<?php 
include('headers.php'); 
include('includes/db.php');    
@session_start();
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Withdraw Balance from Agent is Success</h1>
      <hr/>
<?php 
$Action ="Withdraw Balance Success";
?>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Agent Withdraw Balance Success</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Agent <?php echo $Action; ?></h5>

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
</script>
<?php 
include('end_html.php');
?>
