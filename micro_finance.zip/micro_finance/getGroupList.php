<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$ID='';    $name='';   $AgentName=''; $agentId='';
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and GroupName like '%".$name."%' ";
}

$agentIdStr='';
if($agentId<>'')
{
    $agentIdStr =" and g.`agentID`='".$agentId."'";
}

if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;

if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `GID`, `GroupName`, a.`AgentName` from `group_master` as g LEFT JOIN `agent_profile` as a ON g.`agentID`=a.`AgentId` WHERE 1 $nameStr  $agentIdStr Order By `GID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        echo "<tr>
                    <th scope='row'><a href='group_edit.php?GID=$GID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_Group($GID)'>Delete</a></th>
                    <td>$GID</td>
                    <td>$GroupName</td>
                    <td>$AgentName</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`GID`) as C  FROM `group_master` WHERE 1 $nameStr";
echo '<tr><td colspan="8">';
//echo $Select_sql;
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    $N=$count/$Intv;
if($N>1)
{
$DivStr=<<<Div_Str
<nav aria-label="Page navigation example">
  <ul class="pagination">
Div_Str;
if($page==0)
{
$DivStr.=<<<Div_Str
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
else 
{
    $k=$page-1;
$DivStr.=<<<Div_Str
    <li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_srch$k' onClick="showGroupList($k);" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Previous</span>
      </a>
    </li>
Div_Str;
for($i=0;$i<$N;$i++)
{
$j=$i+1;
    if($i==$page)
    {
$DivStr.=<<<Div_Str
<li class="page-item active"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showGroupList($i);">$j</a></li>
Div_Str;
    }
    else
    {
$DivStr.=<<<Div_Str
<li class="page-item"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showGroupList($i);">$j</a></li>
Div_Str;
    }
}

if($page==$N-1)
{
$DivStr.=<<<Div_Str
<li class="page-item disabled">
      <a class="page-link" href="#" aria-label="Next">
Div_Str;
}
else 
{
    $k=$page+1;
$DivStr.=<<<Div_Str
<li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_next' onClick="showGroupList($k);" aria-label="Next">
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Next</span>
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
Div_Str;
echo $DivStr;
}
$DivStr=<<<Div_Str
<span title=" Based on Searched Result">Total Records </span><span style="color:orange">$count</span> &nbsp;&nbsp;&nbsp;Page size 
<input type="text" value="$Intv" id="txtPageSize" size="2" onChange="setCustPageSize(this.value)">
Div_Str;
echo $DivStr;
echo "</td></tr>";
?>