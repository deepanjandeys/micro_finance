<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');
//include('includes/functions.php');
$LoanRegNo=''; 
date_default_timezone_set("Asia/Kolkata");
extract($_GET); 

$CID=0; $EMIPrincipal=''; $EMIInterest=''; $EMIPayMode=''; 
$LoanDate=''; $CloseDate='';

$sqlLog = PHP_EOL.'-- recreateEMI.php '.PHP_EOL;
        $crDate=date('Y-m-d H:i:s');

        ///////////////////////////////
            $txnID=0; $NoOfDays=0;  $FineAmount='';

            $SelSql="SELECT e.`txnID`, DATEDIFF(NOW(), e.`dueDate`) as NoOfDays,l.FineAmount FROM `emi_register` as e JOIN `loan_register` as l on e.LoanRegNo=l.LoanRegNo WHERE `txnDateTime` is null and `Fine` is null and DATEDIFF(NOW(), e.`mdf_dat_tim`)>0";
            //echo $SelSql;
            $Recordset      =   mysqli_query($db,$SelSql);
            
            if(mysqli_num_rows($Recordset)>0)
            {
            while($row            =   mysqli_fetch_assoc($Recordset))
            {
            extract($row);   
        $Fine=$FineAmount*$NoOfDays;
        $updSql= "UPDATE `emi_register` SET  `Fine`=$Fine WHERE `txnID`=$txnID;";
        $res1   = mysqli_query($db,$updSql);            
        $sqlLog .= $updSql.PHP_EOL;

            }
            
    }            

$sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>