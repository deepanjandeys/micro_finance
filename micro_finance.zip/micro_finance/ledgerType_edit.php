<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
</aside><!-- End Sidebar-->
<?php 
$Name=''; $ID ='0';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['ID']))
{
$ID=(int)$_GET['ID'];
 $SelSql="SELECT  `ID`, `Name` FROM `ledger_types` WHERE `ID`=$ID";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Ledger Type</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Ledger Type</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Ledger Type<?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveLedgerType.php" method="post">
                <input type="hidden" name="ID" value="<?php echo $ID; ?>">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Ledger Type Name </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="Name" name="Name" value="<?php echo $Name; ?>" required>
                  </div>
                </div>
                              
                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
function LedgerType_Change() {
    var val = document.getElementById("LedgerType").value;
    var opts = document.getElementById('LedgerTypeOptions').children;
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].value === val) {
        // An item was selected from the list!
        // yourCallbackHere()
        $('#spnLedgerTypeName').html(opts[i].text);
        //console.log(opts[i].text);
        break;
      }
    }
  }
LedgerType_Change();
</script>

<?php 
include('end_html.php');
?>
