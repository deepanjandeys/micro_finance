<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$ID=''; $Name='';
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveCity.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
$SelSql        =   "SELECT `id_gen_num` as ID FROM `gen_ids` WHERE `id_code`=3";
$Recordset      =   mysqli_query($db,$SelSql);
$row            =   mysqli_fetch_assoc($Recordset);
extract($row);   
    
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=3;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);

            $insSql="INSERT INTO `city_master`(`Sl`, `City_Name`,`State_Sl`,`crt_dat_time`) VALUES ('$ID','$City_Name','$State_Sl','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            //echo '<br>'.$insSql;
            //die();
    
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `city_master` SET `City_Name`='$City_Name',`State_Sl`='$State_Sl' WHERE `Sl`=".$ID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:city_edit.php'); 
    }
    else 
    {
        $_SESSION['action']     = $action;
        $_SESSION['City_Name']  = $City_Name;
        header('location:citySuccess.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>