<?php 
include('headers.php'); 
include('includes/db.php');    
@session_start();
$LedgerName='';   $LedgerName1='';  $Amount=0;

if(isset($_SESSION['LedgerName']))
  $LedgerName=$_SESSION['LedgerName'];

if(isset($_SESSION['LedgerName1']))
  $LedgerName1=$_SESSION['LedgerName1'];

if(isset($_SESSION['Amount']))
  $Amount=$_SESSION['Amount'];

?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Transfer Amount Rs <span class="text-danger"><?php echo $Amount; ?></span> from <span class="text-danger"><?php echo $LedgerName; ?></span> to <span class="text-danger"><?php echo $LedgerName1; ?></span> is Success</h1>
      <hr/>
<?php 
$Action ="Transfer Balance Success";
?>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Transfer Balance Success</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Transfer <?php echo $Action; ?></h5>

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
</script>
<?php 
include('end_html.php');
?>
