<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$agentId='';    $withdraw_balance=0; $Balance=0;
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveAgentWIthdrawBalance.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
//////////////////////////////////////////

        $SelSql        =   "SELECT `LedgerID` FROM `agent_profile` WHERE `AgentID`=$agentId";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   

///////////////////// add record to agent transaction log
////////////////////////////////////////////////////////////
        $SelSql        =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //           2 for Withdraw  , 3 Loan Giving , 4 EMI Collection
    $txnType=2;
    // vouType = 0 for agent  , 1 account tranfer
    //         
    $vouType=0; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$agentId','$vouType','0','$txnType','Withdraw Balance')";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

        $SelSql        =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+2,`last_gen_date`='$crDate' WHERE `id_code`=11;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    
    $ledgerID_Cash=2;
    // $LedgerID newly generated Ledger ID of agent
    // $withdraw_balance openning withdraw_balance of agent
    $id1 = $id+1; // next Id
    $custId=0;
    ////////////////
        $SelSql        =   "SELECT `balance` as `cashBalance` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_Cash"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $cashBalance += $withdraw_balance;   // add cash <- withdraw_balance

        $updSql= "UPDATE `ledger_master` SET  `balance`= $cashBalance WHERE `LedgerID`=$ledgerID_Cash;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    
    $Balance -= $withdraw_balance;
    $updSql= "UPDATE `ledger_master` SET  `balance`= $Balance WHERE `LedgerID`=$LedgerID;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    
    ///////////////////////////////////////////////
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$ledgerID_Cash', '$LedgerID', '$withdraw_balance', '0.00', '$custId', '$cashBalance'), ('$id1', '$tid', '$LedgerID', '$ledgerID_Cash', '0.00', '$withdraw_balance', '$custId', '$Balance');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
        
        }
        else if($action=='Update') 
        {
            //// later
        }
    if($res1=='')
    {
        header('location:agent_withdraw_balance.php'); 
    }
    else 
    {
        header('location:agent_withdraw_balance_success.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>