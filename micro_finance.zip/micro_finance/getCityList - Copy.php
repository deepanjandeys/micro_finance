<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$ID='';    $name='';   
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and City_Name like '%".$name."%' ";
}


$State_SlStr='';
if($State_Sl<>'')
{
    $State_SlStr=" and State_Sl ='".$State_Sl."' ";
}

if(isset($_COOKIE['pgSizeC']))
    $Intv=(int)$_COOKIE['pgSizeC'];
else
    $Intv=0;

if($Intv==0)
    $Intv=1000;
$start=($page-1)*$Intv; 

$SelSql="SELECT c.`Sl` as `ID`, `City_Name` as `Name`, `State_Name` from `city_master` as c JOIN `state_master` as s ON c.`State_Sl`=s.`Sl` WHERE 1 $nameStr $State_SlStr Order By c.`Sl` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        echo "<tr>
                    <th scope='row'><a href='city_edit.php?ID=$ID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_city($ID)'>Delete</a></th>
                    <td>$ID</td>
                    <td>$Name</td>
                    <td>$State_Name</td>
                    <td></td>
                  </tr>";
         
        }
    } 
         
$Select_sql = "SELECT count(`Sl`) as C  FROM `City_master` WHERE 1 $nameStr $State_SlStr";
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    
/*
if($N>1)
{
$DivStr=<<<Div_Str
<nav aria-label="Page navigation example">
  <ul class="pagination">
Div_Str;
if($page==0)
{
$DivStr.=<<<Div_Str
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
else 
{
    $k=$page-1;
$DivStr.=<<<Div_Str
    <li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_srch$k' onClick="showCitiList($k);" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Previous</span>
      </a>
    </li>
Div_Str;
for($i=0;$i<$N;$i++)
{
$j=$i+1;
    if($i==$page)
    {
$DivStr.=<<<Div_Str
<li class="page-item active"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showCitiList($i);">$j</a></li>
Div_Str;
    }
    else
    {
$DivStr.=<<<Div_Str
<li class="page-item"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showCitiList($i);">$j</a></li>
Div_Str;
    }
}

if($page==$N-1)
{
$DivStr.=<<<Div_Str
<li class="page-item disabled">
      <a class="page-link" href="#" aria-label="Next">
Div_Str;
}
else 
{
    $k=$page+1;
$DivStr.=<<<Div_Str
<li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_next' onClick="showCitiList($k);" aria-label="Next">
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Next</span>
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
Div_Str;
echo $DivStr;
}
$DivStr=<<<Div_Str
<span title=" Based on Searched Result">Total Records </span><span style="color:orange">$count</span> &nbsp;&nbsp;&nbsp;Page size 
<input type="text" value="$Intv" id="txtPageSize" size="2" onChange="setCustPageSize(this.value)">
Div_Str;
echo $DivStr;
*/

$lnks= get_pagination_links($page,'showCitiList',$count,$Intv);

echo $lnks;

echo "</td></tr>";
?>