<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$AID=''; $IDProofLink=''; $addressProofLink=''; $photoLink='';

extract($_GET); 
$sqlLog = PHP_EOL.'-- deleteAgent.php '.PHP_EOL;
        
        $SelSql        =   "SELECT `IDProofLink`, `addressProofLink`, `photoLink` FROM `agent_profile` WHERE `AgentID`=$AID";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    if($IDProofLink !='')
    {
        if(file_exists("uploads/IDProofLink/".$IDProofLink))
         {
            unlink("uploads/IDProofLink/".$IDProofLink);
         }
    }
    if($addressProofLink !='')
    {
        if(file_exists("uploads/addressProofLink/".$addressProofLink))
         {
            unlink("uploads/addressProofLink/".$addressProofLink);
         }
    }
    if($photoLink !='')
    {
        if(file_exists("uploads/photoLink/".$photoLink))
         {
            unlink("uploads/photoLink/".$photoLink);
         }
     }
    
    $delSql="DELETE FROM `agent_profile` WHERE `AgentID`=".$AID;
            //echo "sql ".$delSql;
    
    $sqlLog .= $delSql.PHP_EOL;
    $res1   = mysqli_query($db,$delSql);

    header('location:agents.php'); 
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>