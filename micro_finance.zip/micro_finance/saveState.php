<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$ID=''; $Name='';
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveState.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
$SelSql        =   "SELECT `id_gen_num` as ID FROM `gen_ids` WHERE `id_code`=4";
$Recordset      =   mysqli_query($db,$SelSql);
$row            =   mysqli_fetch_assoc($Recordset);
extract($row);   
    
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=4;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);

            $insSql="INSERT INTO `State_master`(`Sl`, `State_Name`,`CountrySl`,`crt_dat_time`) VALUES ('$ID','$State_Name','0','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            //echo '<br>'.$insSql;
            //die();
    
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `State_master` SET `State_Name`='$State_Name' WHERE `Sl`=".$ID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:State_edit.php'); 
    }
    else 
    {
        header('location:states.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>