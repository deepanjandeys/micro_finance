<?php 
include('includes/db.php');
@session_start();
$org_name='';

if(isset($_SESSION['org_name']))
{
  $org_name= $_SESSION['org_name'];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php  echo $org_name;  ?> Agent Created successfully</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<body>

    <div class="container">
        <div class="row">
            <div class="col-12">
<?php 
$AgentName=''; 
if(isset($_SESSION['AgentName']))
    $AgentName=$_SESSION['AgentName'];
if(isset($_SESSION['action']))
{
    echo '<h2 class="bg-primary mt-3 p-3 rounded text-white">Agent '.$AgentName.'  '.$_SESSION['action'].' Successfully</h2>';
    
    if($_SESSION['action']=='Save')
    {
        $_SESSION['lastPage']='yes';
    }

   echo '<span style="float:left;"> Go to <a href="agents.php" class="btn btn-warning">Agent List</a></span>';

}
?>                
            </div>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>