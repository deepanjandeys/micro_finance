<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$ID=''; $City_Name=''; $State_Sl='';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['ID']))
{
$ID=(int)$_GET['ID'];
 $SelSql="SELECT `Sl` as `ID`, `City_Name`,`State_Sl` FROM `city_master` WHERE `Sl`=$ID";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>City</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">City</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">City <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveCity.php" method="post" onsubmit="return form_validation();">
                <input type="hidden" name="ID" value="<?php echo $ID; ?>">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">City Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="City_Name" name="City_Name" value="<?php echo $City_Name; ?>" required>
                  </div>
                </div>
                 <?php 
$Select_sql ="SELECT `Sl`, `State_Name` FROM `state_master` ";
$result = mysqli_query($db,$Select_sql);
$selStates='There is no Agent ';
if(mysqli_num_rows($result)>0)
{
$selStates=<<<select_States
<select id="selState" name='State_Sl' class="from-control" style="width:200px;">
  <option value="">Select City</option>
select_States;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['State_Name'];
    
$selStates.=<<<select_States
<option value='$Code'>$Name</option>
select_States;
  } 
$selStates.=<<<select_States
</select> 
select_States;
}
?>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">State Id</label>
                  <div class="col-sm-4">
                     <?php echo $selStates; ?>
                  </div>
                  <div class="col-sm-6">
                  </div>
                </div>

                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
$(document).ready(function(){
            $('#selState').select2();
        });

function form_validation()
{
var msg='';
  if($('#selState').val()=='')
  {
    msg +='Select a State<br>';
  }
  
  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}
</script>

<?php 
include('end_html.php');
?>
