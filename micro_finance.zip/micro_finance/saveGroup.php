<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$GroupName=''; $GID=0; $agentId=0;
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveGroup.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
$SelSql        =   "SELECT `id_gen_num` as GID FROM `gen_ids` WHERE `id_code`=9";
$Recordset      =   mysqli_query($db,$SelSql);
$row            =   mysqli_fetch_assoc($Recordset);
extract($row);   
    
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=9;";
    $res1       =   mysqli_query($db,$updSql);

$insSql="INSERT INTO `group_master`(`GID`, `GroupName`,`agentID`,`crt_dat_time`) VALUES ($GID, '$Name','$agentId','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `group_master` SET `GroupName`='$Name',`agentID`='$agentId', `mdf_dat_tim`='$upDate' WHERE `GID`=".$GID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:group_edit.php'); 
    }
    else 
    {
        header('location:groups.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>