<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 

 $txnID='';         $txnDateTime='';    $dueDate='';    $EMIPrincipal='';  
 $EMIInterest='';   $Fine='';           $LoanRegNo='';  $agentId='';  
 $EMIPayMode='';    $Remarks='';        $callBy=0;      $CID='';

$Action="Add new";
$ActionButton="Save";
if(isset($_GET['txnID']))
{
$txnID=(int)$_GET['txnID'];
 $SelSql="SELECT  e.`txnID`, e.`txnDateTime`, e.`dueDate`, e.`EMIPrincipal`, e.`EMIInterest`, `Fine`, e.`LoanRegNo`, e.`agentId`, e.`EMIPayMode`, e.`Remarks`,DATEDIFF(NOW(), e.`dueDate`) as NoOfDays,lr.`FineAmount` FROM `EMI_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` WHERE `txnID`=$txnID";
 //echo $SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }

    if($Fine=='')
        {
            $Fine = (float)$FineAmount * (int) $NoOfDays;
        }
}
if(isset($_GET['callBy']))
  $callBy=$_GET['callBy'];

if(isset($_GET['CID']))
  $CID=$_GET['CID'];

?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>EMI</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">EMI</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">EMI <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveEmi.php" method="post" enctype="multipart/form-data">
              <input type="hidden" name="txnID" value="<?php echo $txnID; ?>">
              <input type="hidden" name="callBy" value="<?php echo $callBy; ?>">
              <input type="hidden" name="CID" value="<?php echo $CID; ?>">

                <div class="row mb-3">
                  <label for="EMIPrincipal" class="col-sm-2 col-form-label">EMIPrincipal</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="EMIPrincipal" id="EMIPrincipal" value="<?php echo $EMIPrincipal;?>" readonly>
                  </div>
                  <label for="EMIInterest" class="col-sm-2 col-form-label">EMI Interest</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="EMIInterest" id="EMIInterest" value="<?php echo $EMIInterest;?>" readonly>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="EMITotal" class="col-sm-2 col-form-label">EMI Total</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" name="EMITotal" id="EMITotal" readonly>
                  </div>
                  <label for="FineAmount" class="col-sm-2 col-form-label">Fine </label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="Fine" id="Fine" value="<?php echo $Fine;?>" required>
                  </div>
                </div>
                 <div class="row mb-3">
                  <label  class="col-sm-2 col-form-label">EMI Pay Mode</label>
                  <div class="col-sm-4">
                     <?php 
$Select_sql ="SELECT `ID`, `Name` FROM `payment_modes` WHERE `ID`=$EMIPayMode";
$result = mysqli_query($db,$Select_sql);
$selCustomers='There is no Payment Mode';
if(mysqli_num_rows($result)>0)
{
$row = mysqli_fetch_array($result);
echo $row['Name'];
}
?>

                  </div>
              <label for="Remarks" class="col-sm-2 col-form-label">Remarks</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" name="Remarks" id="Remarks" value="<?php echo $Remarks; ?>" >
                  </div>

                 </div>
                 <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Agent</label>
                  <div class="col-sm-4">
                     <?php 
$Select_sql ="SELECT `AgentName` FROM `agent_profile` WHERE `AgentId`=$agentId";
$result = mysqli_query($db,$Select_sql);
if(mysqli_num_rows($result)>0)
{
$row = mysqli_fetch_array($result);
echo $row['AgentName'];
}
?>

                  </div>
              <label for="LoanRegNo" class="col-sm-2 col-form-label">Loan Reg No</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" name="LoanRegNo" id="LoanRegNo" value="<?php echo $LoanRegNo; ?>" >
                  </div>

                 </div>
  

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Recived Date</label>
                  <div class="col-sm-4">
                  <label><?php if($txnDateTime!='')echo date('d-m-Y',strtotime($txnDateTime)); ?></label>
                  </div>
                  <label class="col-sm-2 col-form-label">Due Date</label>
                  <div class="col-sm-4">
                    <label>
                  <?php if($dueDate!='') echo date('d-m-Y',strtotime($dueDate));?>
                    </label>
                  </div>
                </div>
                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  function calcuTotal()
  {
    var P= parseFloat($('#EMIPrincipal').val());
    
    if(isNaN(P))
      P=0;

    var I= parseFloat($('#EMIInterest').val());

    if(isNaN(I))
      I=0;
    var T=P+I;
    $('#EMITotal').val(T.toFixed(2));
  }

  calcuTotal();
</script>

<?php 
include('end_html.php');
?>
