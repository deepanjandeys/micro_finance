<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Customers</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Customer</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Customers   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_mobile" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Address
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                        <input type="text" id="src_address" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          City
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
//print_r($_SESSION);

$Select_sql ="SELECT `Sl`, `City_Name` FROM `city_master` where `State_Sl`=18;";
$result = mysqli_query($db,$Select_sql);
$selCities='There is no City ';

if(mysqli_num_rows($result)>0)
{
$selCities=<<<select_Cities
        <select id="selCity" class="from-control" style="width:200px;">
        <option value="">Select City</option>
select_Cities;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['City_Name'];
    
$selCities.=<<<select_Cities
<option value='$Code'>$Name</option>
select_Cities;
  } 
$selCities.=<<<select_Cities
</select>
select_Cities;
}

echo $selCities;
?>
<span id='spnCity_Name'></span>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          ID Proof
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_IDProof" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          Address Proof
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_AddressProof" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Agent
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
  $agentId='';
  $agentIdReadOnly='';
  $whereClausCustomer='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $agentIdReadOnly='readonly';
      $whereClausCustomer=" and `agentId`=$agentId";
    }
}

$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile` WHERE 1 $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<select id="selAgent" style="width:200px;">
Select_Agents;

if($agentId=='')
{
$selAgents.=<<<Select_Agents
  <option value=''>Select Agent</option>
Select_Agents;
}

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}
echo $selAgents;
?>

    <span id='spnAgentname'></span>
                        </div>
                        <div class="col-lg-3">
                          
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showCustomerList(1)">
                        
                        </div>
                      </div>
                      </fieldset>
                   </div>
                   <a href="customer_edit.php">Add New</a>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">CID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Mobile No</th>
                    <th scope="col">Address</th>
                    <th scope="col">IDProof</th>
                    <th scope="col">addressProof</th>
                    <th scope="col">IDProofLink</th>
                    <th scope="col">addressProofLink</th>
                    <th scope="col">photoLink</th>
                    <th scope="col">agent</th>
                    <th scope="col">city</th>
                    <th scope="col">sex</th>
                    <th scope="col">dob</th>                  
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
        $(document).ready(function(){
            $('#selCity').select2();
            $('#selAgent').select2();
        });

  function delete_cust(CustID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteCustomer.php?CID='+CustID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showCustomerList(curPage)
{

  var name=$('#src_name').val();
  var mobile=$('#src_mobile').val();
  var address=$('#src_address').val();
  var IDProof=$('#src_IDProof').val();
  var AddressProof=$('#src_AddressProof').val();
  var agent=$('#selAgent').val();
  var city=$('#selCity').val();

if(agent==undefined)
  agent=0;

$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');

    var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
 
setCookie('CustPageNo',curPage,7);
  xmlhttp.open("GET","getCustomerList.php?page="+curPage+"&name="+name+"&mobile="+mobile+"&address="+address+"&IDProof="+IDProof+"&AddressProof="+AddressProof+"&agent="+agent+"&city="+city,true);
  xmlhttp.send();
}


<?php  
if(isset($_SESSION['lastPage']))
{
  if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$Select_sql = "SELECT count(`CID`) as C  FROM `customer_profile` Where 1 $whereClausCustomer";
$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  
  $lastPage=ceil($count/$Intv);

echo 'showCustomerList('.$lastPage.');';

unset($_SESSION['lastPage']);
}
else 
{
?>
var pageNo=getCookie('CustPageNo');
if(pageNo=='')
  pageNo=1;

showCustomerList(pageNo);
<?php 
}
?> 
function setCustPageSize(a)
{
document.cookie="pgZize="+a; 
showCustomerList(a);
}


function setCustPageNumber(a)
{
showCustomerList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}


$('#src_dob_from').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_dob_to').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#src_dob_from').val('');
$('#src_dob_to').val('');

</script>
<?php 
include('end_html.php');
?>
