<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');  

$ledgerID='';

if (isset($_GET['ledgerID'])) 
{
  $ledgerID=$_GET['ledgerID'];
}
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Ledger Trans</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Ledger Tran</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
             
                   <!-- Table with stripped rows -->
                   <div id="divSerach" >
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Ledger 
                        </div>
                        <div class="col-lg-3">
                          <?php 
$agentIdReadOnly='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $agentIdReadOnly='readonly';

      $ledgerID=0;
      $Select_sql ="SELECT `ledgerID` FROM `agent_profile` WHERE `AgentId`='$agentId'";
      $result = mysqli_query($db,$Select_sql);
      $row = mysqli_fetch_array($result);
      extract($row);
    }
    else 
    {
      $agentIdReadOnly='required';
    }
}

$Select_sql ="SELECT `LedgerID`,`LedgerName` FROM `ledger_master`";
$result = mysqli_query($db,$Select_sql);

$selLedgers='There is no Ledger';

if(mysqli_num_rows($result)>0)
{
$selLedgers=<<<select_Ledgers
<select id="ledgerID" style="width:200px;">
  <option value=''>Select Ledger</option>
select_Ledgers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['LedgerID'];
    $Name=$row['LedgerName'];
    
$selLedgers.=<<<select_Ledgers
<option value='$Code'>$Name</option>
select_Ledgers;
  } 
$selLedgers.=<<<select_Ledgers
</select> 
select_Ledgers;
}

echo $selLedgers;
?>
</div>
<div class="col-lg-3">
  <span id='spnledgerID_Name'></span>                        
  </div>
                        <div class="col-lg-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showLedgerTranList(1)">
                        </div>
</div>
<div class="row py-1">
<div class="col-lg-3"></div>
<div class="col-lg-9">
              <?php
              $ledgerTranChoice=0;
              if(isset($_COOKIE['ledgerTranChoice']))
                  $ledgerTranChoice=(int)$_COOKIE['ledgerTranChoice'];
                $chkToday='';
                $chkWeek='';
                $chkMonth='';
                $chkUntill='';

                $toDay = date('d-m-Y');
                $day = date('w');
                //$day++;
                $week_start = date('d-m-Y', strtotime('-'.$day.' days'));
                $week_end = date('d-m-Y', strtotime('+'.(6-$day).' days'));  
                $Month_start = date('01-m-Y');
                $Month_end = date('d-m-Y');

                $TranDateFrom='';
                $TranDateTo='';

  $start_date='';
  $end_date='';

$Select_sql = "SELECT `start_date`,`end_date` FROM `session_master` WHERE `active`=1";
$result = mysqli_query($db,$Select_sql);
if(mysqli_num_rows($result)>0)
{
  $row = mysqli_fetch_array($result);
  $start_date = date('d-m-Y',strtotime($row['start_date']));
  $end_date = date('d-m-Y',strtotime($row['end_date']));
}
              if($ledgerTranChoice==0)
              {
                $chkToday='checked';

                $TranDateFrom=$toDay;
                $TranDateTo=$toDay;
              }
              else if($ledgerTranChoice==1)
              {
                $chkWeek='checked';

                $TranDateFrom=$week_start;
                $TranDateTo=$week_end;
              }
              else if($ledgerTranChoice==2)
              {
                $chkMonth='checked';
                $TranDateFrom=$Month_start;
                $TranDateTo=$Month_end;
              }
              else if($ledgerTranChoice==3)
              {
                $chkUntill='checked';
                $TranDateFrom=$start_date;
                $TranDateTo=$end_date;
              } 
              ?>                
               </h5>
              <div class="row">
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" <?php echo $chkToday; ?> id="rdbToday" onclick="setToday()"><label for="rdbToday">&nbsp; Today</label>
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbWeek" <?php echo $chkWeek; ?> onclick="setWeekDay()"> <label for="rdbWeek"> this Week</label>
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbMonth" <?php echo $chkMonth; ?> onclick="setMonthDay()"> <label for="rdbMonth"> this Month</label> 
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbUntill" <?php echo $chkUntill;?> onclick="setCurrentSession()"> <label for="rdbUntill"> Current Session</label>
               </div>
              </div>

                <input type="hidden" id="hdToDay" value="<?php echo $toDay; ?>">

                <input type="hidden" id="hdWeekFrom" value="<?php echo $week_start; ?>">
                <input type="hidden" id="hdWeekTo" value="<?php echo $week_end; ?>">
                <input type="hidden" id="hdMonthFrom" value="<?php echo $Month_start; ?>">
                <input type="hidden" id="hdMonthTo" value="<?php echo $Month_end; ?>">
                <input type="hidden" id="hdStart_date" value="<?php echo $start_date; ?>">
                <input type="hidden" id="hdEnd_date" value="<?php echo $end_date; ?>">
                  
</div>
</div>
                <div class="row py-1">
                        <div class="col-lg-3">
                          Transaction Date
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_TranDateFrom" value="<?php echo $TranDateFrom; ?>" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_TranDateTo" value="<?php echo $TranDateTo; ?>" class="form-control">
                        </div>
                        <div class="col-lg-3">
                        </div>
                      </div>
                      

                      </fieldset>
                   </div>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Particuler</th>
                    <th scope="col">Debit</th>
                    <th scope="col">Credit</th>
                    <th scope="col">Time</th>
                    <th scope="col">Balance</th>
                    <th scope="col">Remarks</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  
  function delete_LedgerTran(LedgerTranID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteLedgerTran.php?LedgerTranID='+LedgerTranID);
    }
    else 
    {
      //alert('not deleted');
    }
  }
  
 $(document).ready(function(){
            $('#ledgerID').select2();
  });

function showLedgerTranList(curPage)
{
var ledgerID= $('#ledgerID').val();
$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');

var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);


      var CurPage=parseInt($('#txtCurPage').val());
      var totalPage=parseInt($('#spn_totalPage').html());
      if(CurPage>totalPage)
      {
      setCookie('LedgerTranPageNo',totalPage,7); 
      window.location.reload();       
      }
    }
  }

  var TranDateFrom = $('#src_TranDateFrom').val();
  var TranDateTo = $('#src_TranDateTo').val();

setCookie('LedgerTranPageNo',curPage,7);
console.log("getLedgerTranList.php?page="+curPage+"&ledgerID="+ledgerID+"&TranDateFrom="+TranDateFrom+"&TranDateTo="+TranDateTo);

xmlhttp.open("GET","getLedgerTranList.php?page="+curPage+"&ledgerID="+ledgerID+"&TranDateFrom="+TranDateFrom+"&TranDateTo="+TranDateTo,true);
xmlhttp.send();
}

var pageNo=getCookie('LedgerTranPageNo');
if(pageNo=='')
  pageNo=1;

showLedgerTranList(pageNo);
function setCustPageSize(a)
{
document.cookie="pgZize="+a; 
showLedgerTranList(1);
}

function setCustPageNumber(a)
{
//document.cookie="pgSizeC="+a; 
showLedgerTranList(a);
}

//ledgerID_Change();

function setToday()
{
var hdToDay=$('#hdToDay').val();
$('#src_TranDateFrom').val(hdToDay);
$('#src_TranDateTo').val(hdToDay);
setCookie('ledgerTranChoice',0,7);
showLedgerTranList(pageNo);
}

function setWeekDay()
{
var hdWeekFrom=$('#hdWeekFrom').val();
var hdWeekTo=$('#hdWeekTo').val();
$('#src_TranDateFrom').val(hdWeekFrom);
$('#src_TranDateTo').val(hdWeekTo);
setCookie('ledgerTranChoice',1,7);
showLedgerTranList(pageNo);
}

function setMonthDay()
{
var hdMonthFrom=$('#hdMonthFrom').val();
var hdMonthTo=$('#hdMonthTo').val();
$('#src_TranDateFrom').val(hdMonthFrom);
$('#src_TranDateTo').val(hdMonthTo);
setCookie('ledgerTranChoice',2,7);
showLedgerTranList(pageNo);
}

function setCurrentSession()
{
  //debugger;
var start_date=$('#hdStart_date').val();
var end_date=$('#hdEnd_date').val();
$('#src_TranDateFrom').val(start_date);
$('#src_TranDateTo').val(end_date);
setCookie('ledgerTranChoice',3,7);
showLedgerTranList(pageNo);
}

$('#src_TranDateFrom').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_TranDateTo').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

</script>
<?php 
include('end_html.php');
?>