<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php'); 

$CID=''; $CustName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $agentId=''; $cityId=''; 
$sex='';  $dob='';
//print_r($_POST);

date_default_timezone_set("Asia/Kolkata");
extract($_POST); 
$dob=date('Y-m-d',strtotime($dob));

$sqlLog = PHP_EOL.'-- saveCustomer.php '.PHP_EOL;
$IDProofLinkFilename='';
            if(($_FILES['IDProofLink']['error']==0))
            {       
                $path="IDProofLink";
                $file = basename($_FILES['IDProofLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $IDProofLinkFilename=substr($file,0,$pos);
                $IDProofLinkFilename =$IDProofLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["IDProofLink"]["tmp_name"],'./uploads/'.$path.'/'.$IDProofLinkFilename);

                if($hdIDProofLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdIDProofLink))
                    {
                    unlink("uploads/".$path."/".$hdIDProofLink);
                    }
                }

                }
                else
                {
                    $IDProofLinkFilename="";
                }
                
            }
            else
            {
            $IDProofLinkFilename=$hdIDProofLink;  
            }

$addressProofLinkFilename='';
            if(($_FILES['addressProofLink']['error']==0))
            {       
                $path="addressProofLink";
                $file = basename($_FILES['addressProofLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $addressProofLinkFilename=substr($file,0,$pos);
                $addressProofLinkFilename =$addressProofLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["addressProofLink"]["tmp_name"],'./uploads/'.$path.'/'.$addressProofLinkFilename);

                if($hdaddressProofLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdaddressProofLink))
                    {
                    unlink("uploads/".$path."/".$hdaddressProofLink);
                    }
                }

                }
                else
                {
                    $addressProofLinkFilename="";
                }
                
            }
            else
            {
            $addressProofLinkFilename=$hdaddressProofLink;  
            }

$photoLinkFilename='';
            if(($_FILES['photoLink']['error']==0))
            {       
                $path="photoLink";
                $file = basename($_FILES['photoLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $photoLinkFilename=substr($file,0,$pos);
                $photoLinkFilename =$photoLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["photoLink"]["tmp_name"],'./uploads/'.$path.'/'.$photoLinkFilename);
              if($hdphotoLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdphotoLink))
                    {
                    unlink("uploads/".$path."/".$hdphotoLink);
                    }
                }

                }
                else
                {
                    $photoLinkFilename="";
                }
                
            }
            else
            {
            $photoLinkFilename=$hdphotoLink;  
            //echo '1.2 '.$hdphotoLink;
            }
        $queryString='';
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');

        $SelSql        =   "SELECT `id_gen_num` as CID FROM `gen_ids` WHERE `id_code`=1";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=1;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);

            $insSql="INSERT INTO `customer_profile`(`CID`, `CustName`, `Address`, `mobileNo`, `IDProof`, `addressProof`, `IDProofLink`, `addressProofLink`, `photoLink`, `agentId`, `cityId`, `sex`, `dob`) VALUES ('$CID','$CustName','$Address','$mobileNo','$IDProof','$addressProof','$IDProofLinkFilename','$addressProofLinkFilename','$photoLinkFilename','$agentId','$cityId','$sex','$dob')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            //echo '<br>'.$insSql;
            //die();
        $queryString='lastPage';
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `customer_profile` SET `CustName`='$CustName',`Address`='$Address',`mobileNo`='$mobileNo',`IDProof`='$IDProof',`addressProof`='$addressProof',`IDProofLink`='$IDProofLinkFilename',`addressProofLink`='$addressProofLinkFilename',`photoLink`='$photoLinkFilename',`agentId`='$agentId',`cityId`='$cityId',`sex`='$sex',`dob`='$dob' WHERE `CID`=".$CID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:customer_edit.php'); 
    }
    else 
    {
        $_SESSION['action'] = $action;
        $_SESSION['CustName'] = $CustName;
        
        header('location:customerSuccess.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>