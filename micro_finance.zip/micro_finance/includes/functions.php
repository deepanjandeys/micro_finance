<?php
function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

function get_tiny_url($url)  {  
  $ch = curl_init();  
  $timeout = 5;  
  curl_setopt($ch,CURLOPT_URL,'http://tinyurl.com/api-create.php?url='.$url);  
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);  
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);  
  $data = curl_exec($ch);  
  curl_close($ch);  
  return $data;  
}

function maskEmail($email){
 
   return $maskEmail=preg_replace('/(?<=.).(?=.*@)/', '*', $email);
}

function generateNumericOTP($n) {
      
    // Take a generator string which consist of
    // all numeric digits
    $generator = "1357902468";
  
    // Iterate for n-times and pick a single character
    // from generator and append it to $result
      
    // Login for generating a random character from generator
    //     ---generate a random number
    //     ---take modulus of same with length of generator (say i)
    //     ---append the character at place (i) from generator to result
  
    $result = "";
  
    for ($i = 1; $i <= $n; $i++) {
        $result .= substr($generator, (rand()%(strlen($generator))), 1);
    }
  
    // Return result
    return $result;
}

function get_pagination_links($current_page, $functionName,$total_record,$Intv)
{
  $links='';

$total_pages=ceil($total_record/$Intv);

    if($total_record<=$Intv)
     goto lastLine;

  ///https://stackoverflow.com/questions/28716904/limit-pages-numbers-on-php-pagination

  $links = '<nav aria-label="Page navigation example">
  <ul class="pagination">';

  if($current_page==1)
  {

   $links.='<li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>';
         $a='active';
  }
  else 
  {
    $k=$current_page-1;
    $links.='<li class="page-item ">
      <a class="page-link" href="javascript:void(0);" id="a_srch'.$k.'" onClick="'.$functionName.'('.$k.');" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>';
        $a='';
  }

  $links .='  <span class="sr-only">Previous</span>
      </a>
    </li>';

    if ($total_pages >= 1 && $current_page <= $total_pages) 
    {
      $i=1; $factor=2;
        //$links .= "<a href=\"{$url}?page=1\">1</a>";
      $links .='<li class="page-item '.$a.'"><a class="page-link '.$a.'" href="javascript:void(0);" id="a_srch'.$i.'" onClick="'.$functionName.'('.$i.');">'.$i.'</a></li>';
        $i = max(2, $current_page - $factor);
        if ($i > 2)
            $links .= " ... ";
        for (; $i < min($current_page + ($factor+1), $total_pages); $i++) 
        {
            //$links .= "<a href=\"{$url}?page={$i}\">{$i}</a>";
          if($i==$current_page)
            $a='active';
          else 
            $a='';

            $links .='<li class="page-item '.$a.'"><a class="page-link" href="javascript:void(0);" id="a_srch'.$i.'" onClick="'.$functionName.'('.$i.');">'.$i.'</a></li>';
        }
        if ($i != $total_pages)
            $links .= " ... ";
        //$links .= "<a href=\"{$url}?page={$total_pages}\">{$total_pages}</a>";
        

if($current_page==$total_pages)
{
$links .='<li class="page-item active"><a class="page-link active" href="javascript:void(0);" id="a_srch'.$total_pages.'" onClick="'.$functionName.'('.$total_pages.');">'.$total_pages.'</a></li>';
  
$links .='<li class="page-item disabled">
      <a class="page-link" href="#" aria-label="Next">';
}
else 
{
$links .='<li class="page-item "><a class="page-link" href="javascript:void(0);" id="a_srch'.$total_pages.'" onClick="'.$functionName.'('.$total_pages.');">'.$total_pages.'</a></li>';
  
    $k=$current_page+1;
$links .=
'<li class="page-item">
      <a class="page-link" href="javascript:void(0);" id="a_next" onClick="'.$functionName.'('.$k.');" aria-label="Next">';
}        
$links .='<span class="sr-only">Next</span>
        <span aria-hidden="true">&raquo;</span>
      </a>';
}
$links .='  </ul>
</nav>
';


lastLine:
if($total_pages==0) $total_pages=1;

$links.='<span title=" Based on Searched Result">Total Records </span><span style="color:orange">'.$total_record.'</span> &nbsp;&nbsp;&nbsp;Page size 
<input type="text" style="text-align:right;" value="'.$Intv.'" id="txtPageSize" size="3" onChange="setCustPageSize(this.value)"> &nbsp;&nbsp;&nbsp; Page Number
<input type="text" value="'.$current_page.'" style="text-align:right;" id="txtCurPage" size="4" onChange="setCustPageNumber(this.value)">/<span id="spn_totalPage">'.$total_pages.'</span>';

    return $links;
}

?>