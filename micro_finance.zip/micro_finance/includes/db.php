<?php
$hostname_db = "localhost";
$database_db = "micro_finance";
$username_db = "root";
$password_db = "";
$db = mysqli_connect($hostname_db, $username_db, $password_db) or trigger_error(mysqli_error($db),E_USER_ERROR); 
mysqli_select_db($db,$database_db);
?>