<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$page=0;

    $CID='';            $agent='';          $loan_opr='';       $Loan_Amount=""; 
    $EMIPrinci_opr='';  $EMI_Principal='';  $EMIInterst_opr=''; $EMIInterest='';
    $FineAmount_opr=''; $Fine_Amount='';    $PaymentMode='';    
    $EMI_DueDateFrom='';$EMI_DueDateTo='';  $emiNo=0;
 
extract($_GET);

$CIDStr='';
if($CID<>'')
{
    $CIDStr=" and  lr.`CID`=$CID";
}

$GIDStr='';
if($GID<>'')
{
    $GIDStr=" and  lr.`groupID`=$GID";
}

$agentStr='';
if($agent<>'')
{
    $agentStr=" and a.agentID =".$agent." ";
}


$PaymentModeStr='';
if($PaymentMode<>'')
{
    $PaymentModeStr=" and e.EMIPayMode =".$PaymentMode;
}


$LoanTypeStr='';
$LoanType=(int)$LoanType;

if($LoanType >0)
{
    if($LoanType==1)
        $LoanTypeStr=" and lr.LoanType = 1 ";
    else if($LoanType==2)
        $LoanTypeStr=" and lr.LoanType = 2 ";
    else if($LoanType==3)
        $LoanTypeStr=" and lr.LoanType in(1,2) ";
}

date_default_timezone_set("Asia/Kolkata");
$EMI_DueDateStr='';
if($EMI_DueDateFrom<>'' && $EMI_DueDateTo<>'')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateTo =date('Y-m-d',strtotime($EMI_DueDateTo));

    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateTo."'";
}
else if($EMI_DueDateFrom<>'' && $EMI_DueDateTo=='')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateFrom."'";
}
else if($EMI_DueDateFrom=='' && $EMI_DueDateTo<>'')
{
    $EMI_DueDateTo =date('Y-m-d',strtotime($EMI_DueDateTo));
    $EMI_DueDateStr=" and e.`dueDate` <= '".$EMI_DueDateTo."'";
}

$CollectDateStr='';
if($CollectDateFrom<>'' && $CollectDateTo<>'')
{
    $CollectDateFrom=date('Y-m-d',strtotime($CollectDateFrom));
    $CollectDateTo =date('Y-m-d',strtotime($CollectDateTo));

    $CollectDateStr=" and CAST(e.`txnDateTime` AS DATE) between '".$CollectDateFrom."' and '".$CollectDateTo."'";
}
else if($CollectDateFrom<>'' && $CollectDateTo=='')
{
    $CollectDateFrom=date('Y-m-d',strtotime($CollectDateFrom));
    $CollectDateStr=" and CAST(e.`txnDateTime` AS DATE) between '".$CollectDateFrom."' and '".$CollectDateFrom."'";
}
else if($CollectDateFrom=='' && $CollectDateTo<>'')
{
    $CollectDateTo =date('Y-m-d',strtotime($CollectDateTo));
    $CollectDateStr=" and CAST(e.`txnDateTime` AS DATE) <= '".$CollectDateTo."'";
}

//print_r($_COOKIE);

if(isset($_COOKIE['pgEMIcollectSize']))
    $Intv=(int)$_COOKIE['pgEMIcollectSize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;

if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT e.`txnID`, e.`emiNo`, e.`txnDateTime`, e.`dueDate`, e.`EMIPrincipal`, e.`EMIInterest`, e.`Fine`, e.`LoanRegNo`, a.`AgentName`, e.`EMIPayMode`, e.`Remarks`, cp.`CustName`,lr.`LoanAmt`,DATEDIFF(NOW(), e.`dueDate`) as NoOfDays,lr.`FineAmount`,g.`GroupName`,`LoanType` FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` LEFT JOIN `group_master` AS g ON lr.`groupID`=g.`GID` WHERE `txnDateTime` is not null $CIDStr $GIDStr $LoanTypeStr $agentStr $PaymentModeStr $EMI_DueDateStr $CollectDateStr Order By e.`txnID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
 $sumEMIofPage=0;   $sumFineOfPage=0;            
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        if($EMIPayMode=='1')
            $EMIPayModeStr='Daily';
        else if($EMIPayMode=='2')
            $EMIPayModeStr="Weekly";
        else if ($EMIPayMode=='3')
            $EMIPayModeStr="Monthly";
        if($txnDateTime !='')
            $txnDateTime = '<span title="'.date('h:i:s A',strtotime($txnDateTime)).'">'.date('d-m-Y',strtotime($txnDateTime)).'</span>';
        $dueDate = date('d-m-Y',strtotime($dueDate));
        //$Fine=number_format($NoOfDays*$FineAmount,2);

        $txnDateTime.='<a href="reciptEMI.php?txnID='.$txnID.'" target="_blank" class="btn btn-success">Print</a>';
        $EMI="<span title='$EMIPrincipal + $EMIInterest'>".number_format($EMIPrincipal+$EMIInterest,2)."</span>";
        $sumEMIofPage +=($EMIPrincipal+$EMIInterest);
        $sumFineOfPage += $Fine;
        if($LoanType=='1')
            $LoanType='Personal loan';
        else if($LoanType=='2')
            $LoanType='Group loan';
        else  
            $LoanType='';

        echo "<tr>
                    <td>$txnID</td>
                    <td>$emiNo</td>
                    <td id='tdCollect$txnID'>$txnDateTime</td>
                    <td>$dueDate</td>
                    <td style='text-align:right;'>$EMI</td>
                    <td style='text-align:right;' id='tdFine$txnID'><span id='spnFineAmt$txnID'>$Fine</span></td>
                    <td>$EMIPayModeStr</td>
                    <td>$AgentName</td>
                    <td>$CustName</td>
                    <td>$LoanRegNo</td>
                    <td>$GroupName</td>
                    <td>$LoanType</td>
                  </tr>";
         
        }
    } 


echo '<tr><td colspan="4" style="text-align:right;">Total EMI Collected of this page </td><td style="text-align:right;">';
echo number_format($sumEMIofPage+$sumFineOfPage,2);
echo '</td><td  colspan="8"></tr>';


$sumEMI=0;

$Select_sql = "SELECT count(e.`txnID`) as C,sum(e.`EMIPrincipal`+e.`EMIInterest`) as sumEMI,sum(e.`Fine`) as `sumFine` FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` WHERE `txnDateTime` is not null $CIDStr $GIDStr $LoanTypeStr $agentStr $PaymentModeStr $EMI_DueDateStr $CollectDateStr";

if($rdbDay=='t'){
    $rdbDayStr='Today';
}
elseif ($rdbDay=='w') {
    $rdbDayStr='this Week';
}
elseif ($rdbDay=='m') {
    $rdbDayStr='this Month';
}
elseif ($rdbDay=='s') {
    $rdbDayStr='this Session';
}
else 
{
    $rdbDayStr='';
}

////////////
$result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0; $sumFine=0;
                if(isset($row['C']))
                {
                    $count=$row['C'];
                    $sumEMI=$row['sumEMI'];
                    $sumFine=$row['sumFine'];
                }
/////////////
echo '<tr><td colspan="4" style="text-align:right;">Total EMI collected '.$rdbDayStr.' : </td><td style="text-align:right;">';
//echo $Select_sql;
echo number_format($sumEMI+$sumFine,2);
echo '</td><td  colspan="8"></tr>';
echo '<tr><td colspan="4" style="text-align:right;">Fine Collected '.$rdbDayStr.' : </td><td style="text-align:right;">';
//echo $Select_sql;
echo number_format($sumFine,2);
echo '</td><td  colspan="8"></tr>';
echo '<tr><td colspan="4" style="text-align:right;">Net EMI collected '.$rdbDayStr.' : </td><td style="text-align:right;">';
//echo $Select_sql;
echo number_format($sumEMI,2);
echo '</td><td  colspan="8"></tr>';

echo '<tr><td colspan="8">';
$lnks= get_pagination_links($page,'showEMIList',$count,$Intv);
echo $lnks;
echo "</td></tr>";
?>