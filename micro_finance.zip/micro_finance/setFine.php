<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$txnID=''; $fine='';
date_default_timezone_set("Asia/Kolkata");
extract($_GET); 

$sqlLog = PHP_EOL.'-- setFine.php '.PHP_EOL;
    $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `emi_register` SET `Fine`='$fine',`mdf_dat_tim`='$upDate' WHERE `txnID`=".$txnID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
    
        $Fine ="<span id='spnFineAmt$txnID' class='text-primary'>$fine</span><a href='javascript:void(0)' onClick='edit_fine($txnID)'><i class='bi bi-pencil'></i></a>";
        
    echo $Fine;

    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>