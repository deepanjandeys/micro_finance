<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$agentId=''; $AgentName='';  $balance=0;

$sqlLog = PHP_EOL.'-- copyAgentsToLedger.php '.PHP_EOL;

$crDate=date('Y-m-d H:i:s');

$SelSql    =   "SELECT `id_gen_num` as LedgerID FROM `gen_ids` WHERE `id_code`=6";
$Recordset =   mysqli_query($db,$SelSql);
$row       =   mysqli_fetch_assoc($Recordset);
extract($row);   

$SelSql = "SELECT `agentId`, `AgentName`,`balance` FROM `agent_profile` WHERE 1";
//echo $SelSql;
$Recordset2      =   mysqli_query($db,$SelSql);
//echo '<br>No of agent '.mysqli_num_rows($Recordset2);
        while($row2            =   mysqli_fetch_assoc($Recordset2))
        {
            extract($row2);   
///////////////////// add record to ledger
$LedgerType=2;
$LedgerName=$AgentName;
//$balance=0;

$insSql="INSERT INTO `ledger_master`(`LedgerID`, `LedgerName`, `LedgerType`, `balance`,`crt_dat_time`) VALUES ($LedgerID, '$LedgerName', '$LedgerType','$balance','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
echo '<br>'.$insSql;
$updSql= "UPDATE `agent_profile` SET  `LedgerID`=$LedgerID WHERE `AgentID`=$agentId;";
$sqlLog .= $updSql.PHP_EOL;
$res1       =   mysqli_query($db,$updSql);
///////////////////// add record to agent transaction log
////////////////////////////////////////////////////////////
$SelSql     =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
$Recordset      =   mysqli_query($db,$SelSql);
$row1            =   mysqli_fetch_assoc($Recordset);
extract($row1);   
    
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";
echo '<br>'.$updSql;

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //           2 for EMI Collection, 3 Loan Giving 
    $txnType=0;
    // refType = 0 for agent Creation , 1 
    //           2 for EMI Collection , 3 Loan Giving  
    $refType=0; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$agentId','0','0','0','Openning Balance')";
echo '<br>'.$insSql;
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

        $SelSql        =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row1            =   mysqli_fetch_assoc($Recordset);
        extract($row1);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+2,`last_gen_date`='$crDate' WHERE `id_code`=11;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    
    $ledgerID_Cash=2;
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id1 = $id+1; // next Id
    $custId=0;
    ////////////////
        $SelSql        =   "SELECT `balance` as `cashBalance` FROM `ledger_master` WHERE `LedgerID`=2"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row1            =   mysqli_fetch_assoc($Recordset);
        extract($row1);   
    ////////////////////
        $cashBalance -= $balance;   // deduct cash balance

        $updSql= "UPDATE `ledger_master` SET  `balance`= $cashBalance WHERE `LedgerID`=2;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ///////////////////////////////////////////////
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$ledgerID_Cash', '$LedgerID', '$balance', '0.00', '$custId', '$cashBalance'), ('$id1', '$tid', '$LedgerID', '$ledgerID_Cash', '0.00', '$balance', '$custId', '$balance');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    

$LedgerID++;        
}

$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=$LedgerID,`last_gen_date`='$crDate' WHERE `id_code`=6;";
    $res1       =   mysqli_query($db,$updSql);

    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>