<?php 
include('includes/db.php');
@session_start();
$org_name='';

if(isset($_SESSION['org_name']))
{
  $org_name= $_SESSION['org_name'];
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php  echo $org_name;  ?> Loan Due List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<body>

    <div class="container">
        <div class="row">
            <div class="col-12">
<?php 
$LoanRegNo=''; 
if(isset($_SESSION['LoanRegNo']))
    $LoanRegNo=$_SESSION['LoanRegNo'];
if(isset($_SESSION['action']))
{

     if($_SESSION['action']=='Save')
    {
        $_SESSION['lastPage']='yes';
    }

    echo '<h2 class="bg-primary mt-3 p-3 rounded text-white">Loan '.$_SESSION['action'].' Successfully</h2>';
    echo '<button type="button" class="btn btn-primary" onclick="print_EMI('.$LoanRegNo.')" style="float:right;">Print</button>';
    echo '<span style="float:left;"> Go to <a href="loans.php" class="btn btn-warning">Loan List</a></span>';
}
?>                
            </div>
        </div>
    </div>
<?php 

date_default_timezone_set("Asia/Kolkata");
//extract($_GET); 

$CID=0; $EMIPrincipal=''; $EMIInterest=''; $EMIPayMode=''; 
$LoanDate=''; $CloseDate='';

$SelSql="SELECT `LoanRegNo`, `CustName`, `LoanType`,`GroupName`, `LoanAmt`, `BookId`, `EMIPrincipal`, `EMIInterest`, `FineAmount`, pm.`Name` as `EMIPayModeStr`, `LoanDate`, `LoanStatus`, `CloseDate` FROM `loan_register` as lr LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `payment_modes` AS pm ON lr.`EMIPayMode`=pm.`ID` LEFT JOIN `group_master` as g ON lr.`groupID`=g.`GID` WHERE `LoanRegNo`=$LoanRegNo";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);  
        if($LoanType=='1')
            $LoanType='Personal loan';
        else if($LoanType=='2')
            $LoanType='Group loan';
        else  
            $LoanType='';
        
        $LoanDate = date('d-m-Y',strtotime($LoanDate));
        $CloseDate = date('d-m-Y',strtotime($CloseDate));

        $tbls= '<h2>'.$org_name.' Loan Due List</h2>
        <div class="table-responsive">
        <table class="table table-bordered table-striped">
                        <tr>
                            <th>Loan Type</th><td>'.$LoanType.'</td>
                            <th>Group</th><td>'.$GroupName.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Amount</th><td>Rs '.number_format($LoanAmt,2).'</td>
                            <th>Fine Amount</th><td>Rs '.number_format($FineAmount,2).'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Date</th><td>'.$LoanDate.'</td>
                            <th>Close Date</th><td>'.$CloseDate.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Name</th><td>'.$CustName.'</td>
                            <th>Mode</th><td>'.$EMIPayModeStr.'&nbsp;</td>
                        </tr>
                    </table>
                    </div>
                    '; 
        }
    }

        ///////////////////////////////
            $txnID=0;

            $SelSql="SELECT `txnDateTime`, `emiNo`,`dueDate`, `EMIPrincipal`, `EMIInterest` FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo Order by `dueDate`;";
            $Recordset      =   mysqli_query($db,$SelSql);
            if(mysqli_num_rows($Recordset)>0)
            {
                $tbls.= "<table class='table table-bordered table-striped'><tr><th>EMI No.</th><th>Due Date</th><th>EMI</th></tr>";
                while($row            =   mysqli_fetch_assoc($Recordset))
                {
                    extract($row);
                    $EMI=(float)$EMIPrincipal + (float)$EMIInterest;
                    $EMI=number_format($EMI,2);
                    $dueDate=date('d-M-Y',strtotime($dueDate));
                  $tbls .=  "<tr><td>$emiNo</td><td>$dueDate</td>
                    <td>Rs $EMI</td>
                    </tr>";
                }

                $tbls.= '</table>';
            }
            else  
            {
                $tbls.= 'Nothing found';
            }

?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <?php echo $tbls; ?>
        </div>
    </div>
</div>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<script type="text/javascript">
    
function print_EMI(LoanRegNo)
{
  window.open('printEMI_List.php?LoanRegNo='+LoanRegNo);
}
</script>
  </body>
</html>
