<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
</aside><!-- End Sidebar-->

<?php 
$LoanRegNo=''; $CustName=''; $LoanAmt=''; $BookId=''; $EMIPrincipal='';
$EMIInterest=''; $FineAmount='' ; $EMIPayMode='';       $LoanDate='';
$LoanStatus='0';  $CloseDate=''; $CID=''; $GID='';  $groupID=''; $LoanType='';
$GroupName ='';   $EMIPayModeStr ='';

$Action="Add new";
$ActionButton="Save";
if(isset($_GET['LoanRegNo']))
{
$LoanRegNo=(int)$_GET['LoanRegNo'];

 $SelSql="SELECT `LoanRegNo`,lr.`CID`,`groupID`, `CustName`, `LoanType`,`GroupName`, `LoanAmt`, `BookId`, `EMIPrincipal`, `EMIInterest`, `FineAmount`,`EMIPayMode` , pm.`Name` as `EMIPayModeStr`, `LoanDate`, `LoanStatus`, `CloseDate` FROM `loan_register` as lr LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `payment_modes` AS pm ON lr.`EMIPayMode`=pm.`ID` LEFT JOIN `group_master` as g ON lr.`groupID`=g.`GID` WHERE `LoanRegNo`=$LoanRegNo";
      $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";

        $LoanDate = date('d-m-Y',strtotime($LoanDate));
        $CloseDate = date('d-m-Y',strtotime($CloseDate)); 
    }
  if($groupID=='0')
    $groupID='';
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Loan</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Loan</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Loan <?php echo $Action; ?></h5>
              <!-- Horizontal Form -->
        <form action="saveLoan.php" method="post" onsubmit="return form_validation();">
          <?php 
$PL='';
$GL='';
?>

<input type="hidden" name="LoanRegNo" value="<?php echo $LoanRegNo; ?>">
<?php 

  $agentId='1';
  $whereClausCustomer='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $whereClausCustomer=" and `agentId`=$agentId";
    }
}

$Select_sql ="SELECT `CID`, `CustName` FROM `customer_profile` WHERE 1 $whereClausCustomer";
$result = mysqli_query($db,$Select_sql);
$selCustomers='There is no Customer';
if(mysqli_num_rows($result)>0)
{
$selCustomers=<<<select_Customers
<select id="selCust"  name="CID" style="width:200px;" required>
  <option value=''>Select Customer</option>
select_Customers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['CID'];
    $Name=$row['CustName'];
    
$selCustomers.=<<<select_Customers
<option value='$Code'>$Name</option>
select_Customers;
  } 
$selCustomers.=<<<select_Customers
</select> 
select_Customers;
}

     $SelSql= "SELECT `balance`  FROM `agent_profile` as a join `ledger_master` as l ON a.`LedgerID`=l.`LedgerID` WHERE `AgentId`=$agentId";
     //echo $SelSql;
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
        echo '<h6 class="text-primary">Your Balance is <span class="text-danger" id="spnBalance">Rs '.$balance.'</span></h6>';

?>
<div class="row mb-3">
            <label for="CID" class="col-sm-2 col-form-label">Customer Id</label>
                  <div class="col-sm-4">

             <?php echo $selCustomers; ?>
                  </div>
                  
<?php 
  $Select_sql ="SELECT `GID`, `GroupName` FROM `group_master`  WHERE 1 $whereClausCustomer";
  $result = mysqli_query($db,$Select_sql);
  $selGroups='There is no Group';
  if(mysqli_num_rows($result)>0)
  {
$selGroups=<<<select_Groups
<select id="selGroup" name='GID' onChange='selGroup_Change(this.value)' class="from-control" style="width:200px;">
  <option value="">Select Group</option>
select_Groups;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['GID'];
    $Name=$row['GroupName'];
    
$selGroups.=<<<select_Groups
<option value='$Code'>$Name</option>
select_Groups;
  } 
$selGroups.=<<<select_Groups
</select> 
select_Groups;
}
?>
            <label for="GID" class="col-sm-2 col-form-label">Group Id</label>
                  <div class="col-sm-4">
                     <?php echo $selGroups; ?>
                  </div>
                  <div class="col-sm-4">
  
    </div>
  
</div>
<!--  //////// -->
 
<div class="row mb-3">
  <div class="col-sm-2">
    Loan Type
  </div>
  <div class="col-sm-2">
     <div class="form-check">
            <input class="form-check-input" type="radio" name="LoanType" id="LoanType1" value="1" <?php echo $PL; ?> checked required>
            <label class="form-check-label" for="LoanType1">
                        Personal Loan
            </label>
          </div>

        </div>

    <div class="col-sm-2">
          <div class="form-check">
              <input class="form-check-input" type="radio" name="LoanType" id="LoanType2" value="2" <?php echo $GL; ?> required>
            <label class="form-check-label" for="LoanType2">
                        Group Loan
            </label>
        </div>
    </div>
</div>
<!---- -->
                <div class="row mb-3">
                  <label for="LoanAmt" class="col-sm-2 col-form-label">Loan Amount</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" id="LoanAmt" name="LoanAmt" value="<?php echo $LoanAmt; ?>" onChange="LoanDate_Change()" required>
                  </div>
                  <label for="BookId" class="col-sm-2 col-form-label">Book ID</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" id="BookId" name="BookId" value="<?php echo $BookId; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="EMIPrincipal" class="col-sm-2 col-form-label">EMIPrincipal</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="EMIPrincipal" id="EMIPrincipal" value="<?php echo $EMIPrincipal;?>" onkeyup="calcuTotal()" onChange="LoanDate_Change()" required>
                  </div>
                  <label for="EMIInterest" class="col-sm-2 col-form-label">EMI Interest</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="EMIInterest" id="EMIInterest" onkeyup="calcuTotal()" value="<?php echo $EMIInterest;?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="EMITotal" class="col-sm-2 col-form-label">EMI Total</label>
                  <div class="col-sm-4">
                    <input type="text" class="form-control" name="EMITotal" id="EMITotal" readonly>
                  </div>
                  <label for="FineAmount" class="col-sm-2 col-form-label">Fine Amount</label>
                  <div class="col-sm-4">
                    <input type="number" class="form-control" name="FineAmount" id="FineAmount" value="<?php echo $FineAmount;?>" required>
                  </div>
                </div>
<?php 
$Select_sql ="SELECT `ID`, `Name` FROM `payment_modes` WHERE `ID`>0";
$result = mysqli_query($db,$Select_sql);
$selCustomers='There is no Payment Mode';
if(mysqli_num_rows($result)>0)
{
$chekedStr='';
$selEMIPayMode=<<<select_EMIPayMode
select_EMIPayMode;
while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['ID'];
    $Name=$row['Name'];
    
    if($Code==$EMIPayMode)
      $chekedStr='checked';
    else  
      $chekedStr='';
$selEMIPayMode.=<<<select_EMIPayMode
<div class="form-check">
    <input class="form-check-input" type="radio" name="EMIPayMode" id="EMIPayMode$Code" value="$Code" $chekedStr onChange="LoanDate_Change()" required>
    <label class="form-check-label" for="EMIPayMode$Code">
      $Name
    </label>
  </div>
select_EMIPayMode;
  } 
}
?>
                 <div class="row mb-3">
                  <label for="EMIPayMode3" class="col-sm-2 col-form-label">EMI Pay Mode</label>
                  <div class="col-sm-4">
                     <?php echo $selEMIPayMode; ?>
                  </div>
                  
                <?php 
                $IA=''; $A=''; 
                if($LoanStatus=='1')
                  $A='checked';
                else if($LoanStatus=='2')
                  $IA='checked';
                else  
                  $A='checked';
                ?>
                <legend class="col-form-label col-sm-2 pt-0">Loan Status</legend>
                  <div class="col-sm-4">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="LoanStatus" id="LoanStatus2" value="2" <?php echo $IA; ?> required>
                      <label class="form-check-label" for="LoanStatus2">
                        In Active
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="LoanStatus" id="LoanStatus1" value="1" <?php echo $A; ?> required>
                      <label class="form-check-label" for="LoanStatus1">
                        Active
                      </label>
                    </div>
                    <div class="form-check ">
                      <label class="form-check-label" id="lblPeriod">
                        
                      </label>
                    </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="LoanDate" class="col-sm-2 col-form-label">Loan Date</label>
                  <div class="col-sm-4">
                    <input type="text" id="LoanDate" name="LoanDate" onchange="LoanDate_Change()" class="form-control" value="<?php echo $LoanDate; ?>" placeholder="dd-mm-yyyy"  required>
                    
                  </div>
                  <label for="CloseDate" class="col-sm-2 col-form-label">Close Date</label>
                  <div class="col-sm-4">
                    <input type="text" name="CloseDate" id="CloseDate"  onChange="CloseDate_Change()" class="form-control" value="<?php echo $CloseDate; ?>" placeholder="dd-mm-yyyy"  required>
                   
                  </div>
                </div>
                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
      <div style="height:100px;"></div>
<a class='btn' onClick='recreateEMI(<?php echo $LoanRegNo; ?>)' href='javascript:void(0)'><i class="bi bi-arrow-counterclockwise"></i></a><span id='spnLoanEMI_Creatlist<?php echo $LoanRegNo; ?>'></span>

<?php
$s2='<!-- Modal Dialog Scrollable -->
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalDialogScrollable'.$LoanRegNo.'" onClick="showEMI_List('.$LoanRegNo.')">
                EMI List
              </button>
              <div class="modal fade" id="modalDialogScrollable'.$LoanRegNo.'" tabindex="-1">
                <div class="modal-dialog modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">EMI List of Loan #'.$LoanRegNo.'</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <table class="table">
                        <tr>
                            <th>Loan Type<th><td>'.$LoanType.'</td>
                            <th>Group</th><td>'.$GroupName.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Amount<th><td>'.$LoanAmt.'</td>
                            <th>Fine Amount</th><td>'.$FineAmount.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Date<th><td>'.$LoanDate.'</td>
                            <th>Close Date</th><td>'.$CloseDate.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Name<th><td>'.$CustName.'</td>
                            <th>Mode</th><td>'.$EMIPayModeStr.'&nbsp;</td>
                        </tr>
                    </table>
                    <div class="modal-body" id="EMI_list'.$LoanRegNo.'">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary" onclick="print_EMI('.$LoanRegNo.')">Print</button>
                    </div>
                  </div>
                </div>
              </div><!-- End Modal Dialog Scrollable-->
';

echo $s2;
?>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  
 $(document).ready(function(){
            $('#selCust').select2();
            $('#selGroup').select2();           
        });

function calcuTotal()
  {
    var P= parseFloat($('#EMIPrincipal').val());

    if(isNaN(P))
      P=0;

    var I= parseFloat($('#EMIInterest').val());

    if(isNaN(I))
      I=0;
    var T=P+I;
    $('#EMITotal').val(T.toFixed(2));
  }
calcuTotal();

function LoanDate_Change()
{
  //console.log(loanDate);

  var loanDate =$('#LoanDate').val();

  var L= parseFloat($('#LoanAmt').val());
    if(isNaN(L))
      L=0;
  var P= parseFloat($('#EMIPrincipal').val());
    if(isNaN(P))
      P=0;

var period = 100;

  if(L>0 && P>0)
  {
    period = Math.round(L/P);
  }
var periods = 'Period is '+period + ' Day(s)';
var someDate = new Date();

if(loanDate !='')
{
  var loanDateParts = loanDate.split("-");
  if(loanDateParts.length==3)
  {
    loanDate = loanDateParts[2]+'-'+loanDateParts[1]+'-'+loanDateParts[0];
    someDate = new Date(loanDate);
  }
}

var result ='';

if($('#EMIPayMode1').is(':checked'))
{//////// Day
    result =new Date(someDate.setDate(someDate.getDate() + period));
    periods = 'Period is '+period + ' Day(s)';
}
else if($('#EMIPayMode2').is(':checked'))
{/////// week
    result =new Date(someDate.setDate(someDate.getDate() + period*7));
    periods='Period is '+period + ' Week(s) ';
}
else if($('#EMIPayMode3').is(':checked'))
{//////////// Month
    result =new Date(someDate.setMonth(someDate.getMonth() + period));
    periods = 'Period is '+period + ' Month(s) ';
}
else  
{
  /////// if nothing selected, then by default Days
  result =new Date(someDate.setDate(someDate.getDate() + period));  
  periods = 'Period is '+period + ' Day(s)';
}

//console.log(result);
var s=result.getDate().toString().padStart(2, '0')+'-'+(result.getMonth()+1).toString().padStart(2, '0')+'-'+result.getFullYear();

if(loanDate !='')
{
  $('#CloseDate').val(s);
}


$('#lblPeriod').html(periods);
}


function form_validation()
{
var msg='';
  if($('#selAgent').val()=='')
  {
    msg +='Select an Agent<br>';
  }
  if($('#selCust').val()=='')
  {
    msg +='Select a Customer<br>';
  }

var groupID=$('#selGroup').val() ;

  if($('#LoanType1').is(':checked'))
  {
 if(groupID == undefined)
  groupID='';
   
    if(groupID !='')
    {
      msg +='Deselect Group form Group List, mean Chose <span class="bg-success text-light font-weight-bold px-2"> Select Group </span>Option from Group List<br>';
    }

  }
  else if($('#LoanType2').is(':checked'))
  {
    if(groupID=='')
    {
      msg +='Select a Group<br>';
    }
    else if(groupID==undefined)
    {
      msg+='There is no Group Under this agent, select Personal loan only<br>';  
    }
  }
var Balance=parseFloat($('#spnBalance').html().substring(3));
var LoanAmt=parseFloat($('#LoanAmt').val());
if(LoanAmt>Balance)
  msg +='<br>Loan Amount must be less than Agent Balance';

  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}


$('#LoanDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#CloseDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

<?php  
if($ActionButton=='Save')
{
?>
$('#LoanDate').val('');
$('#CloseDate').val('');
<?php  
}
else 
{
?>
$('#selCust').val(<?php echo $CID;?>);
$('#selGroup').val(<?php echo $groupID;?>);
<?php 
}
?>
function selGroup_Change(groupID)
{
  if(groupID!='')
    $('#LoanType2').attr('checked',true);
  else 
   $('#LoanType2').attr('checked',false);    
}

</script>
<?php 
include('end_html.php');
?>
