<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
</aside><!-- End Sidebar-->
<?php 
$LedgerType=''; $LedgerName=''; $LedgerID ='0';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['LedgerID']))
{
$LedgerID=(int)$_GET['LedgerID'];
 $SelSql="SELECT  `LedgerID`, `LedgerName`,`LedgerType` FROM `Ledger_master` WHERE `LedgerID`=$LedgerID";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Ledger</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Ledger</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Ledger <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveLedger.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="LedgerID" value="<?php echo $LedgerID; ?>">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Ledger Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="LedgerName" name="LedgerName" value="<?php echo $LedgerName; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Ledger Type</label>
                  <div class="col-sm-10">
                    <?php 
$Select_sql ="SELECT `Id`, `Name` FROM `ledger_types`";

$result = mysqli_query($db,$Select_sql);
$selLedgerTypes='There is no LedgerType ';

if(mysqli_num_rows($result)>0)
{
$selLedgerTypes=<<<Select_LedgerTypes
<input class="form-control" 
            list="LedgerTypeOptions" name='LedgerType' id='LedgerType'  
            placeholder="Select LedgerType " value="$LedgerType" onchange='LedgerType_Change()' autocomplete="off" required> 
        <datalist id="LedgerTypeOptions"> 
Select_LedgerTypes;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Id'];
    $Name=$row['Name'];
    
$selLedgerTypes.=<<<Select_LedgerTypes
<option value='$Code'>$Name</option>
Select_LedgerTypes;
  } 
$selLedgerTypes.=<<<Select_LedgerTypes
</datalist> 
Select_LedgerTypes;
}
echo $selLedgerTypes;
?>
<span id="spnLedgerTypeName"></span>
                  </div>
                </div>
              
                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
function LedgerType_Change() {
    var val = document.getElementById("LedgerType").value;
    var opts = document.getElementById('LedgerTypeOptions').children;
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].value === val) {
        // An item was selected from the list!
        // yourCallbackHere()
        $('#spnLedgerTypeName').html(opts[i].text);
        //console.log(opts[i].text);
        break;
      }
    }
  }
LedgerType_Change();
</script>

<?php 
include('end_html.php');
?>
