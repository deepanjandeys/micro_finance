<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$page=0;

    $CID='';            $agent='';          $loan_opr='';       $Loan_Amount=""; 
    $EMIPrinci_opr='';  $EMI_Principal='';  $EMIInterst_opr=''; $EMIInterest='';
    $FineAmount_opr=''; $Fine_Amount='';    $PaymentMode='';    
    $EMI_DueDateFrom='';$EMI_DueDateTo='';  

extract($_GET);

$CIDStr='';
if($CID<>'')
{
    $CIDStr=" and  lr.`CID`=$CID";
}

$agentStr='';
if($agent<>'')
{
    $agentStr=" and a.agentID =".$agent." ";
}

$EMI_PrincipalStr='';

if($EMI_Principal<>'')
{
    $EMI_PrincipalStr=" and e.EMIPrincipal $EMIPrinci_opr ".$EMI_Principal." ";
}

$EMIInterestStr='';
if($EMIInterest<>'')
{
    $EMIInterestStr=" and e.EMIInterest $EMIInterst_opr ".$EMIInterest." ";
}

$Fine_AmountStr='';
if($Fine_Amount<>'')
{
    $Fine_AmountStr=" and e.Fine $FineAmount_opr ".$Fine_Amount." ";
}

$PaymentModeStr='';
if($PaymentMode<>'')
{
    $PaymentModeStr=" and e.EMIPayMode =".$PaymentMode;
}


$Loan_AmountStr='';

if($Loan_Amount<>'')
{
    $Loan_AmountStr=" and lr.`LoanAmt` $loan_opr ".$Loan_Amount." ";
}

date_default_timezone_set("Asia/Kolkata");


$EMI_DueDateStr='';
if($EMI_DueDateFrom<>'' && $EMI_DueDateTo<>'')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateTo =date('Y-m-d',strtotime($EMI_DueDateTo));

    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateTo."'";
}
else if($EMI_DueDateFrom<>'')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateFrom."'";
}


if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;

if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT e.`txnID`, e.`txnDateTime`, e.`dueDate`, e.`EMIPrincipal`, e.`EMIInterest`, e.`Fine`, e.`LoanRegNo`, a.`AgentName`, e.`EMIPayMode`, e.`Remarks`, cp.`CustName`,lr.`LoanAmt` FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` WHERE 1 $CIDStr $agentStr $EMI_PrincipalStr $EMIInterestStr $Fine_AmountStr $PaymentModeStr $EMI_DueDateStr Order By e.`txnID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        if($EMIPayMode=='1')
            $EMIPayModeStr='Daily';
        else if($EMIPayMode=='2')
            $EMIPayModeStr="Weekly";
        else if ($EMIPayMode=='3')
            $EMIPayModeStr="Monthly";
        if($txnDateTime !='')
            $txnDateTime = date('d-m-Y',strtotime($txnDateTime));
        $dueDate = date('d-m-Y',strtotime($dueDate));
        echo "<tr>
                    <th scope='row'><a href='emi_edit.php?txnID=$txnID'>Edit</a>
                    </th>
                    <td>$txnID</td>
                    <td>$txnDateTime</td>
                    <td>$dueDate</td>
                    <td>$EMIPrincipal</td>
                    <td>$EMIInterest</td>
                    <td>$Fine</td>
                    <td>$EMIPayModeStr</td>
                    <td>$AgentName</td>
                    <td>$CustName</td>
                    <td>$LoanRegNo</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(e.`txnID`) as C FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` WHERE 1 $CIDStr $agentStr $EMI_PrincipalStr $EMIInterestStr $Fine_AmountStr $PaymentModeStr $EMI_DueDateStr";

echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];

$lnks= get_pagination_links($page,'showEMIList',$count,$Intv);
echo $lnks;
echo "</td></tr>";
?>