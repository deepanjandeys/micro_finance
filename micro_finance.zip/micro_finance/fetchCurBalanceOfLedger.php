<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');
$ledgerId='';  $Balance=0;
extract($_GET);

        $SelSql  =   "SELECT l.`Balance` FROM  `ledger_master` as l WHERE `ledgerId`=$ledgerId";
        //echo $SelSql;
        $Recordset      =   mysqli_query($db,$SelSql);
        if(mysqli_num_rows($Recordset)>0)
         {
                $row =   mysqli_fetch_assoc($Recordset);
                extract($row);   
         }
        echo $Balance;    
?>