<?php 
include('headers.php');   
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
  <?php
  @session_start();
  ?>
  <header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
      <hr/>
      <?php  
    $UID=0;
    $balance=0;

  if(isset($_SESSION['isAdmin']))
    {
      if($_SESSION['isAdmin']=='0')
      {
        $UID=$_SESSION['UID'];

     $SelSql= "SELECT `balance`  FROM `agent_profile` as a join `ledger_master` as l ON a.`LedgerID`=l.`LedgerID` WHERE `AgentId`=$UID";
     //echo $SelSql;
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
        echo '<h3 class="text-primary">Your Balance is <span class="text-danger">Rs '.$balance.'</span></h3>';
        echo '<a href="emiCollections.php" class="btn btn-success">EMI Collection </a>&nbsp; &nbsp; &nbsp;';
        echo '<a href="emiCollected.php" class="btn btn-secondary">Collected EMI</a>';

        }
    
    }
      ?>
    </div><!-- End Page Title -->


  </main><!-- End #main -->
<?php 
include('footers.php');
?>

<?php 
include('end_html.php');
?>
