<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$CID=''; $CustName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $agentId=''; $cityId=''; 
$sex='';  $dob='';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['CID']))
{
$CID=(int)$_GET['CID'];
 $SelSql="SELECT `CID`, `CustName`, `Address`, `mobileNo`, `IDProof`, `addressProof`, `IDProofLink`, `addressProofLink`, `photoLink`, `agentId`, `cityId`, `sex`, `dob` FROM `customer_profile` WHERE `CID`=$CID";
              $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Customer</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Customer</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Customer <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveCustomer.php" method="post" enctype="multipart/form-data" onsubmit="return form_validation();">
                <input type="hidden" name="CID" value="<?php echo $CID; ?>">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Customer Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="CustName" name="CustName" value="<?php echo $CustName; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Mobile</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" id="mobileNo" name="mobileNo" value="<?php echo $mobileNo; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputPassword3" class="col-sm-2 col-form-label">Address</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" name="Address" id="Address" required><?php echo $Address;?></textarea>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">ID Proof</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="IDProof" name="IDProof" value="<?php echo $IDProof; ?>">
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">ID Proof Link</label>
                  <div class="col-sm-4">
                    <input type="hidden" name="hdIDProofLink" value="<?php echo $IDProofLink; ?>">
                    <input class="form-control" type="file"  id="IDProofLink" name="IDProofLink" required>
                  </div>
                  <div class="col-sm-6"><?php if($IDProofLink!=''){
                    if(file_exists("uploads/IDProofLink/".$IDProofLink))
                    {
                    $extension = strtolower(pathinfo($IDProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/IDProofLink/$IDProofLink' alt='uploads/IDProofLink/$IDProofLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      else if($extension=='pdf')
                      {
                      echo  '<object data= 
"uploads/IDProofLink/'.$IDProofLink.'" 
                width="100"
                height="100"> 
        </object> ';
                      }
                      echo '<a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">ID Proof link Preview</a>';
                    
                    }
                  } ?></div>
                </div>
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Address Proof</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="addressProof" name="addressProof" value="<?php echo $addressProof; ?>">
                  </div>
                </div>

               <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Address Proof Link</label>
                  <div class="col-sm-4">
                    <input type="hidden" name="hdaddressProofLink" value="<?php echo $addressProofLink; ?>">
                    <input class="form-control" type="file"  id="addressProofLink" name="addressProofLink" required>
                  </div>
                  <div class="col-sm-6"><?php if($addressProofLink!=''){
                    if(file_exists("uploads/addressProofLink/".$addressProofLink))
                    {

                      $extension = strtolower(pathinfo($addressProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/addressProofLink/$addressProofLink' alt='uploads/addressProofLink/$addressProofLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      else if($extension=='pdf')
                      {
                      echo  '<object data= 
                    "uploads/addressProofLink/'.$addressProofLink.'" 
                    width="100"
                    height="100"> 
                      </object> ';
                      }
                      echo '<a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">Address Proof link Preview</a>';
                    }
                  } ?></div>
                </div>

                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Photo Link</label>
                  <div class="col-sm-4">

                    <input type="hidden" name="hdphotoLink" value="<?php echo $photoLink; ?>">
                    <input class="form-control" type="file"  id="photoLink" name="photoLink" required>
                  </div>
                  <div class="col-sm-6"><?php if($photoLink!=''){
                    if(file_exists("uploads/photoLink/".$photoLink))
                    {

                      $extension = strtolower(pathinfo($photoLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/photoLink/$photoLink' alt='uploads/photoLink/$photoLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      
                      echo '<a href="uploads/photoLink/'.$photoLink.'" target="_blank">photo link Preview</a>';
                    }
                  } ?>
                </div>
                </div>
<?php 


$agentIdReadOnly='';
$whereClausCustomer='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $agentIdReadOnly='readonly';
      $whereClausCustomer=" and `agentId`=$agentId";
    }
    else 
    {
      $agentIdReadOnly='required';
    } 
}

$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile` WHERE 1  $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{

$selAgents=<<<Select_Agents
<select id="selAgent" name='agentId' class="from-control" style="width:200px;">
Select_Agents;


if($whereClausCustomer =='')
{
$selAgents.=<<<Select_Agents
  <option value=''>Select Agent</option>
Select_Agents;
}

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}
?>
<div class="row mb-3">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Agent Id</label>
                  <div class="col-sm-4">
                    <?php echo $selAgents; ?>
                  </div>
                  <div class="col-sm-6">
                    <span id='spnAgentname'>
                   
                  </span>
      </div>
</div>
<?php 
$Select_sql ="SELECT `Sl`, `City_Name` FROM `city_master` where `State_Sl`=18;";

$result = mysqli_query($db,$Select_sql);

$selCities='There is no City ';

if(mysqli_num_rows($result)>0)
{
$selCities=<<<select_Cities
<select id="selCity" name='cityId' class="from-control" style="width:200px;">
  <option value="">Select City</option>
select_Cities;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['City_Name'];
    
$selCities.=<<<select_Cities
<option value='$Code'>$Name</option>
select_Cities;
  } 
$selCities.=<<<select_Cities
</select> 
select_Cities;
}
?>
                <div class="row mb-3">
                  <label for="cityId" class="col-sm-2 col-form-label">City Id</label>
                  <div class="col-sm-4">
                     <?php echo $selCities; ?>
                  </div>
                  <div class="col-sm-6">
                    <span id='spnCity_Name'>
                    </span>
                  </div>
                </div>
                <?php 
                $m=''; $f=''; $o='';
                if($sex=='1')
                  $m='checked';
                else if($sex=='2')
                  $f='checked';
                else if($sex=='3')
                  $o='checked';
                ?>
                
                <fieldset class="row mb-3">
                  <legend class="col-form-label col-sm-2 pt-0">Sex</legend>
                  <div class="col-sm-6 mx-3">
                    <div class="row">
                    <div class="form-check col-4">
                      <input class="form-check-input" type="radio" name="sex" id="sex1" value="1" <?php echo $m; ?> required>
                      <label class="form-check-label" for="sex1">
                        Male
                      </label>
                    </div>
                    <div class="form-check col-4">
                      <input class="form-check-input" type="radio" name="sex" id="sex2" value="2" <?php echo $f; ?> required>
                      <label class="form-check-label" for="sex2">
                        Female
                      </label>
                    </div>
                    <div class="form-check col-4">
                      <input class="form-check-input" type="radio" name="sex" id="sex3" value="3" <?php echo $o; ?> required>
                      <label class="form-check-label" for="sex3">
                        Other
                      </label>
                    </div>  
                    </div>
                    
                  </div>
                </fieldset>
                <div class="row mb-3 d-none">
                  <div class="col-sm-8 offset-sm-2">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" id="gridCheck1">
                      <label class="form-check-label" for="gridCheck1">
                        Example checkbox
                      </label>
                    </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="dob" class="col-sm-2 col-form-label">Date of Birth</label>
                  <div class="col-sm-4">
                    <input type="text" name="dob" id="dob" class="form-control" value="<?php  if($dob!='') echo date('d-m-Y',strtotime($dob));  ?>" placeholder="dd-mm-yyyy" required>
                  </div>
                </div>
                <div class="text-center">
                  
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  
 $(document).ready(function(){
            $('#selCity').select2();
            $('#selAgent').select2();
        });
function form_validation()
{
var msg='';
  if($('#selAgent').val()=='')
  {
    msg +='Select an Agent<br>';
  }
  if($('#selCity').val()=='')
  {
    msg +='Select a City<br>';
  }

  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}


$('#dob').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

<?php  
if($ActionButton=='Save')
{
?>
$('#dob').val('');
<?php  
}
else 
{
?>
$('#selAgent').val(<?php echo $agentId;?>);
$('#selCity').val(<?php echo $cityId;?>);
<?php 
}
?>
</script>

<?php 
include('end_html.php');
?>
