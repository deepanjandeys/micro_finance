<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$ID='';    $name='';   
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and City_Name like '%".$name."%' ";
}


$State_SlStr='';
if($State_Sl<>'')
{
    $State_SlStr=" and State_Sl ='".$State_Sl."' ";
}

if(isset($_COOKIE['pgSizeC']))
    $Intv=(int)$_COOKIE['pgSizeC'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT c.`Sl` as `ID`, `City_Name` as `Name`, `State_Name` from `city_master` as c JOIN `state_master` as s ON c.`State_Sl`=s.`Sl` WHERE 1 $nameStr $State_SlStr Order By c.`Sl` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        echo "<tr>
                    <th scope='row'><a href='city_edit.php?ID=$ID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_city($ID)'>Delete</a></th>
                    <td>$ID</td>
                    <td>$Name</td>
                    <td>$State_Name</td>
                    <td></td>
                  </tr>";
         
        }
    } 
         
$Select_sql = "SELECT count(`Sl`) as C  FROM `city_master` WHERE 1 $nameStr $State_SlStr";
//echo $SelSql;
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    
$lnks= get_pagination_links($page,'showCitiList',$count,$Intv);

echo $lnks;

echo "</td></tr>";
?>