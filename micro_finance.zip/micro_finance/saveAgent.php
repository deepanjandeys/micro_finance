<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$AID=''; $AgentName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $agentId=''; $cityId=''; 
$sex='';  $dob=''; $password=''; $balance=0;

date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$JoiningDate = date('Y-m-d',strtotime($JoiningDate));

$balance=(float)$balance;
$password=password_hash($password, PASSWORD_DEFAULT);

$sqlLog = PHP_EOL.'-- saveAgent.php '.PHP_EOL;
$IDProofLinkFilename='';
            if(($_FILES['IDProofLink']['error']==0))
            {       
                $path="IDProofLink";
                $file = basename($_FILES['IDProofLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $IDProofLinkFilename=substr($file,0,$pos);
                $IDProofLinkFilename =$IDProofLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["IDProofLink"]["tmp_name"],'./uploads/'.$path.'/'.$IDProofLinkFilename);

                if($hdIDProofLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdIDProofLink))
                    {
                    unlink("uploads/".$path."/".$hdIDProofLink);
                    }
                }

                }
                else
                {
                    $IDProofLinkFilename="";
                }
                
            }
            else
            {
            $IDProofLinkFilename=$hdIDProofLink;  
            }

$addressProofLinkFilename='';
            if(($_FILES['addressProofLink']['error']==0))
            {       
                $path="addressProofLink";
                $file = basename($_FILES['addressProofLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $addressProofLinkFilename=substr($file,0,$pos);
                $addressProofLinkFilename =$addressProofLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["addressProofLink"]["tmp_name"],'./uploads/'.$path.'/'.$addressProofLinkFilename);

                if($hdaddressProofLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdaddressProofLink))
                    {
                    unlink("uploads/".$path."/".$hdaddressProofLink);
                    }
                }

                }
                else
                {
                    $addressProofLinkFilename="";
                }
                
            }
            else
            {
            $addressProofLinkFilename=$hdaddressProofLink;  
            }

$photoLinkFilename='';
            if(($_FILES['photoLink']['error']==0))
            {       
                $path="photoLink";
                $file = basename($_FILES['photoLink']['name']);
                $pos = strrpos($file, ".");
                $ext=strtoupper(substr($file,$pos+1));
                $photoLinkFilename=substr($file,0,$pos);
                $photoLinkFilename =$photoLinkFilename.date('Ymdhis').".".$ext;
                
                if($ext=="GIF" || $ext=="JPG" || $ext=="JPEG" || $ext=="PNG" || $ext=="PDF")
                {
                move_uploaded_file($_FILES["photoLink"]["tmp_name"],'./uploads/'.$path.'/'.$photoLinkFilename);
              if($hdphotoLink !='')
                {
                    if(file_exists("uploads/".$path."/".$hdphotoLink))
                    {
                    unlink("uploads/".$path."/".$hdphotoLink);
                    }
                }

                }
                else
                {
                    $photoLinkFilename="";
                }
                
            }
            else
            {
            $photoLinkFilename=$hdphotoLink;  
            //echo '1.2 '.$hdphotoLink;
            }
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');

        $SelSql        =   "SELECT `id_gen_num` as AID FROM `gen_ids` WHERE `id_code`=2";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=2;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);

            $insSql="INSERT INTO `agent_profile`(`AgentID`, `AgentName`,`password`, `Address`, `mobileNo`, `IDProof`, `addressProof`, `IDProofLink`, `addressProofLink`, `photoLink`, `cityId`,`JoiningDate`) VALUES ('$AID','$AgentName','$password','$Address','$mobileNo','$IDProof','$addressProof','$IDProofLinkFilename','$addressProofLinkFilename','$photoLinkFilename','$cityId','$JoiningDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            $errNo= mysqli_errno($db);
            if($errNo==1062)
            {

                $_SESSION['AgentName']      = $AgentName;
                $_SESSION['Address']        = $Address;
                $_SESSION['mobileNo']       = $mobileNo;
                $_SESSION['IDProof']        = $IDProof;
                $_SESSION['addressProof']   = $addressProof;
                $_SESSION['IDProofLink']    = $IDProofLinkFilename;
                $_SESSION['addressProofLink']=$addressProofLinkFilename;
                $_SESSION['photoLink']      = $photoLink;
                $_SESSION['password']       = $password;
                $_SESSION['cityId']         = $cityId;
                $_SESSION['sex']            = $sex;
                $_SESSION['JoiningDate']    = $JoiningDate;
                $_SESSION['balance']        = $balance;

                $_SESSION['error_message']="<span class='text-danger font-weight-bold'>This $mobileNo mobile number is use by another agent, try with another mobile no.</span>";
                header('location:agent_edit.php'); 
                die();
            }

///////////////////// add record to ledger

$SelSql   =   "SELECT `id_gen_num` as LedgerID FROM `gen_ids` WHERE `id_code`=6";
$Recordset  =   mysqli_query($db,$SelSql);
$row       =   mysqli_fetch_assoc($Recordset);
extract($row);   
    
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=6;";
    $res1       =   mysqli_query($db,$updSql);
$LedgerType=2;
$LedgerName=$AgentName;

$insSql="INSERT INTO `ledger_master`(`LedgerID`, `LedgerName`, `LedgerType`, `balance`,`crt_dat_time`) VALUES ($LedgerID, '$LedgerName', '$LedgerType','$balance','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    

$updSql= "UPDATE `agent_profile` SET  `LedgerID`=$LedgerID WHERE `AgentID`=$AID;";
$sqlLog .= $updSql.PHP_EOL;
$res1       =   mysqli_query($db,$updSql);
///////////////////// add record to agent transaction log
////////////////////////////////////////////////////////////
        $SelSql        =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //           2 for Withdraw  , 3 Loan Giving , 4 EMI Collection
    $txnType=0;
    // vouType = 0 for agent  , 1 
    //         
    $vouType=0; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$AID','$vouType','0','$txnType','Openning Balance')";

            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

        $SelSql        =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+2,`last_gen_date`='$crDate' WHERE `id_code`=11;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    
    $ledgerID_Cash=2;
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id1 = $id+1; // next Id
    $custId=0;
    ////////////////
        $SelSql        =   "SELECT `balance` as `cashBalance` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_Cash"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $cashBalance -= $balance;   // deduct cash balance

        $updSql= "UPDATE `ledger_master` SET  `balance`= $cashBalance WHERE `LedgerID`=$ledgerID_Cash;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ///////////////////////////////////////////////
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$ledgerID_Cash', '$LedgerID', '$balance', '0.00', '$custId', '$cashBalance'), ('$id1', '$tid', '$LedgerID', '$ledgerID_Cash', '0.00', '$balance', '$custId', '$balance');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
        
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `agent_profile` SET `AgentName`='$AgentName',`password`='$password',`Address`='$Address',`mobileNo`='$mobileNo',`IDProof`='$IDProof',`addressProof`='$addressProof',`IDProofLink`='$IDProofLinkFilename',`addressProofLink`='$addressProofLinkFilename',`photoLink`='$photoLinkFilename', `cityId`='$cityId', `JoiningDate`='$JoiningDate' WHERE `AgentID`=".$AID;
//echo $updSql;
//die();
    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:agent_edit.php'); 
    }
    else 
    {
        $_SESSION['action']     = $action;
        $_SESSION['AgentName']  = $AgentName;
        header('location:agentSuccess.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>