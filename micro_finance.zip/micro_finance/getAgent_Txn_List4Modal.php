<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');

date_default_timezone_set("Asia/Kolkata");

$AID=0; 
extract($_GET); 

        ///////////////////////////////
            $txnID=0;

            $SelSql="SELECT l.`tid`,l.`tdate`, t.`name` as `txnTypeStr`, lt.`debit`,lt.`credit`, lt.`balance`, l.`remarks` FROM `ledger` as l join `ledgertran` as lt ON l.`tid`=lt.`tid` join `agent_profile` as a ON a.`LedgerID`=lt.`LedgerID` join `transaction_type` as t ON l.`txnType`=t.`id` WHERE a.`AgentId`=$AID order by l.`tid`;";
            
            //echo $SelSql; 
            $Recordset      =   mysqli_query($db,$SelSql);
            if(mysqli_num_rows($Recordset)>0)
            {
                echo "<table ><tr><th>TXN ID</th><th>TXN Type</th><th>Debit</th><th>Credit</th><th>Balance</th><th>Time</th><th>Remarks</th></tr>";
                while($row            =   mysqli_fetch_assoc($Recordset))
                {
                    extract($row);
                    $tdate=date('d-M h:i:s A',strtotime($tdate));
                  echo  "<tr><td>$tid</td>
                    <td>$txnTypeStr</td>
                    <td>$debit</td>
                    <td>$credit</td>
                    <td>$balance</td>
                    <td>$tdate</td>
                    <td>$remarks</td></tr>";
                }

                echo '</table>';
            }
            else  
            {
                echo 'Nothing found';
            }
?>