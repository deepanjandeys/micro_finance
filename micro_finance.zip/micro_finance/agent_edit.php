<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$AID=''; $AgentName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $agentId=''; $cityId=''; 
$sex='';  $JoiningDate=''; $Balance=0;
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['AID']))
{
$AID=(int)$_GET['AID'];
 $SelSql="SELECT `AgentID` as `AID`, `AgentName`,`Balance`, `Address`, `mobileNo`, `IDProof`, `addressProof`, `IDProofLink`, `addressProofLink`, `photoLink`, `cityId`, `JoiningDate` FROM `agent_profile` as a join `ledger_master` as l ON a.`LedgerID`=l.`LedgerID` WHERE `AgentId`=$AID";
 //echo '('.$SelSql.')';
              $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Agent</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Agent</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Agent <?php echo $Action; ?></h5>
<?php 
  if(isset($_SESSION['error_message']))
  {
    echo $_SESSION['error_message'];
   
   $AgentName = $_SESSION['AgentName'];
   $Address = $_SESSION['Address'] ;
   $password = $_SESSION['password'] ;
   $mobileNo = $_SESSION['mobileNo'] ;
   $IDProof= $_SESSION['IDProof']        ;
   $addressProof= $_SESSION['addressProof']   ;
   $IDProofLink = $_SESSION['IDProofLink'];
   $addressProofLink = $_SESSION['addressProofLink'] ;
   $photoLink = $_SESSION['photoLink'];
   $cityId = $_SESSION['cityId'] ;
   $JoiningDate = $_SESSION['JoiningDate'] ;
   $balance = $_SESSION['balance'] ;

   unset($_SESSION['error_message']);
  }
  
?>
              <!-- Horizontal Form -->
              <form action="saveAgent.php" method="post" enctype="multipart/form-data" onsubmit="return form_validation();">
                <input type="hidden" name="AID" value="<?php echo $AID; ?>">
                <div class="row mb-3">
                  <label for="AgentName" class="col-sm-2 col-form-label">Agent Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="AgentName" name="AgentName" value="<?php echo $AgentName; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="password" class="col-sm-2 col-form-label">Password</label>
                  <div class="col-sm-10">
                    
                    <input type="text" class="form-control" id="password" name="password" style="<?php  
                    if($ActionButton=='Update')  
                    {
                      echo "display: none;";
                    }
                    ?>" >
                  <?php  
                    
                    if($ActionButton=='Update')  
                    {
                 ?>
                 <a href="javascript:void(0)" onclick="resetPassword()">Reset password</a>
                 <?php     
                    }
                  ?>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="balance" class="col-sm-2 col-form-label">
                  <?php  
                    if($ActionButton=='Save')  
                    {
                      echo "Opening ";
                    }
                    
                    ?> Balance</label>
                  <div class="col-sm-10">
                    
                    <input type="text" class="form-control" id="balance" name="balance" <?php  
                    if($ActionButton=='Update')  
                    {
                      echo "readonly";
                    }
                    else
                    {
                      echo "required";
                    }
                    ?> value="<?php echo $Balance; ?>">
                  
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="mobileNo" class="col-sm-2 col-form-label">Mobile</label>
                  <div class="col-sm-10">
                    <input type="number" class="form-control" id="mobileNo" name="mobileNo" value="<?php echo $mobileNo; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="Address" class="col-sm-2 col-form-label">Address</label>
                  <div class="col-sm-10">
                    <textarea class="form-control" name="Address" id="Address" required><?php echo $Address;?></textarea>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="IDProof" class="col-sm-2 col-form-label">ID Proof</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="IDProof" name="IDProof" value="<?php echo $IDProof; ?>">
                  </div>
                </div>
                 <div class="row mb-3">
                  <label for="IDProofLink" class="col-sm-2 col-form-label">ID Proof Link</label>
                  <div class="col-sm-4">
                    <input type="hidden" name="hdIDProofLink" value="<?php echo $IDProofLink; ?>">
                    <input class="form-control" type="file"  id="IDProofLink" name="IDProofLink">
                  </div>
                  <div class="col-sm-6"><?php if($IDProofLink!=''){
                    if(file_exists("uploads/IDProofLink/".$IDProofLink))
                    {
                    $extension = strtolower(pathinfo($IDProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/IDProofLink/$IDProofLink' alt='uploads/IDProofLink/$IDProofLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      else if($extension=='pdf')
                      {
                      echo  '<object data= 
"uploads/IDProofLink/'.$IDProofLink.'" 
                width="100"
                height="100"> 
        </object> ';
                      }
                      echo '<a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">ID Proof link Preview</a>';
                    
                    }
                  } ?></div>
                </div>
                <div class="row mb-3">
                  <label for="addressProof" class="col-sm-2 col-form-label">Address Proof</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="addressProof" name="addressProof" value="<?php echo $addressProof; ?>">
                  </div>
                </div>

               <div class="row mb-3">
                  <label for="addressProofLink" class="col-sm-2 col-form-label">Address Proof Link</label>
                  <div class="col-sm-4">
                    <input type="hidden" name="hdaddressProofLink" value="<?php echo $addressProofLink; ?>">
                    <input class="form-control" type="file"  id="addressProofLink" name="addressProofLink">
                  </div>
                  <div class="col-sm-6"><?php if($addressProofLink!=''){
                    if(file_exists("uploads/addressProofLink/".$addressProofLink))
                    {

                      $extension = strtolower(pathinfo($addressProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/addressProofLink/$addressProofLink' alt='uploads/addressProofLink/$addressProofLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      else if($extension=='pdf')
                      {
                      echo  '<object data= 
                    "uploads/addressProofLink/'.$addressProofLink.'" 
                    width="100"
                    height="100"> 
                      </object> ';
                      }
                      echo '<a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">Address Proof link Preview</a>';
                    }
                  } ?></div>
                </div>

                <div class="row mb-3">
                  <label for="photoLink" class="col-sm-2 col-form-label">Photo Link</label>
                  <div class="col-sm-4">

                    <input type="hidden" name="hdphotoLink" value="<?php echo $photoLink; ?>">
                    <input class="form-control" type="file"  id="photoLink" name="photoLink">
                  </div>
                  <div class="col-sm-6"><?php if($photoLink!=''){
                    if(file_exists("uploads/photoLink/".$photoLink))
                    {

                      $extension = strtolower(pathinfo($photoLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        echo "<img src='uploads/photoLink/$photoLink' alt='uploads/photoLink/$photoLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                      
                      echo '<a href="uploads/photoLink/'.$photoLink.'" target="_blank">photo link Preview</a>';
                    }
                  } ?>
                </div>
                </div>
                <?php 
$Select_sql ="SELECT `Sl`, `City_Name` FROM `city_master` where `State_Sl`=18;";
$result = mysqli_query($db,$Select_sql);
$selCities='There is no City ';
if(mysqli_num_rows($result)>0)
{
$selCities=<<<select_Cities
<select id="selCity" name='cityId' class="from-control" style="width:200px;">
  <option value="">Select City</option>
select_Cities;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['City_Name'];
    
$selCities.=<<<select_Cities
<option value='$Code'>$Name</option>
select_Cities;
  } 
$selCities.=<<<select_Cities
</select> 
select_Cities;
}
?>
                <div class="row mb-3">
                  <label for="cityId" class="col-sm-2 col-form-label">City Id</label>
                  <div class="col-sm-4">
                     <?php echo $selCities; ?>
                  </div>
                  <div class="col-sm-6">
                    <span id='spnCity_Name'></span>
                  </div>
                </div>
              <div class="row mb-3">
                  <label for="JoiningDate" class="col-sm-2 col-form-label">Date of Joining</label>
                  <div class="col-sm-4">
                    <input type="text" name="JoiningDate" id="JoiningDate" class="form-control" value="<?php if($JoiningDate!='') echo date('d-m-Y',strtotime($JoiningDate)); ?>" placeholder="dd-mm-yyyy" required> 
                  </div>
                </div>
                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
   $(document).ready(function(){
            $('#selCity').select2();
        });

  function resetPassword()
  {
    $('#password').show();
  }

function form_validation()
{
var msg='';
  if($('#selCity').val()=='')
  {
    msg +='Select a City<br>';
  }

  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}

$('#JoiningDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });



<?php  
if($ActionButton=='Save')
{
?>
$('#JoiningDate').val('');
<?php  
}
else 
{
?>
$('#selCity').val(<?php echo $cityId;?>);
<?php 
}
if(isset($_SESSION['error_message']))
  {
?>
$('#selCity').val(<?php echo $cityId;?>);
<?php
  }
?>
</script>

<?php 
include('end_html.php');
?>
