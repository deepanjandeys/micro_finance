<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$id=''; $name=''; $start_date=''; $end_date='';  $activeChecked='';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['id']))
{
$id=(int)$_GET['id'];
 $SelSql="SELECT `id`, `name`, `start_date`, `end_date`, `active` FROM `Session_master` WHERE `id`=$id";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";

        if($active=='1')
          $activeChecked='checked';
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Session</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Session</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Session <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveSession.php" method="post">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="row mb-3">
                  <label for="name" class="col-sm-2 col-form-label">Session Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="start_date" class="col-sm-2 col-form-label">Start Date</label>
                  <div class="col-sm-4">
                    <input type="text" name="start_date" class="form-control" value="<?php if($start_date!='') echo date('d-m-Y',strtotime($start_date)); ?>" required> 
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="end_date" class="col-sm-2 col-form-label">End Date </label>
                  <div class="col-sm-4">
                    <input type="text" name="end_date" class="form-control" value="<?php if($end_date!='') echo date('d-m-Y',strtotime($end_date)); ?>" required> 
                  </div>
                </div>
                <div class="row mb-3">
                <label for="name" class="col-sm-2 col-form-label">Active</label>
                  <div class="col-sm-10 form-check form-switch">
                    <input type="checkbox" class="form-check-input" id="active" name="active" <?php echo $activeChecked; ?> >
                  </div>
                </div>
                
                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
$('#start_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#end_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

</script>

<?php 
include('end_html.php');
?>
