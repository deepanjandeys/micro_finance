<?php require_once('../includes/db.php'); ?>
<?php
@session_start();

		if(!$_POST['username'] )//|| !$_POST['password']
		{
			$_SESSION["LoginErr"]=1; 
			header("location:../index.php");
		}
		else
		{
			$User = stripslashes($_POST['username']);
			$passwordRecv = stripslashes($_POST['password']);
			
$query = "SELECT `id`, `username`, `password` FROM `users` u WHERE u.`username`='".trim($User)."'";
//echo $query;
//die();
			$resource = mysqli_query($db,$query);
			$row = mysqli_fetch_array($resource);
			$count=mysqli_num_rows($resource);	
			
			if($count == 1)
			{
				extract($row);		
			///////////////////////////////////////////////////////////////////////

					if(password_verify($passwordRecv, $password))
					{	
						$_SESSION["UID"]=$id; 
						$_SESSION["Uname"]=$User; 
						$_SESSION["type"]=0;
						$_SESSION['isAdmin']=1;
						$_SESSION['logged_in'] = 1;
						
						header("location:../index.php");
					}
					else  
					{
					$_SESSION["LoginErr"]=3;
					$_SESSION["Uname"]=$User;  
					header("location:index.php");		
					}
				
			}
			else  
			{
				//echo "User not found";
				$_SESSION["LoginErr"]=2; 
				$_SESSION["Uname"]=$User; 
				header("location:index.php");
			}
				//if not, redirect back to login page showing an error
				//$_SESSION["LoginErr"]=2; 
				//header("location:../index.php");
			}

?>
<?php
	ob_flush();
?>