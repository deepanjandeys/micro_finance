<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');
$LoanRegNo=''; $CustName=''; $LoanAmt=''; $BookId=''; $EMIPrincipal='';
$EMIInterest=''; $FineAmount='' ; $EMIPayMode='';  $groupID='';   $GID='';   $LoanDate='';
$LoanStatus='0';  $CloseDate=''; $CID=''; $agentId='';  $LoanType=0; $LedgerID=''; 
//print_r($_POST);

date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$GID=(int)$GID;
$LoanDate=date('Y-m-d',strtotime($LoanDate));
$CloseDate=date('Y-m-d',strtotime($CloseDate));

$sqlLog = PHP_EOL.'-- saveLoan.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');

        $SelSql        =   "SELECT `id_gen_num` as `LoanRegNo` FROM `gen_ids` WHERE `id_code`=7";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=7;";

    $sqlLog .= $updSql.PHP_EOL;
    $res1       =   mysqli_query($db,$updSql);

            $insSql="INSERT INTO `loan_register`(`LoanRegNo`, `CID`,`LoanType`, `groupID`, `LoanAmt`, `BookId`, `EMIPrincipal`, `EMIInterest`, `FineAmount`, `EMIPayMode`, `LoanDate`, `LoanStatus`, `CloseDate`,`crt_dat_time`,`mdf_dat_tim`) VALUES ($LoanRegNo, $CID,'$LoanType', '$GID', $LoanAmt, '$BookId', $EMIPrincipal, $EMIInterest, $FineAmount, $EMIPayMode, '$LoanDate', $LoanStatus, '$CloseDate','$crDate','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            ///////////////////////////////
            $txnID=0;

            $SelSql        =   "SELECT `id_gen_num` as `txnID` FROM `gen_ids` WHERE `id_code`=8";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        ////////////////////
        $SelSql        =   "SELECT `agentId` FROM `customer_profile` WHERE `CID`=$CID";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
            //////////////////////////
if($EMIPayMode=='1')
            {
                $Interval='P1D';
                
                $LoanDate1  = date('Y-m-d',strtotime('+ 1 day',strtotime($LoanDate)));
                $CloseDate1 = date('Y-m-d',strtotime('+ 1 day',strtotime($CloseDate)));
            }
            elseif($EMIPayMode=='2')
            {
                $Interval='P1W';

                $LoanDate1  = date('Y-m-d',strtotime('+ 1 week',strtotime($LoanDate)));
                $CloseDate1 = date('Y-m-d',strtotime('+ 1 week',strtotime($CloseDate)));
            }
            elseif($EMIPayMode=='3')
            {
                $Interval='P1M';

                $LoanDate1   = date('Y-m-d',strtotime('+ 1 month' ,strtotime($LoanDate)));
                $CloseDate1  = date('Y-m-d',strtotime('+ 1 month', strtotime($CloseDate)));
            }
            
            $period = new DatePeriod(
                new DateTime($LoanDate1),
                new DateInterval($Interval),
                new DateTime($CloseDate1)
            );
            $emiNo=0;
    foreach ($period as $key => $value) 
        {
            $emiNo++;
        $dueDate=$value->format('Y-m-d');
        $insSql="INSERT INTO `emi_register`(`txnID`,`emiNo`, `dueDate`, `EMIPrincipal`, `EMIInterest`, `LoanRegNo`, `agentId`, `EMIPayMode`,`crt_dat_time`) VALUES ('$txnID','$emiNo','$dueDate', $EMIPrincipal, $EMIInterest, $LoanRegNo, '$agentId', '$EMIPayMode','$crDate')";

        $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

        $txnID++;
            }
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=$txnID,`last_gen_date`='$crDate' WHERE `id_code`=8;";
$res1       =   mysqli_query($db,$updSql);
        $sqlLog .= $updSql.PHP_EOL;
//////////////////////////////****************////////////////
    $SelSql= "SELECT `LedgerID`,`CustName`  FROM `agent_profile` as a JOIN `customer_profile` as c ON a.`AgentId`=c.`agentId` WHERE c.`CID`=$CID";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////////////////////////////////////////////
        $SelSql        =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //           2 for Withdraw  , 3 Loan Giving , 4 EMI Collection
    $txnType=3;
    // vouType = 0 for agent  , 1 account, 2 loan
    //         
    $vouType=2; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$LoanRegNo','$vouType','0','$txnType','Loan Given to $CustName')";

            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

        $SelSql        =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+2,`last_gen_date`='$crDate' WHERE `id_code`=11;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    
    $ledgerID_CustLoan=6;
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id1 = $id+1; // next Id
    $custId=0;
    ////////////////
        $SelSql        =   "SELECT `balance` as `custLoan` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_CustLoan"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $custLoan += $LoanAmt;   // add to cust Loan

        $updSql= "UPDATE `ledger_master` SET  `balance`= $custLoan WHERE `LedgerID`=$ledgerID_CustLoan;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ////////////////////////////////////////////
        $SelSql        =   "SELECT `balance` FROM `ledger_master` WHERE `LedgerID`=$LedgerID"; // fetch balance of agent ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $balance -= $LoanAmt;
    $updSql= "UPDATE `ledger_master` SET  `balance`= $balance WHERE `LedgerID`=$LedgerID;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    
    ///////////////////////////////////////////////
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$LedgerID', '$ledgerID_CustLoan', '$LoanAmt', '0.00', '$CID', '$balance'),('$id1', '$tid', '$ledgerID_CustLoan', '$LedgerID', '0.00','$LoanAmt', '$CID', '$custLoan');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
        
///////////////////////********************///////////////////////////
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `loan_register` SET `CID`='$CID',`LoanType`='$LoanType',`LoanAmt`='$LoanAmt', `groupID`='$GID',`BookId`='$BookId',`EMIPrincipal`='$EMIPrincipal',`EMIInterest`='$EMIInterest',`FineAmount`='$FineAmount',`EMIPayMode`='$EMIPayMode',`LoanDate`='$LoanDate', `LoanStatus`='$LoanStatus', `CloseDate`='$CloseDate', `mdf_dat_tim`='$upDate' WHERE `LoanRegNo`=".$LoanRegNo;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
        //////////////////
///////////////////////////////
            $txnID=0; $NoOfDays=0;  $FineAmount='';

            $SelSql="SELECT e.`txnID`, DATEDIFF(NOW(), e.`dueDate`) as NoOfDays,l.FineAmount FROM `emi_register` as e JOIN `loan_register` as l on e.LoanRegNo=l.LoanRegNo WHERE `txnDateTime` is null and `Fine` is null and DATEDIFF(NOW(), e.`mdf_dat_tim`)>0 and e.`LoanRegNo`=$LoanRegNo;";
            //echo $SelSql;
            $Recordset      =   mysqli_query($db,$SelSql);
            
            if(mysqli_num_rows($Recordset)>0)
            {
            while($row            =   mysqli_fetch_assoc($Recordset))
            {
            extract($row);   
        $Fine=$FineAmount*$NoOfDays;
        $updSql= "UPDATE `emi_register` SET  `Fine`=$Fine WHERE `txnID`=$txnID;";
        $res1   = mysqli_query($db,$updSql);            
        $sqlLog .= $updSql.PHP_EOL;

            }
            
            }         
        /////////////////
    if($res1=='')
    {
        header('location:loan_edit.php'); 
    }
    else 
    {
        $_SESSION['action'] = $action;
        $_SESSION['LoanRegNo'] =$LoanRegNo;
        header('location:loanSuccess.php'); 
    }
$sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>