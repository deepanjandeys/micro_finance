<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$ID='';    $name='';   
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and LedgerName like '%".$name."%' ";
}

if(isset($_COOKIE['pgSize']))
    $Intv=(int)$_COOKIE['pgSize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `LedgerID`, `LedgerName`,`balance`,lt.`Name` as `LedgerTypeName`  from `ledger_master` as lm join `ledger_types` as lt ON lm.`LedgerType`=lt.`ID`  WHERE 1 $nameStr Order By `LedgerID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        $balance = number_format($balance,2);
        echo "<tr>
                    <th scope='row'><a href='ledger_edit.php?LedgerID=$LedgerID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_Ledger($LedgerID)'>Delete</a></th>
                    <td>$LedgerID</td>
                    <td>$LedgerName</td>
                    <td style='text-align:right;'>$balance</td>
                    <td>$LedgerTypeName</td>
                    <td><a href='ledgerTrans.php?ledgerID=$LedgerID' target='_blank'>Ledger Transaction</a></td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`LedgerID`) as C  FROM `ledger_master` WHERE 1 $nameStr";
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];

$lnks= get_pagination_links($page,'showLedgerList',$count,$Intv);
echo $lnks;

echo "</td></tr>";
?>