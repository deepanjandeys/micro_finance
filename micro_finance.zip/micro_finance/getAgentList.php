<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$AID=''; $AgentName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $cityId=''; $balance=0;
$sex='';  $JoiningDate_from=''; $JoiningDate_to='';  $page=0;
//print_r($_POST);

$name='';   $mobile='';     $address='';    $IDProof='';    $AddressProof='';    
$city=''; 
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and AgentName like '%".$name."%' ";
}

$mobileStr='';
if($mobile<>'')
{
    $mobileStr=" and a.mobileNo like '%".$mobile."%' ";
}

$addressStr='';

if($address<>'')
{
    $addressStr=" and a.Address like '%".$address."%' ";
}

$IDProofStr='';
if($IDProof<>'')
{
    $IDProofStr=" and a.IDProof like '%".$IDProof."%' ";
}

$AddressProofStr='';
if($AddressProof<>'')
{
    $AddressProofStr=" and a.addressProof like '%".$AddressProof."%' ";
}

$cityStr='';
if($city<>'')
{
    $cityStr=" and a.cityId =".$city;
}

date_default_timezone_set("Asia/Kolkata");

$JoiningDateStr='';
if($JoiningDate_from<>'' && $JoiningDate_to<>'')
{
    $JoiningDate_from=date('Y-m-d',strtotime($JoiningDate_from));
    $JoiningDate_to =date('Y-m-d',strtotime($JoiningDate_to));

    $JoiningDateStr=" and a.JoiningDate between '".$JoiningDate_from."' and '".$JoiningDate_to."'";
}
else if($JoiningDate_from<>'')
{
    $JoiningDate_from=date('Y-m-d',strtotime($JoiningDate_from));
    $JoiningDateStr=" and a.JoiningDate between '".$JoiningDate_from."' and '".$JoiningDate_from."'";
}


if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;

if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `AgentID` as `AID`, `AgentName`,lm.`balance`, a.`Address`, a.`mobileNo`, a.`IDProof`, a.`addressProof`, a.`IDProofLink`, a.`addressProofLink`, a.`photoLink`, cm.`City_Name` FROM `agent_profile` as a LEFT JOIN `city_master` as cm ON  a.`cityId`=cm.`Sl` JOIN ledger_master as lm ON a.`LedgerID`=lm.`LedgerID` WHERE 1 $nameStr $mobileStr $addressStr $IDProofStr $AddressProofStr $cityStr $JoiningDateStr Order By `AgentID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              $IDProofLinkStr='';
              $addressProofLinkStr='';
              $photoLinkStr='';
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        $IDProofLinkStr='';
        $addressProofLinkStr='';
        $photoLinkStr='';

        if($IDProofLink!=''){
                    if(file_exists("uploads/IDProofLink/".$IDProofLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($IDProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/IDProofLink/$IDProofLink' alt='uploads/IDProofLink/$IDProofLink' style='width:50px;' />&nbsp;&nbsp;";

                        $IDProofLinkStr= '<a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">'.$fileTag.'</a>';
                      }
                      else if($extension=='pdf')
                      {
                      $fileTag=  '<object data= 
                    "uploads/IDProofLink/'.$IDProofLink.'" 
                    width="50" height="50"> </object> ';
                      
                      $IDProofLinkStr= $fileTag.'<br><a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">Preview</a>';
                      }
                      
                    }
                  } 
        if($addressProofLink!='')
        {
                    if(file_exists("uploads/addressProofLink/".$addressProofLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($addressProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/addressProofLink/$addressProofLink' alt='uploads/addressProofLink/$addressProofLink' style='width:50px;' />&nbsp;&nbsp;";
                    
                        $addressProofLinkStr= '<a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">'.$fileTag.'</a>';
                    
                      }
                      else if($extension=='pdf')
                      {
                      $fileTag=  '<object data= 
                    "uploads/addressProofLink/'.$addressProofLink.'" 
                    width="50" height="50"> </object> ';
                    
                      $addressProofLinkStr= $fileTag.'<br><a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">Preview</a>';
                    
                      }
                      
                      }
                  } 
        if($photoLink!=''){
                    if(file_exists("uploads/photoLink/".$photoLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($photoLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/photoLink/$photoLink' alt='uploads/photoLink/$photoLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                     

                      $photoLinkStr= '<a href="uploads/photoLink/'.$photoLink.'" target="_blank">'.$fileTag.'</a>';
                    }
                  }
        $s2='<!-- Modal Dialog Scrollable -->
              <button type="button" class="btn btn-warning text-danger" data-bs-toggle="modal" data-bs-target="#modalDialogScrollable'.$AID.'" onClick="showAgentTxn_List('.$AID.')">
                '.$balance.'
              </button>
              <div class="modal fade" id="modalDialogScrollable'.$AID.'" tabindex="-1" >
                <div class="modal-dialog modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Agent Transaction Log</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="agent_txn_list'.$AID.'">
                      

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div><!-- End Modal Dialog Scrollable-->
';
 
        echo "<tr>
                    <th scope='row'><a href='agent_edit.php?AID=$AID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_agent($AID)'>Delete</a></th>
                    <td>$AID</td>
                    <td>$AgentName</td>
                    <td style='text-align:right;'>$s2 <br><a href='agent_add_balance.php?AID=$AID'><i class='bi bi-plus-circle'></i></a>
                    <a href='agent_withdraw_balance.php?AID=$AID'><i class='bi bi-dash-circle'></i></a></td>
                    <td>$mobileNo</td>
                    <td>$Address</td>
                    <td>$IDProof</td>
                    <td>$addressProof</td>
                    <td>$IDProofLinkStr</td>
                    <td>$addressProofLinkStr</td>
                    <td>$photoLinkStr</td>
                    <td>$City_Name</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`AgentID`) as C  FROM `agent_profile` as a WHERE 1 $nameStr $mobileStr $addressStr $IDProofStr $AddressProofStr $cityStr $JoiningDateStr";
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    $N=$count/$Intv;
$lnks= get_pagination_links($page,'showAgentList',$count,$Intv);
echo $lnks;
echo "</td></tr>";
?>