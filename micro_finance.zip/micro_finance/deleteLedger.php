<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$ID=''; 

extract($_GET); 
$sqlLog = PHP_EOL.'-- deleteLedger.php '.PHP_EOL;
        
    $delSql="DELETE FROM `ledger_master` WHERE `LedgerID`=".$ID;

    
    $sqlLog .= $delSql.PHP_EOL;
    $res1   = mysqli_query($db,$delSql);

    header('location:ledgers.php'); 
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>