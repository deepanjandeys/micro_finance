<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');
//include('includes/functions.php');
$LoanRegNo='2'; 
date_default_timezone_set("Asia/Kolkata");
extract($_GET); 

$CID=0; $EMIPrincipal=''; $EMIInterest=''; $EMIPayMode=''; 
$LoanDate=''; $CloseDate='';

$sqlLog = PHP_EOL.'-- recreateEMI.php '.PHP_EOL;
        $crDate=date('Y-m-d H:i:s');

        ///////////////////////////////
            $txnID=0;

            $SelSql="SELECT count(`txnID`) as C FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo and `txnDateTime` is NOT null;";
            $Recordset      =   mysqli_query($db,$SelSql);
            $row            =   mysqli_fetch_assoc($Recordset);
            if($row['C']>0)
            {
                
                echo '<div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                Recreate is not done, as there are some records related to EMI Collection!
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
                die();
            }

            $SelSql="SELECT `CID`, `EMIPrincipal`, `EMIInterest`, `EMIPayMode`, `LoanDate`, `CloseDate` FROM `loan_register` WHERE `LoanRegNo`=$LoanRegNo";
            $Recordset      =   mysqli_query($db,$SelSql);
            $row            =   mysqli_fetch_assoc($Recordset);
            extract($row);   
    
            $SelSql        =   "SELECT `id_gen_num` as `txnID` FROM `gen_ids` WHERE `id_code`=8";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
                ////////////////////
        $SelSql        =   "SELECT `agentId` FROM `customer_profile` WHERE `CID`=$CID";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
            //////////////////////////
        if($EMIPayMode=='1')
            {
                $Interval='P1D';
                
                $LoanDate1  = date('Y-m-d',strtotime('+ 1 day',strtotime($LoanDate)));
                $CloseDate1 = date('Y-m-d',strtotime('+ 1 day',strtotime($CloseDate)));
            }
            elseif($EMIPayMode=='2')
            {
                $Interval='P1W';

                $LoanDate1  = date('Y-m-d',strtotime('+ 1 week',strtotime($LoanDate)));
                $CloseDate1 = date('Y-m-d',strtotime('+ 1 week',strtotime($CloseDate)));
            }
            elseif($EMIPayMode=='3')
            {
                $Interval='P1M';

                $LoanDate1   = date('Y-m-d',strtotime('+ 1 month' ,strtotime($LoanDate)));
                $CloseDate1  = date('Y-m-d',strtotime('+ 1 month', strtotime($CloseDate)));
            }

            $period = new DatePeriod(
                new DateTime($LoanDate1),
                new DateInterval($Interval),
                new DateTime($CloseDate1)
            );
            ///////////////////
            $delSql="delete from `emi_register` WHERE `LoanRegNo`=$LoanRegNo";
            $res1   = mysqli_query($db,$delSql);            
            ////////////////
        $emiNo=0;

    foreach ($period as $key => $value) {
        $emiNo++;
        $dueDate=$value->format('Y-m-d');
        $insSql="INSERT INTO `emi_register`(`txnID`, `dueDate`,`emiNo`, `EMIPrincipal`, `EMIInterest`, `LoanRegNo`, `agentId`, `EMIPayMode`,`crt_dat_time`,`mdf_dat_tim`) VALUES ('$txnID', '$dueDate',$emiNo, $EMIPrincipal, $EMIInterest, $LoanRegNo, '$agentId', '$EMIPayMode','$crDate','$crDate')";

        $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

        $txnID++;
}
$updSql= "UPDATE `gen_ids` SET  `id_gen_num`=$txnID,`last_gen_date`='$crDate' WHERE `id_code`=8;";
$res1   = mysqli_query($db,$updSql);            
        $sqlLog .= $updSql.PHP_EOL;

//////////////////////////////

echo '<div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                 EMI List Created !
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    
$sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>