<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$ID='';    $name='';   
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and Name like '%".$name."%' ";
}

if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;
$page=(int)$page;
if($page==0)
    $page++;

$start=$page*$Intv; 

$SelSql="SELECT `ID`, `Name` from `ledger_types` WHERE 1 $nameStr Order By `ID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        echo "<tr>
                    <th scope='row'><a href='ledgerType_edit.php?ID=$ID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_LedgerType($ID)'>Delete</a></th>
                    <td>$ID</td>
                    <td>$Name</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`ID`) as C  FROM `ledger_types` WHERE 1 $nameStr";
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    $N=$count/$Intv;
if($N>1)
{
$DivStr=<<<Div_Str
<nav aria-label="Page navigation example">
  <ul class="pagination">
Div_Str;
if($page==0)
{
$DivStr.=<<<Div_Str
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
else 
{
    $k=$page-1;
$DivStr.=<<<Div_Str
    <li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_srch$k' onClick="showLedgerTypeList($k);" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Previous</span>
      </a>
    </li>
Div_Str;
for($i=0;$i<$N;$i++)
{
$j=$i+1;
    if($i==$page)
    {
$DivStr.=<<<Div_Str
<li class="page-item active"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showLedgerTypeList($i);">$j</a></li>
Div_Str;
    }
    else
    {
$DivStr.=<<<Div_Str
<li class="page-item"><a class="page-link" href="javascript:void(0);" id='a_srch$i' onClick="showLedgerTypeList($i);">$j</a></li>
Div_Str;
    }
}

if($page==$N-1)
{
$DivStr.=<<<Div_Str
<li class="page-item disabled">
      <a class="page-link" href="#" aria-label="Next">
Div_Str;
}
else 
{
    $k=$page+1;
$DivStr.=<<<Div_Str
<li class="page-item">
      <a class="page-link" href="javascript:void(0);" id='a_next' onClick="showLedgerTypeList($k);" aria-label="Next">
Div_Str;
}
$DivStr.=<<<Div_Str
        <span class="sr-only">Next</span>
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>
Div_Str;
echo $DivStr;
}
$DivStr=<<<Div_Str
<span title=" Based on Searched Result">Total Records </span><span style="color:orange">$count</span> &nbsp;&nbsp;&nbsp;Page size 
<input type="text" value="$Intv" id="txtPageSize" size="2" onChange="setCustPageSize(this.value)">
Div_Str;
echo $DivStr;
echo "</td></tr>";
?>