<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$EMIPrincipal=''; $EMIInterest='';  $Fine_Amount=''; $txnID='';

date_default_timezone_set("Asia/Kolkata");
$crDate=date('Y-m-d H:i:s');

extract($_GET); 
$Fine_Amount = (float)$Fine_Amount;

$sqlLog = PHP_EOL.'-- setEMICollection.php '.PHP_EOL;

    $SelSql="SELECT e.`EMIPrincipal`,e.`EMIInterest`,l.`CID` FROM `emi_register` as e join `loan_register` as l ON e.`LoanRegNo`=l.`LoanRegNo` WHERE `txnID`=$txnID"; 
    //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
    $row=   mysqli_fetch_assoc($Recordset);
    extract($row);   
    }


    $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `emi_register` SET `Fine`='$Fine_Amount',`txnDateTime`='$upDate',`mdf_dat_tim`='$upDate' WHERE `txnID`=".$txnID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
//////////////////////////////****************////////////////
    $SelSql= "SELECT `LedgerID`,`CustName`  FROM `agent_profile` as a JOIN `customer_profile` as c ON a.`AgentId`=c.`agentId` WHERE c.`CID`=$CID";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////////////////////////////////////////////
        $SelSql        =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //           2 for Withdraw  , 3 Loan Giving , 4 EMI Collection
    $txnType=4;
    // vouType = 0 for agent  , 1 account, 2 loan, 3 EMI
    //         
    $vouType=3; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$txnID','$vouType','0','$txnType','EMI Collect from $CustName')";

            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

    $SelSql =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
    $Recordset      =   mysqli_query($db,$SelSql);
    $row            =   mysqli_fetch_assoc($Recordset);
    extract($row);   
  
    if($Fine_Amount==0)
    {  
    $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+3,`last_gen_date`='$crDate' WHERE `id_code`=11;";
    }
    else  
    {   // for Fine entry, we need two extra 
    $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+5,`last_gen_date`='$crDate' WHERE `id_code`=11;";
    }
    $sqlLog .= $updSql.PHP_EOL;
    $res1       =   mysqli_query($db,$updSql);
    
    $ledgerID_CustLoan=6;
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id1 = $id+1; // next Id
    $id2 = $id+2; // next Id
    $custId=0;
    $EMI = ($EMIPrincipal+$EMIInterest);
    ////////////////
        $SelSql = "SELECT `balance` as `custLoan` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_CustLoan"; // fetch balance of cash ledger
        $Recordset =   mysqli_query($db,$SelSql);
        $row       =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $custLoan -= $EMI;   // deduct cust Loan

        $updSql= "UPDATE `ledger_master` SET  `balance`= $custLoan WHERE `LedgerID`=$ledgerID_CustLoan;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ////////////////////////////////////////////
        $SelSql        =   "SELECT `balance` FROM `ledger_master` WHERE `LedgerID`=$LedgerID"; // fetch balance of agent ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $balance += $EMI;
    $updSql= "UPDATE `ledger_master` SET  `balance`= $balance WHERE `LedgerID`=$LedgerID;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    
    
    ///////////////////////////////////////////////
    $ledgerID_Interest=5;
    ////////////////
        $SelSql        =   "SELECT `balance` as `Interest` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_Interest"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $Interest += $EMIInterest;   // deduct cust Loan

        $updSql= "UPDATE `ledger_master` SET  `balance`= $Interest WHERE `LedgerID`=$ledgerID_Interest;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$ledgerID_CustLoan', '$LedgerID', '$EMI','0.00', '$CID', '$custLoan'),('$id1', '$tid', '$LedgerID', '$ledgerID_CustLoan', '0.00','$EMI','$CID', '$balance'),('$id2', '$tid', '$ledgerID_Interest', '$LedgerID', '0.00', '$EMIInterest', '$CID', '$Interest');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
  
  if($Fine_Amount>0)
  {
        // previous code we update id by extra two
    
    $ledgerID_Fine=7;
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id3 = $id+3; // next Id
    $id4 = $id+4; // next Id
    ////////////////
        $SelSql = "SELECT `balance` as `Fine` FROM `ledger_master` WHERE `LedgerID`=$ledgerID_Fine"; // fetch balance of cash ledger
        $Recordset =   mysqli_query($db,$SelSql);
        $row       =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $Fine += $Fine_Amount;   // deduct cust Loan

        $updSql= "UPDATE `ledger_master` SET  `balance`= $Fine_Amount WHERE `LedgerID`=$ledgerID_Fine;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ////////////////////////////////////////////
        $SelSql        =   "SELECT `balance` FROM `ledger_master` WHERE `LedgerID`=$LedgerID"; // fetch balance of agent ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $balance += $Fine_Amount;
    $updSql= "UPDATE `ledger_master` SET  `balance`= $balance WHERE `LedgerID`=$LedgerID;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ///////////////////////////////////////////////
    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id3', '$tid', '$ledgerID_Fine', '$LedgerID', '$Fine_Amount','0.00', '$CID', '$Fine'),('$id4', '$tid', '$LedgerID', '$ledgerID_Fine', '0.00','$Fine_Amount','$CID', '$balance');";
    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
  }      
///////////////////////********************///////////////////////////
       
    if($res1=='')
    {
        echo '<span style="color:red;font-weight:bold;">EMI <span style="color:green;">'.$txnID.'</span> not collected</span>';
    }
    else 
    {
        echo '<span style="color:green;font-weight:bold;">EMI <span style="color:red;">'.$txnID.'</span>  collected</span><a href="reciptEMI.php?txnID='.$txnID.'" target="_blank" class="btn btn-success">Print</a>';
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>