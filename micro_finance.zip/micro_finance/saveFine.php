<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$principalAmt=''; $FineAmt='';
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveFine.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');

            $insSql="INSERT INTO `fine_master`(`principalAmt`, `FineAmt`,`crt_dat_time`) VALUES ('$principalAmt','$FineAmt','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `fine_master` SET `FineAmt`='$FineAmt',`mdf_dat_tim`='$upDate' WHERE `principalAmt`=".$principalAmt;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:Fine_edit.php'); 
    }
    else 
    {
        header('location:fines.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>