function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function recreateEMI(LoanRegNo)
{
  var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#spnLoanEMI_Creatlist'+LoanRegNo).html(xmlhttp.responseText);
    }
  }
 
  console.log("recreateEMI.php?LoanRegNo="+LoanRegNo);
  xmlhttp.open("GET","recreateEMI.php?LoanRegNo="+LoanRegNo,true);
  xmlhttp.send();
}


function showEMI_List(LoanRegNo)
{
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      console.log(xmlhttp.responseText);
      $('#EMI_list'+LoanRegNo).html(xmlhttp.responseText);
    }
  }
  xmlhttp.open("GET","getEMI_List4Modal.php?LoanRegNo="+LoanRegNo,true);
  xmlhttp.send();
}


function print_EMI(LoanRegNo)
{
  window.open('printEMI_List.php?LoanRegNo='+LoanRegNo);
}
