<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$id=''; $name=''; $start_date=''; $end_date=''; $activeValue=0;
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 
//print_r($_POST);
//die();
$start_date = date('Y-m-d',strtotime($start_date));
$end_date = date('Y-m-d',strtotime($end_date));

$sqlLog = PHP_EOL.'-- saveSession.php '.PHP_EOL;

if(isset($active))
    {
         $activeValue=1;
          $upDate=date('Y-m-d H:i:s');
          $updSql = "UPDATE `session_master` SET `active`=0";

          $sqlLog .= $updSql.PHP_EOL;
          $res1   = mysqli_query($db,$updSql);
    }   
else 
    $activeValue=0;

        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
$SelSql =   "SELECT ifnull(max(`id`) + 1,1) as id  FROM `session_master` ";
$Recordset      =   mysqli_query($db,$SelSql);
$row            =   mysqli_fetch_assoc($Recordset);
extract($row);   

$insSql="INSERT INTO `session_master`(`id`, `name`, `start_date`, `end_date`, `active`,`created_at`,`modify_at`) VALUES ('$id','$name','$start_date','$end_date',$activeValue,'$crDate','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
$updSql = "UPDATE `session_master` SET `name`='$name',`start_date`='$start_date', `end_date`='$end_date',`active`=$activeValue WHERE `id`=".$id;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:session_edit.php'); 
    }
    else 
    {
        header('location:settings.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>