<?php 
include('headers.php'); 
include('includes/db.php');  

?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>EMI Report Daywise</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">EMI</li>
          <li class="breadcrumb-item active">Report</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of EMI &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-3">
                          Customer
                        </div>
                        <div class="col-3">
                          <?php 
$Select_sql ="SELECT `CID`, `CustName` FROM `customer_profile` ";

$result = mysqli_query($db,$Select_sql);

$selCustomers='There is no Cutomer ';

if(mysqli_num_rows($result)>0)
{
$selCustomers=<<<select_Customers
<input class="form-control" 
            list="CIDOptions" name='CID' id='CID'  
            placeholder="Select Customer" onchange='CID_Change()' autocomplete="off"> 
        <datalist id="CIDOptions"> 
select_Customers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['CID'];
    $Name=$row['CustName'];
    
$selCustomers.=<<<select_Customers
<option value='$Code'>$Name</option>
select_Customers;
  } 
$selCustomers.=<<<select_Customers
</datalist> 
select_Customers;
}

echo $selCustomers;
?>
<span id='spnCust_Name'></span>
                        </div>
                         <div class="col-3">
                          Agent
                        </div>
                        <div class="col-3">
                          <?php 
$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile`";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<input class="form-control" 
            list="agentIdOptions" name='agentId' id='agentId'  
            placeholder="Select Agents " onchange='agentID_Change()' autocomplete="off"> 
        <datalist id="agentIdOptions"> 
Select_Agents;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</datalist> 
Select_Agents;
}
echo $selAgents;
?>

    <span id='spnAgentname'></span>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-3">
                          EMI Principal
                        </div>
                        <div class="col-1">
                          <select class="form-control" id="src_EMIPrinci_opr">
                            <option>=</option>
                            <option>></option>
                            <option>>=</option>
                            <option><</option>
                            <option><=</option>
                            <option> != </option>
                          </select>
                        </div>
                        
                        <div class="col-2">
                          <input type="text" id="src_EMI_Principal" class="form-control">
                        </div>
                        <div class="col-3">
                          EMI Payment Mode
                        </div>
                        <div class="col-3">
                          <?php 
$Select_sql ="SELECT `ID`, `Name` FROM `payment_modes` ";

$result = mysqli_query($db,$Select_sql);

$selCities='There is no EMI Payment Mode ';

if(mysqli_num_rows($result)>0)
{
$selCities=<<<select_Cities
<input class="form-control" 
            list="EMIPayModeOptions" name='src_Payment_Mode' id='src_Payment_Mode'  
            placeholder="Select Payment Modes" onchange='EMIPayMode_Change()' autocomplete="off"> 
        <datalist id="EMIPayModeOptions"> 
select_Cities;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['ID'];
    $Name=$row['Name'];
    
$selCities.=<<<select_Cities
<option value='$Code'>$Name</option>
select_Cities;
  } 
$selCities.=<<<select_Cities
</datalist> 
select_Cities;
}

echo $selCities;
?>
<span id='spnPayment_Mode_Name'></span>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-3">
                          EMI Interest
                        </div>
                        <div class="col-1">
                          <select class="form-control" id="src_EMIInterst_opr">
                            <option>=</option>
                            <option>></option>
                            <option>>=</option>
                            <option><</option>
                            <option><=</option>
                            <option> != </option>
                          </select>
                        </div>
                        
                        <div class="col-2">
                          <input type="text" id="src_EMI_Interest" class="form-control">
                        </div>
                        <div class="col-3">
                          Fine Amount
                        </div>
                        <div class="col-1">
                          <select class="form-control" id="src_FineAmount_opr">
                            <option>=</option>
                            <option>></option>
                            <option>>=</option>
                            <option><</option>
                            <option><=</option>
                            <option> != </option>
                          </select>
                        </div>
                        
                        <div class="col-2">
                          <input type="text" id="src_Fine_Amount" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-3">
                          Loan Amount
                        </div>
                        <div class="col-1">
                          <select class="form-control" id="src_loan_opr">
                            <option>=</option>
                            <option>></option>
                            <option>>=</option>
                            <option><</option>
                            <option><=</option>
                            <option> != </option>
                          </select>
                        </div>
                        <div class="col-2">
                         <input type="text" id="src_Loan_Amount" class="form-control">
                        </div>
                        <div class="col-3">
                          EMI Status
                        </div>
                        <div class="col-3">
                          <select id="src_Status" class="form-control">
                            <option value="0"></option>
                            <option value="1">InActive</option>
                            <option value="2">Active</option>
                            <option value="3">Start</option>
                          </select>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-3">
                          EMI Due Date
                        </div>
                        <div class="col-3">
                          <input type="text" id="src_EMI_DueDateFrom" value="<?php echo date('d-m-Y'); ?>" class="form-control">
                        </div>
                        <div class="col-3">
                          <input type="text" id="src_EMI_DueDateTo" value="<?php echo date('d-m-Y'); ?>" class="form-control">
                        </div>
                        <div class="col-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showEMIList(0)">
                        </div>
                      </div>
                      </fieldset>
                   </div>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">EMI txnID</th>
                    <th scope="col">Collect Time</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">EMI Principal</th>
                    <th scope="col">EMI Interest</th>
                    <th scope="col">Fine Amount</th>
                    <th scope="col">EMIPayMode</th>
                    <th scope="col">Agent</th>
                    <th scope="col">Customer </th>
                    <th scope="col">Loan ID </th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  function agentID_Change() {
    var val = document.getElementById("agentId").value;
    var opts = document.getElementById('agentIdOptions').children;
    $('#spnAgentname').html('');
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].value === val) {
        // An item was selected from the list!
        // yourCallbackHere()
        $('#spnAgentname').html(opts[i].text);
        //console.log(opts[i].text);
        break;
      }
    }
  }
  function delete_EMI(EMIID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteEMI.php?EMIID='+EMIID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showEMIList(curPage)
{

  var CID=$('#CID').val();
  var agent=$('#agentId').val();

  var loan_opr=$('#src_loan_opr').val();
  var Loan_Amount=$('#src_Loan_Amount').val();

  var EMIPrinci_opr=$('#src_EMIPrinci_opr').val();
  var EMI_Principal=$('#src_EMI_Principal').val();
  
  var EMIInterst_opr=$('#src_EMIInterst_opr').val();
  var EMI_Interest=$('#src_EMI_Interest').val();
  
  var FineAmount_opr=$('#src_FineAmount_opr').val();
  var Fine_Amount=$('#src_Fine_Amount').val();
  
  var PaymentMode=$('#src_Payment_Mode').val();
  var EMI_DueDateFrom = $('#src_EMI_DueDateFrom').val();
  var EMI_DueDateTo = $('#src_EMI_DueDateTo').val();

  $('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');
  
  var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
setCookie('EMIPageNo',curPage,7);
/* 
console.log("getEMIDayWiseList.php?page="+curPage+"&CID="+CID+"&agent="+agent+"&EMIPrinci_opr="+EMIPrinci_opr+"&EMI_Principal="+EMI_Principal+"&EMIInterst_opr="+EMIInterst_opr+"&EMI_Interest="+EMI_Interest+"&FineAmount_opr="+FineAmount_opr+"&Fine_Amount="+Fine_Amount+"&loan_opr="+loan_opr+"&Loan_Amount="+Loan_Amount+"&PaymentMode="+PaymentMode+"&EMI_DueDateFrom="+EMI_DueDateFrom+"&EMI_DueDateTo="+EMI_DueDateTo);
*/
  xmlhttp.open("GET","getEMIDayWiseList.php?page="+curPage+"&CID="+CID+"&agent="+agent+"&EMIPrinci_opr="+EMIPrinci_opr+"&EMI_Principal="+EMI_Principal+"&EMIInterst_opr="+EMIInterst_opr+"&EMI_Interest="+EMI_Interest+"&FineAmount_opr="+FineAmount_opr+"&Fine_Amount="+Fine_Amount+"&loan_opr="+loan_opr+"&Loan_Amount="+Loan_Amount+"&PaymentMode="+PaymentMode+"&EMI_DueDateFrom="+EMI_DueDateFrom+"&EMI_DueDateTo="+EMI_DueDateTo,true);
  xmlhttp.send();
}

var pageNo=getCookie('EMIPageNo');
if(pageNo=='')
  pageNo=1;

showEMIList(pageNo);

function setCustPageSize(a)
{
document.cookie="pgZize="+a; 
showEMIList(1);
}

function setCustPageNumber(a)
{
showEMIList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}

$('#src_EMI_DueDateFrom').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_EMI_DueDateTo').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

</script>
<?php 
include('end_html.php');
?>
