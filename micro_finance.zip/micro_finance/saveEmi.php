<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');
$txnID=''; $Fine='';    $callBy=0; $CID='';

date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveEMI.php '.PHP_EOL;
        if ($action=='Save') 
        {
        //////////////////////////////         ///////////////////////////////////////
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `emi_register` SET `Fine`='$Fine' WHERE `txnID`=".$txnID;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    if($res1=='')
    {
        header('location:emi_edit.php'); 
    }
    else 
    {
        if($callBy=='0')
            header('location:emis.php'); 
        else if($callBy=='1')
            header('location:emiOutstandingReport.php'); 
        else if($callBy=='2')
            header('location:emisIndividual.php?CID='.$CID); 
        else if($callBy=='3')
            header('location:emiCollectionReport.php'); 
    }
$sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>