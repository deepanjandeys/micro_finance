<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');
$ledgerID=0; $Amount=0; $ledgerID1=0;
$LedgerName='';     $LedgerName1=''; $Remarks='';

date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$Amount=(float)$Amount;

$SelSql ="SELECT `LedgerName` FROM `ledger_master` where `ledgerID`=$ledgerID";
$result = mysqli_query($db,$SelSql);

if(mysqli_num_rows($result)>0)
{
    $row = mysqli_fetch_array($result);
    extract($row);
}

$SelSql ="SELECT `LedgerName` as `LedgerName1` FROM `ledger_master` where `ledgerID`=$ledgerID1";
$result = mysqli_query($db,$SelSql);

if(mysqli_num_rows($result)>0)
{
    $row = mysqli_fetch_array($result);
    extract($row);
}

$sqlLog = PHP_EOL.'-- saveLedgerAmountTransfer.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');

///////////////////// add record to agent transaction log
////////////////////////////////////////////////////////////
        $SelSql        =   "SELECT `id_gen_num` as `tid` FROM `gen_ids` WHERE `id_code`=10";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+1,`last_gen_date`='$crDate' WHERE `id_code`=10;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    // txnType = 0 for Openning Balance, 1 add Balance, 
    //      2 for Withdraw  , 3 Loan Giving , 4 EMI Collection, 5 Account Transfer
    $txnType=5;
    // vouType = 0 for agent  , 1 Account Transfer
    //         
    $vouType=1; 
    
    $insSql ="INSERT INTO `ledger`(`tid`, `tdate`, `vouNo`, `vouType`, `userId`, `txnType`, `remarks`) VALUES ($tid,'$crDate','$ledgerID','$vouType','0','$txnType','Amount Transfer from $LedgerName to $LedgerName1 : $Remarks')";

            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);    
        /////////////////////////////////////////

        $SelSql        =   "SELECT `id_gen_num` as `id` FROM `gen_ids` WHERE `id_code`=11";
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    
        $updSql= "UPDATE `gen_ids` SET  `id_gen_num`=`id_gen_num`+2,`last_gen_date`='$crDate' WHERE `id_code`=11;";

    $sqlLog .= $updSql.PHP_EOL;

    $res1       =   mysqli_query($db,$updSql);
    
    // $LedgerID newly generated Ledger ID of agent
    // $balance openning balance of agent
    $id1 = $id+1; // next Id
    $custId=0;
    ////////////////
        $SelSql        =   "SELECT `balance` FROM `ledger_master` WHERE `LedgerID`=$ledgerID"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $balance -= $Amount;   // deduct from balance of First ledger

        $updSql= "UPDATE `ledger_master` SET  `balance`= $balance WHERE `LedgerID`=$ledgerID;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ///////////////////////////////////////////////
        $SelSql        =   "SELECT `balance` as `balance1` FROM `ledger_master` WHERE `LedgerID`=$ledgerID1"; // fetch balance of cash ledger
        $Recordset      =   mysqli_query($db,$SelSql);
        $row            =   mysqli_fetch_assoc($Recordset);
        extract($row);   
    ////////////////////
        $balance1 += $Amount;   // add to balance1

        $updSql= "UPDATE `ledger_master` SET  `balance`= $balance1 WHERE `LedgerID`=$ledgerID1;";
        $sqlLog .= $updSql.PHP_EOL;
        $res1       =   mysqli_query($db,$updSql);
    ///////////////////////////////////////////////

    $insSql = "INSERT INTO `ledgertran` (`id`, `tid`, `ledgerid`, `particularsid`, `debit`, `credit`, `custId`, `balance`) VALUES ('$id', '$tid', '$ledgerID', '$ledgerID1', '$Amount', '0.00', '$custId', '$balance'), ('$id1', '$tid', '$ledgerID1', '$ledgerID', '0.00', '$Amount', '$custId', '$balance1');";

    $sqlLog .= $insSql.PHP_EOL;
    $res1   = mysqli_query($db,$insSql);    
        
        }
        else if($action=='Update') 
        {
////////////////////////////////       
        }
    if($res1=='')
    {
        header('location:ledgerAmountTarnsfer.php'); 
    }
    else 
    {
        $_SESSION['action']     = $action;
        $_SESSION['LedgerName']  = $LedgerName;
        $_SESSION['LedgerName1']  = $LedgerName1;
        $_SESSION['Amount']  = $Amount;
        header('location:ledgerAmountTarnsfer_success.php'); 
    }
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>