<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');
//include('includes/functions.php');
$LoanRegNo=''; 
date_default_timezone_set("Asia/Kolkata");
extract($_GET); 

$CID=0; $EMIPrincipal=''; $EMIInterest=''; $EMIPayMode=''; 
$LoanDate=''; $CloseDate='';

        ///////////////////////////////
            $txnID=0;

            $SelSql="SELECT `emiNo`,`txnDateTime`, `dueDate`, `EMIPrincipal`, `EMIInterest`, `Fine` FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo Order by `dueDate`;";
            $Recordset      =   mysqli_query($db,$SelSql);
            if(mysqli_num_rows($Recordset)>0)
            {
                echo "<table class='table table-bordered table-striped'><tr><th>EMI No.</th><th>Due Date</th><th>EMI</th></tr>";
                while($row            =   mysqli_fetch_assoc($Recordset))
                {
                    extract($row);
                $EMI=number_format((float)$EMIPrincipal + (float)$EMIInterest,2);
                    $dueDate=date('d-M-Y',strtotime($dueDate));
                  echo  "<tr><td>$emiNo</td><td>$dueDate</td>
                    <td>Rs $EMI</td>
                    </tr>";
                }

                echo '</table>';
            }
            else  
            {
                echo 'Nothing found';
            }

?>