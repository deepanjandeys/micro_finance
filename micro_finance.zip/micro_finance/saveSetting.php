<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$id=''; $organisation_name='';
date_default_timezone_set("Asia/Kolkata");
extract($_POST); 

$sqlLog = PHP_EOL.'-- saveState.php '.PHP_EOL;
        if ($action=='Save') 
        {
        $crDate=date('Y-m-d H:i:s');
            $insSql="INSERT INTO `State_master`(`Sl`, `State_Name`,`CountrySl`,`crt_dat_time`) VALUES ('$ID','$State_Name','0','$crDate')";
            $sqlLog .= $insSql.PHP_EOL;
            $res1   = mysqli_query($db,$insSql);

            //echo '<br>'.$insSql;
            //die();
    
        }
        else if($action=='Update') 
        {
        $upDate=date('Y-m-d H:i:s');
    $updSql = "UPDATE `meta_info` SET `organisation_name`='$organisation_name' WHERE `id`=".$id;

    $sqlLog .= $updSql.PHP_EOL;
    $res1   = mysqli_query($db,$updSql);
       
        }
    header('location:settings.php'); 
    
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);

    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>