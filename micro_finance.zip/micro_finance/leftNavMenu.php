<?php  
@session_start();
if(isset($_SESSION['isAdmin']))
{
  if($_SESSION['isAdmin']=='1')
  {
  ?>
    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-heading">Master</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="customers.php">
          <i class="bi bi-person"></i>
          <span>Customers</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="groups.php">
          <i class="bi bi-person"></i>
          <span>Groups</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="agents.php">
          <i class="bi bi-question-circle"></i>
          <span>Agents</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="cities.php">
          <i class="bi bi-envelope"></i>
          <span>Cities</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="states.php">
          <i class="bi bi-card-list"></i>
          <span>States</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="fines.php">
          <i class="bi bi-file-earmark"></i>
          <span>Fine Chart</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="ledgers.php">
          <i class="bi bi-file-earmark"></i>
          <span>Ledger Master</span>
        </a>
      </li>
      <li class="nav-heading">Transactions</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="loans.php">
          <i class="bi bi-dash-circle"></i>
          <span>Loans</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emis.php">
          <i class="bi bi-file-earmark"></i>
          <span>EMI List</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="ledgerTrans.php">
          <i class="bi bi-dash-circle"></i>
          <span>Ledger Transaction</span>
        </a>
      </li>
///////////////////
      <li class="nav-heading">Report</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emiOutstandingReport.php">
          <i class="bi bi-dash-circle"></i>
          <span>EMI Outstanding Report</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="loans.php">
          <i class="bi bi-file-earmark"></i>
          <span>Loan Allocation Report</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emisIndividual.php">
          <i class="bi bi-file-earmark"></i>
          <span>Individual EMI Register</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emiCollectionReport.php">
          <i class="bi bi-dash-circle"></i>
          <span>EMI Collection Report</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="ledgerTrans.php">
          <i class="bi bi-file-earmark"></i>
          <span>Ledger Display</span>
        </a>
      </li>
      <li class="nav-heading">User</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="settings.php">
          <i class="bi bi-file-earmark"></i>
          <span>Setting</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="logout.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Logout</span>
        </a>
      </li><!-- End Login Page Nav -->

    </ul>

  <?php
  }
  else 
  {
?>
<ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-heading">Master</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="customers.php">
          <i class="bi bi-person"></i>
          <span>Customers</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="groups.php">
          <i class="bi bi-person"></i>
          <span>Groups</span>
        </a>
      </li>
      <li class="nav-heading">Transactions</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="loans.php">
          <i class="bi bi-dash-circle"></i>
          <span>Loans</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emiCollections.php">
          <i class="bi bi-file-earmark"></i>
          <span>EMI Collection</span>
        </a>
      </li>
      <li class="nav-heading">Report</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="emiCollected.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Collected EMI </span>
        </a>
      </li><!-- End Login Page Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="ledgerTrans.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Ledger Transaction</span>
        </a>
      </li><!-- End Login Page Nav -->
      <li class="nav-heading">User</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="logout.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Logout</span>
        </a>
      </li><!-- End Login Page Nav -->
 
    </ul>
<?php 
  }
}
?>