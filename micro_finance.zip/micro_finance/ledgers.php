<?php 
include('headers.php'); 
include('includes/db.php'); 


if(isset($_GET['lastPage']))
{
  if(isset($_COOKIE['pgSize']))
    $Intv=(int)$_COOKIE['pgSize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$Select_sql = "SELECT count(`LedgerID`) as C  FROM `ledger_master`";
$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  $lastPage=ceil($count/$Intv);
  setcookie("LedgerPageNo", $lastPage, time() + 3600);
}

?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Ledgers</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Ledger</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Ledger   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          
                        </div>
                        <div class="col-lg-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showLedgerList(1)">
                        </div>
                      </fieldset>
                   </div>
                   <a href="ledger_edit.php">Add New</a> &nbsp; &nbsp; &nbsp;
                   <a href="ledgerAmountTarnsfer.php">Transfer Amount between ledgers</a>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">ID</th>
                    <th scope="col">Ledger Name</th>
                    <th scope="col">Balance</th>
                    <th scope="col">Ledger Type</th>
                    <th scope="col">-</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  function delete_Ledger(LedgerID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteLedger.php?ID='+LedgerID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showLedgerList(curPage)
{

  var name = $('#src_name').val();
  var Ledger_Sl = $('#Ledger_Sl').val();
  var xmlhttp=new XMLHttpRequest();

  $('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
setCookie('LedgerPageNo',curPage,7);
//console.log("getLedgerList.php?page="+curPage+"&name="+name);
  xmlhttp.open("GET","getLedgerList.php?page="+curPage+"&name="+name,true);
  xmlhttp.send();
}


var pageNo=getCookie('LedgerPageNo');
if(pageNo=='')
  pageNo=1;

showLedgerList(pageNo);

function setCustPageSize(a)
{
document.cookie="pgSize="+a; 
showLedgerList(1);
}

function setCustPageNumber(a)
{
showLedgerList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}
</script>
<?php 
include('end_html.php');
?>
