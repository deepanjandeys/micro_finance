<?php 
include('headers.php'); 
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Ledger Types</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Ledger Type</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Ledger Type   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-3">
                          Name
                        </div>
                        <div class="col-3">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        <div class="col-3">
                          
                        </div>
                        <div class="col-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showLedgerTypeList(0)">
                        </div>
                      </fieldset>
                   </div>
                   <a href="ledgerType_edit.php">Add New</a>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">ID</th>
                    <th scope="col">Ledger Type Name</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  function delete_LedgerType(LedgerTypeID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteLedgerType.php?ID='+LedgerTypeID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showLedgerTypeList(curPage)
{

  var name = $('#src_name').val();
  var LedgerType_Sl = $('#LedgerType_Sl').val();
  var xmlhttp=new XMLHttpRequest();

$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
 
console.log("getLedgerTypeList.php?page="+curPage+"&name="+name);
  xmlhttp.open("GET","getLedgerTypeList.php?page="+curPage+"&name="+name,true);
  xmlhttp.send();
}

showLedgerTypeList(0);

function setCustPageSize(a)
{
document.cookie="pgSize="+a; 
showLedgerTypeList(0);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}
</script>
<?php 
include('end_html.php');
?>
