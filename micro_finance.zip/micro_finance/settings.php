<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$id=''; $organisation_name=''; 
$Action="Add new";
$ActionButton="Save";

$SelSql="SELECT `id`, `organisation_name` FROM `meta_info` WHERE `id`=1";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }

?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Setting</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Setting</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Setting <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveSetting.php" method="post">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="row mb-3">
                  <label for="organisation_name" class="col-sm-2 col-form-label">Organisation Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="organisation_name" name="organisation_name" value="<?php echo $organisation_name; ?>" required>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-3">
                    Session
                  </div>
                  <div class="col-9 form-check form-switch">

                    <?php
                    if(isset($_SESSION['error_message']))
                    {
                      echo '<span style="color:red;font-weight:bold;">'.$_SESSION['error_message'].'</span>';
                      unset($_SESSION['error_message']);
                    } 
$Select_sql ="SELECT `id`, `name`, `start_date`, `end_date`, `active` FROM `session_master` ";
$result = mysqli_query($db,$Select_sql);
$tblSessions='There is no Session ';
$activeStr='';
if(mysqli_num_rows($result)>0)
{
$tblSessions=<<<tblect_Sessions
<table class="table"><tr><th>ID</th><th>Name</th><th>Start Date</th><th>End Date</th><th colspan="2">Action</th></tr>
tblect_Sessions;
while ($row = mysqli_fetch_array($result))
    {
    $id=$row['id'];
    $Name=$row['name'];
    $start_date=$row['start_date'];
    $end_date=$row['end_date'];
    $active=$row['active'];
if($active=='1')
{
  $activeStr='checked';
}
else 
{
  $activeStr='';
}

        $start_date=date('d-M-Y',strtotime($start_date));
        $end_date=date('d-M-Y',strtotime($end_date));

$tblSessions.=<<<tblect_Sessions
<tr><td>$id</td><td>$Name</td><td>$start_date</td><td>$end_date</td><td><input type='radio' class='form-check-input' name='rdb_active' $activeStr /></td><td><a href="session_edit.php?id=$id">Edit</a>&nbsp;<a href='javascript:void(0)' onClick='delete_session($id)'>Delete</a></td></tr>
tblect_Sessions;
  } 
$tblSessions.=<<<tblect_Sessions
</table>
</datalist> 
tblect_Sessions;
}
?>
                     <?php echo $tblSessions; ?>

                  </div>
                </div>
                 
                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <a href="session_edit.php" class="btn btn-primary">Add New Session</a>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">

  function delete_session(SessionID)
  {
    if(confirm('Do you want to Delete session'))
    {
      location.replace('deleteSession.php?id='+SessionID);
    }
    else 
    {
      //alert('not deleted');
    }
}

</script>

<?php 
include('end_html.php');
?>
