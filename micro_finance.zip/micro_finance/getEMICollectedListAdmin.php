<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');
 
$page=0;

    $CID='';            $agent='';          $loan_opr='';       $Loan_Amount=""; 
    $EMIPrinci_opr='';  $EMI_Principal='';  $EMIInterst_opr=''; $EMIInterest='';
    $FineAmount_opr=''; $Fine_Amount='';    $PaymentMode='';    
    $EMI_DueDateFrom='';$EMI_DueDateTo='';  $emiNo='';  $rdbDay='';

extract($_GET);

$CIDStr='';
if($CID<>'')
{
    $CIDStr=" and  lr.`CID`=$CID";
}

$GIDStr='';
if($GID<>'')
{
    $GIDStr=" and  lr.`groupID`=$GID";
}

$agentStr='';
if($agent<>'')
{
    $agentStr=" and a.agentID =".$agent." ";
}

$EMI_PrincipalStr='';

if($EMI_Principal<>'')
{
    $EMI_PrincipalStr=" and e.EMIPrincipal $EMIPrinci_opr ".$EMI_Principal." ";
}

$EMIInterestStr='';
if($EMIInterest<>'')
{
    $EMIInterestStr=" and e.EMIInterest $EMIInterst_opr ".$EMIInterest." ";
}

$Fine_AmountStr='';
if($Fine_Amount<>'')
{
    $Fine_AmountStr=" and e.Fine $FineAmount_opr ".$Fine_Amount." ";
}

$PaymentModeStr='';
if($PaymentMode<>'')
{
    $PaymentModeStr=" and e.EMIPayMode =".$PaymentMode;
}


$Loan_AmountStr='';

if($Loan_Amount<>'')
{
    $Loan_AmountStr=" and lr.`LoanAmt` $loan_opr ".$Loan_Amount." ";
}


$LoanTypeStr='';
$LoanType=(int)$LoanType;

if($LoanType >0)
{
    if($LoanType==1)
        $LoanTypeStr=" and lr.LoanType = 1 ";
    else if($LoanType==2)
        $LoanTypeStr=" and lr.LoanType = 2 ";
    else if($LoanType==3)
        $LoanTypeStr=" and lr.LoanType in(1,2) ";
}

date_default_timezone_set("Asia/Kolkata");

$EMI_DueDateStr='';
if($EMI_DueDateFrom<>'' && $EMI_DueDateTo<>'')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateTo =date('Y-m-d',strtotime($EMI_DueDateTo));

    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateTo."'";
}
else if($EMI_DueDateFrom<>'')
{
    $EMI_DueDateFrom=date('Y-m-d',strtotime($EMI_DueDateFrom));
    $EMI_DueDateStr=" and e.`dueDate` between '".$EMI_DueDateFrom."' and '".$EMI_DueDateFrom."'";
}

if(isset($_COOKIE['pgECRsize']))
    $Intv=(int)$_COOKIE['pgECRsize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;

if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT e.`txnID`,e.`emiNo`, e.`txnDateTime`, e.`dueDate`, e.`EMIPrincipal`, e.`EMIInterest`, e.`Fine`, e.`LoanRegNo`, a.`AgentName`, e.`EMIPayMode`, e.`Remarks`, cp.`CustName`,lr.`LoanAmt`, DATEDIFF(NOW(), e.`dueDate`) as NoOfDays,lr.`FineAmount`,g.`GroupName`,`LoanType` FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` LEFT JOIN `group_master` AS g ON lr.`groupID`=g.`GID` WHERE `txnDateTime` is not null $CIDStr $GIDStr $LoanTypeStr  $agentStr $EMI_PrincipalStr $EMIInterestStr $Fine_AmountStr $PaymentModeStr $EMI_DueDateStr Having NoOfDays>=0 Order By e.`txnID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
               $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        if($EMIPayMode=='1')
            $EMIPayModeStr='Daily';
        else if($EMIPayMode=='2')
            $EMIPayModeStr="Weekly";
        else if ($EMIPayMode=='3')
            $EMIPayModeStr="Monthly";
        if($txnDateTime !='')
            $txnDateTime = date('d-m-Y',strtotime($txnDateTime));
        $dueDate = date('d-m-Y',strtotime($dueDate));
        

        if($LoanType=='1')
            $LoanType='Personal loan';
        else if($LoanType=='2')
            $LoanType='Group loan';
        else  
            $LoanType='';

        if($Fine=='')
        {
            $Fine = number_format((float)$FineAmount * (int) $NoOfDays,2);
            $Fine = "<span title='$FineAmount x $NoOfDays'>$Fine</span>";
        }
        else 
        {
            $Fine ="<span class='text-primary'>$Fine</span>";
        }

        $EMI="<span title='$EMIPrincipal + $EMIInterest'>".number_format($EMIPrincipal+$EMIInterest,2)."</span>";

        echo "<tr>
                    <th scope='row'><a href='emi_edit.php?txnID=$txnID&callBy=3'>Edit</a>
                    </th>
                    <td>$txnID</td>
                    <td>$emiNo</td>
                    <td>$txnDateTime</td>
                    <td>$dueDate</td>
                    <td style='text-align:right'>$EMI</td>
                    <td style='text-align:right'>$Fine</td>
                    <td>$EMIPayModeStr</td>
                    <td>$AgentName</td>
                    <td>$CustName</td>
                    <td>$LoanRegNo</td>
                    <td>$GroupName</td>
                    <td>$LoanType</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(e.`txnID`) as C,sum(e.`EMIPrincipal`+e.`EMIInterest`) as sumEMI,sum(`Fine`) as sumFine FROM `emi_register` as e JOIN `loan_register` as lr ON e.`LoanRegNo`=lr.`LoanRegNo` LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `agent_profile` AS a ON e.`agentId`=a.`agentId` WHERE DATEDIFF(NOW(), e.`dueDate`)>=0 and `txnDateTime` is not null $CIDStr $GIDStr $LoanTypeStr $agentStr $EMI_PrincipalStr $EMIInterestStr $Fine_AmountStr $PaymentModeStr $EMI_DueDateStr ";

$sumEMI=0; $sumFine=0;
if($rdbDay=='t'){
    $rdbDayStr='Today';
}
elseif ($rdbDay=='w') {
    $rdbDayStr='this Week';
}
elseif ($rdbDay=='m') {
    $rdbDayStr='this Month';
}
elseif ($rdbDay=='s') {
    $rdbDayStr='this Session';
}
else {
    $rdbDayStr='';
}

$result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                {
                    $count=$row['C'];
                    $sumEMI=$row['sumEMI'];
                    $sumFine=$row['sumFine'];
                }

echo '<tr><td colspan="5" style="text-align:right;">Total EMI to be collected '.$rdbDayStr.' : </td><td style="text-align:right;">';
echo number_format($sumEMI,2);
echo '</td><td  colspan="8"></tr>';
//////////////////////
echo '<tr><td colspan="5" style="text-align:right;">Fine '.$rdbDayStr.' : </td><td style="text-align:right;">';
echo number_format($sumFine,2);
echo '</td><td  colspan="8"></tr>';

echo '<tr><td colspan="5" style="text-align:right;">Net EMI collected  '.$rdbDayStr.' : </td><td style="text-align:right;">';
echo number_format($sumFine,2);
echo '</td><td  colspan="8"></tr>';
echo '<tr><td colspan="8">';
//echo "$Select_sql";
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];

$lnks= get_pagination_links($page,'showEMIList',$count,$Intv);
echo $lnks;
echo "</td></tr>";
?>