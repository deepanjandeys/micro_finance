<?php 
include('headers.php'); 
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Groups</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Group</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Group   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        
<div class="col-lg-2"> Agent</div>
<div class="col-lg-2 col-sm-9 col-xs-9 px-2">
 <?php
$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile`";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<select id="selAgent" style="width:200px;">
  <option value=''>Select Agent</option>
Select_Agents;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}
echo $selAgents;
?>
</div>

                        <div class="col-lg-2" style="text-align:right;">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showGroupList(0)">
                        </div>
                      </fieldset>
                   </div>
                   <a href="group_edit.php">Add New</a>
              <div class="table-responsive">  
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">GID</th>
                    <th scope="col">Group Name</th>
                    <th scope="col">Agent</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">

   $(document).ready(function(){
            $('#selAgent').select2();
        });

  function delete_Group(groupID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteGroup.php?GID='+groupID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showGroupList(curPage)
{

  var name = $('#src_name').val();
  var agentId = $('#selAgent').val();

  var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
 console.log("getGroupList.php?page="+curPage+"&name="+name+"&agentId="+agentId);
  xmlhttp.open("GET","getGroupList.php?page="+curPage+"&name="+name+"&agentId="+agentId,true);
  xmlhttp.send();
}

showGroupList(0);

function setCustPageSize(a)
{
document.cookie="pgSize="+a; 
showgroupList(0);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}
</script>
<?php 
include('end_html.php');
?>
