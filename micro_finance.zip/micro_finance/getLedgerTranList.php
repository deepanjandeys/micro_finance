<?php 
@session_start();

include('includes/db.php');
include('includes/functions.php');
$ledgerID='';
extract($_GET);
$ledgerID=(int)$ledgerID;


if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$TranDateStr='';
if($TranDateFrom<>'' && $TranDateTo<>'')
{
    $TranDateFrom=date('Y-m-d',strtotime($TranDateFrom));
    $TranDateTo =date('Y-m-d',strtotime($TranDateTo));
$TranDateStr=" and DATE_FORMAT(l.`tdate`,'%Y-%m-%d') between '".$TranDateFrom."' and '".$TranDateTo."'";
}
else if($TranDateFrom<>'' && $TranDateTo=='')
{
    $TranDateFrom=date('Y-m-d',strtotime($TranDateFrom));
$TranDateStr="and DATE_FORMAT(l.`tdate`,'%Y-%m-%d') between '".$TranDateFrom."' and '".$TranDateFrom."'";
}
else if($TranDateFrom=='' && $TranDateTo<>'')
{
    $TranDateTo =date('Y-m-d',strtotime($TranDateTo));
    $TranDateStr=" and DATE_FORMAT(l.`tdate`,'%Y-%m-%d') <= '".$TranDateTo."'";
}

$SelSql="SELECT lt.`id`, lt.`debit`, lt.`credit`,lm.`LedgerName` as Particuler,l.`tdate`,l.`remarks`,lt.`balance` FROM `ledgertran` as lt JOIN `ledger` as l ON  lt.`tid`=l.`tid` join `ledger_master` AS lm ON lm.`LedgerID`=lt.`particularsid` WHERE lt.`LEDGERID`=$ledgerID $TranDateStr Order By lt.`id` LIMIT ".$start.','.$Intv.";";

//echo "<br>".$SelSql;
   $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        $tdate=date('d-M-Y h:i:s A',strtotime($tdate));
        $debit=number_format($debit,2);
        $credit=number_format($credit,2);
        $balance=number_format($balance,2);
        echo "<tr>
                    <td>$id</td>
                    <td>$Particuler</td>
                    <td style='text-align:right;'>$debit</td>
                    <td style='text-align:right;'>$credit</td>
                    <td>$tdate</td>
                    <td style='text-align:right;'>$balance</td>
                    <td>$remarks</td>
              </tr>";
        }
    } 
              
$Select_sql = "SELECT count(`id`) as C  FROM `ledgertran` as lt JOIN `ledger` as l ON  lt.`tid`=l.`tid` join `ledger_master` AS lm ON lm.`LedgerID`=lt.`particularsid` WHERE lt.`LEDGERID`=$ledgerID $TranDateStr ";

echo '<tr><td colspan="8">';
//echo $Select_sql;
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    
$lnks= get_pagination_links($page,'showLedgerTranList',$count,$Intv);
echo $lnks;

echo "</td></tr>";
?>