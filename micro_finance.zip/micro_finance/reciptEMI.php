<style type="text/css">
a {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
/*    float: right;*/
}

a
{
    -webkit-appearance: button;
}
a
{
    overflow: visible;
}
</style>
<?php
include('includes/db.php');  

$txnID='1104';          $txnDateTime='';    $dueDate='';    $EMIPrincipal='';
$EMIInterest='';    $Fine='';           $LoanRegNo='';  $agentId='';    
$EMIPayMode='';     $Remarks='';        $emiNo=0;       $CustName='';
$LoanAmt=0;     $EMI=0;
extract($_GET);

$sql = "SELECT `txnID`, `txnDateTime`, `emiNo`,`dueDate`, `EMIPrincipal`, `EMIInterest`, `Fine`, `LoanRegNo`, `agentId`, `EMIPayMode`, `Remarks`, `crt_dat_time`, `mdf_dat_tim` FROM `emi_register` WHERE `TxnID`=$txnID;";

//echo '<br>'.$sql;
	$Recordset = mysqli_query($db,$sql);
	
if(mysqli_num_rows($Recordset))
{
	$row=mysqli_fetch_assoc($Recordset);
	extract ($row);
}
$EMI =$EMIPrincipal + $EMIInterest;

$sql="SELECT max(`emiNo`) as TotalEMI FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo;";

$sqlTotEmi=mysqli_query($db,$sql);
if(mysqli_num_rows($sqlTotEmi))
{
	$rowTotEmi=mysqli_fetch_array($sqlTotEmi);
	$totalEMI=$rowTotEmi['TotalEMI'];
}

$emoNoNext = $emiNo+1;

$sql="SELECT `dueDate` as `nextDueDate` FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo and `emiNO`=$emoNoNext;";

$sqlNextDueDate=mysqli_query($db,$sql);
if(mysqli_num_rows($sqlNextDueDate))
{
    $rowNextDueDate=mysqli_fetch_array($sqlNextDueDate);
    $nextDueDate=$rowNextDueDate['nextDueDate'];
}

$sql="SELECT sum('EMIPrincipal') + sum('EMIInterest') as `totEMIRecive` FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo and `txnDateTime` is NOT null;";

$sqltotEMIRecive=mysqli_query($db,$sql);
if(mysqli_num_rows($sqltotEMIRecive))
{
    $rowtotEMIRecive=mysqli_fetch_array($sqltotEMIRecive);
    $totEMIRecive=$rowtotEMIRecive['totEMIRecive'];
}



$sql="SELECT `CustName`,`loanType`,`LoanAmt`,`CloseDate` FROM `loan_register` as l JOIN `customer_profile` as c ON l.`CID`=c.`CID` WHERE  `LoanRegNo`=$LoanRegNo;";

$sqlLoan=mysqli_query($db,$sql);
if(mysqli_num_rows($sqlLoan))
{
    $rowLoan=mysqli_fetch_array($sqlLoan);
    extract($rowLoan);
}

if($loanType=='1')
    $typeStr='Personal';
else if($loanType=='2')
    $typeStr='Group';
else  
    $typeStr='';
?>
<!-- <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> -->
<div style="text-align: :center;">
    <br/>
<a href="rawbt:
%20%20%20%20%20%MICRO FINANCE EMI RECEIPT %0A%0A
DT & TM 	:		%20%20<?php echo date('d.m.Y H:i:s',strtotime($txnDateTime));?>%0A
LOAN CODE	:		%20%20<?php echo $LoanRegNo; ?>%0A
AGENT CODE	: 		%20%20<?php echo $agentId; ?>%0A
LOAN. TYPE	:		%20%20%20%20<?php echo $typeStr;?>%0A
RECEIPT NO.	:		%20%20<?php echo $txnID;?>%0A
EMI NO	:		    %20%20<?php echo $emiNo;?>/<?php echo $totalEMI;?>%20%20%0A
EMI AMT. :       %20%20<?php echo $EMI;?>%0A
FINE AMT. :       %20%20<?php echo $Fine;?>%0A
NAME :		<?php echo $CustName;?>%0A
DUE DATE.	:<?php echo date('d-m-Y',strtotime($dueDate));?>%0A
NEXT DUE DATE.  :<?php echo date('d-m-Y',strtotime($nextDueDate));?>%0A
TOT. RECV. AMT.	:<?php echo $totEMIRecive;?>%0A
LOAN AMT.	:<?php echo $LoanAmt;?>%0A
CLOSE DT.   :<?php echo date('d-m-Y',strtotime($CloseDate));;?>%0A
" class="styled printMobile" style="Font-Size:60px; Font-Weight: Bold;" id="print1" > Print </a><br/><br/><br/><br/><br/><br/>
<a href="emiCollections.php" style="Font-Size:60px; Font-Weight: Bold;">Cancel</a>
</div>

<script>
//document.getElementById("print1").click();
//window.close();
</script>