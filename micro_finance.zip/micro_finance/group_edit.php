<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
</aside><!-- End Sidebar-->
<?php 
$GroupName=''; $GID ='0'; $agentID=0;
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['GID']))
{
$GID=(int)$_GET['GID'];
 $SelSql="SELECT  `GID`, `GroupName`,`agentID` FROM `group_master` WHERE `GID`=$GID";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Group </h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Group </li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Group <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveGroup.php" method="post">
                <input type="hidden" name="GID" value="<?php echo $GID; ?>">
                <div class="row mb-3">
                  <label for="Name" class="col-sm-2 col-form-label">Group  Name </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="Name" name="Name" value="<?php echo $GroupName; ?>" required>
                  </div>
                </div>
                              
<?php  
  $Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile`";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<select id="selAgent" name='agentId' class="from-control" style="width:200px;">
  <option value=''>Select Agent</option>
Select_Agents;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}
?>
<div class="row mb-3">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Agent Id</label>
                  <div class="col-sm-4">
                    <?php echo $selAgents; ?>
                  </div>
    <div class="col-sm-6">
                    <span id='spnAgentname'></span>
    </div>
</div>

                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  
 $(document).ready(function(){
        $('#selAgent').select2();
        });

<?php  
if($ActionButton=='Update')
{
?>
$('#selAgent').val(<?php echo $agentID;?>);
<?php 
}
?>

</script>

<?php 
include('end_html.php');
?>
