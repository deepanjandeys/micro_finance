<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');  

$agentId='';
  $agentIdReadOnly='';
  $whereClausCustomer='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $agentIdReadOnly='readonly';
      $whereClausCustomer=" and `agentId`=$agentId";
    }
}
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Loans</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Loan</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Loan   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Book ID 
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                         <input type="text" id="src_BookId" class="form-control">
                        </div>
                        <div class="col-lg-3 d-none">
                          Loan Amount
                        </div>
                        <div class="col-lg-1 d-none">
                          <select class="form-control" id="src_loan_opr">
                            <option>=</option>
                            <option>></option>
                            <option>>=</option>
                            <option><</option>
                            <option><=</option>
                            <option> != </option>
                          </select>
                        </div>
                        <div class="col-lg-2 col-sm-9 col-xs-9 d-none">
                          <input type="text" id="src_Loan_Amount" class="form-control">
                        </div>
<!--         -->
<div class="col-lg-3">
                          EMI Payment Mode
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
$Select_sql ="SELECT `ID`, `Name` FROM `payment_modes` ";

$result = mysqli_query($db,$Select_sql);

$selPaymentModes='There is no EMI Type ';

if(mysqli_num_rows($result)>0)
{
$selPaymentModes=<<<select_PaymentModes
<select id="src_PayMode" name='src_PayMode' class="from-control" style="width:200px;">
  <option value="">Select Paymode</option>
select_PaymentModes;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['ID'];
    $Name=$row['Name'];
    
$selPaymentModes.=<<<select_PaymentModes
<option value='$Code'>$Name</option>
select_PaymentModes;
  } 
$selPaymentModes.=<<<select_PaymentModes
</select> 
select_PaymentModes;
}

echo $selPaymentModes;
?>
<span id='spnPaymentMode_Name'></span>
                        </div>
                      <!--  -->

                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Loan Type
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                        <input type="checkbox" id="src_LoanType1" class="form-check-input" > <label for="src_LoanType1">Personal</label> 
                        <input type="checkbox" id="src_LoanType2" class="form-check-input"> <label for="src_LoanType2">Group</label>
                        </div>
                        <div class="col-lg-3">
                          Group
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
$Select_sql ="SELECT `GID`, `GroupName` FROM `group_master` WHERE 1 $whereClausCustomer";
$result = mysqli_query($db,$Select_sql);
$selGroups='There is no Group';
if(mysqli_num_rows($result)>0)
{
$selGroups=<<<select_Groups
<select id="selGroup" name='GID' class="from-control" style="width:200px;">
  <option value="">Select Group</option>
select_Groups;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['GID'];
    $Name=$row['GroupName'];
    
$selGroups.=<<<select_Groups
<option value='$Code'>$Name</option>
select_Groups;
  } 
$selGroups.=<<<select_Groups
</select> 
select_Groups;
}

echo $selGroups;
?>
    <span id='spnGID_Name'></span>
    </div>
</div>
<div class="row py-1">
<div class="col-lg-3">Agent</div>
<div class="col-lg-3 col-sm-9 col-xs-9">
 <?php

$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile` WHERE 1 $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<select id="selAgent" style="width:200px;">
Select_Agents;
if($agentId=='')
{
$selAgents.=<<<Select_Agents
  <option value=''>Select Agent</option>
Select_Agents;
}

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}
echo $selAgents;
?>

    <span id='spnAgentname'></span>
 
</div>
                        <div class="col-lg-3">
                            Customer Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                         <?php 

$Select_sql ="SELECT `CID`, `CustName` FROM `customer_profile` WHERE 1 $whereClausCustomer ";
$result = mysqli_query($db,$Select_sql);
$selCustomers='There is no Customer';
if(mysqli_num_rows($result)>0)
{
$selCustomers=<<<select_Customers
<select id="selCust" style="width:200px;">
  <option value=''>Select Customer</option>
select_Customers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['CID'];
    $Name=$row['CustName'];
    
$selCustomers.=<<<select_Customers
<option value='$Code'>$Name</option>
select_Customers;
  } 
$selCustomers.=<<<select_Customers
</select> 
select_Customers;
}
echo $selCustomers;
?>
<span id='spnCustName'></span>

</div>
</div>
<div class="row py-1">
                       <div class="col-lg-3">
                          Loan Status
                        </div>
                        <div class="col-lg-3">
                          <select id="src_LoanStatus" class="form-control">
                            <option value=""></option>
                            <option value="2">InActive</option>
                            <option value="1">Active</option>
                            <option value="0">Start</option>
                          </select>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Loan Date
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_LoanDate_from" class="form-control" placeholder="dd-mm-yyyy" >
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_LoanDate_to" class="form-control" placeholder="dd-mm-yyyy" >
                        </div>
                        <div class="col-lg-3">
                          
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Close Date
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_CloseDate_from" class="form-control" placeholder="dd-mm-yyyy" >
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_CloseDate_to" class="form-control" placeholder="dd-mm-yyyy" >
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showLoanList(1)">
                        </div>
                      </div>
                      </fieldset>
                   </div>
                   <a href="loan_edit.php">Add New</a>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">LoanRegNo</th>
                    <th scope="col">CustName</th>
                    <th scope="col">LoanAmt</th>
                    <th scope="col">Loan Type</th>
                    <th scope="col">Group</th>
                    <th scope="col">BookId</th>
                    <th scope="col">EMIPrincipal</th>
                    <th scope="col">EMIInterest</th>
                    <th scope="col">FineAmount</th>
                    <th scope="col">EMIPayMode</th>
                    <th scope="col">LoanDate</th>
                    <th scope="col">LoanStatus</th>
                    <th scope="col">CloseDate</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">

   $(document).ready(function(){
            $('#selCust').select2();
            $('#selAgent').select2();
            $('#selGroup').select2();
            $('#src_PayMode').select2();
            
        });

  function delete_Loan(LoanID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteLoan.php?LoanID='+LoanID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showLoanList(curPage)
{
//debugger;
  var BookId=$('#src_BookId').val();
  // var loan_opr=$('#src_loan_opr').val();
  // var Loan_Amount=$('#src_Loan_Amount').val();

  // var EMIPrinci_opr=$('#src_EMIPrinci_opr').val();
  // var EMIPrincipal=$('#src_EMIPrincipal').val();

  // var FineAmount_opr=$('#src_FineAmount_opr').val();
  // var FineAmount=$('#src_FineAmount').val();
  
  // var EMIInterst_opr=$('#src_EMIInterst_opr').val();
  // var EMIInterest=$('#src_EMIInterest').val();

  var PaymentMode=$('#src_PayMode').val();
  var LoanStatus=$('#src_LoanStatus').val();
  var LoanDate_from = $('#src_LoanDate_from').val();
  var LoanDate_to = $('#src_LoanDate_to').val();
  var CloseDate_from = $('#src_CloseDate_from').val();
  var CloseDate_to = $('#src_CloseDate_to').val();
  var CID= $('#selCust').val();
  if(CID==undefined)
    CID='';
  var GID= $('#selGroup').val();
  if(GID==undefined)
    GID='';
  
  var agentId= $('#selAgent').val();
  var LoanType=0;
  if($('#src_LoanType1').is(':checked'))
  {
    LoanType+=1;
  }
  if($('#src_LoanType2').is(':checked'))
  {
    LoanType+=2;
  }

$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');

var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);

      var CurPage=parseInt($('#txtCurPage').val());
      var totalPage=parseInt($('#spn_totalPage').html());
      if(CurPage>totalPage)
      {
        showLoanList(totalPage);
      }
  
    }
  }

setCookie('LoanPageNo',curPage,7);
/*
"getLoanList.php?page="+curPage+"&CID="+CID+"&agentId="+agentId+"&GID="+GID+"&BookId="+BookId+"&loan_opr="+loan_opr+"&Loan_Amount="+Loan_Amount+"&EMIPrinci_opr="+EMIPrinci_opr+"&EMIPrincipal="+EMIPrincipal+"&EMIInterst_opr="+EMIInterst_opr+"&EMIInterest="+EMIInterest+"&FineAmount_opr="+FineAmount_opr+"&FineAmount="+FineAmount+"&LoanStatus="+LoanStatus+"&PaymentMode="+PaymentMode+"&LoanDate_from="+LoanDate_from+"&LoanDate_to="+LoanDate_to+"&CloseDate_from="+CloseDate_from+"&CloseDate_to="+CloseDate_to+"&LoanType="+LoanType
*/
  xmlhttp.open("GET","getLoanList.php?page="+curPage+"&CID="+CID+"&agentId="+agentId+"&GID="+GID+"&BookId="+BookId+"&LoanStatus="+LoanStatus+"&PaymentMode="+PaymentMode+"&LoanDate_from="+LoanDate_from+"&LoanDate_to="+LoanDate_to+"&CloseDate_from="+CloseDate_from+"&CloseDate_to="+CloseDate_to+"&LoanType="+LoanType,true);
  xmlhttp.send();
}
//debugger;

<?php  
if(isset($_SESSION['lastPage']))
{
  if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;
if($whereClausCustomer !='' )
{
  $whereClausCustomer=" and CID in(SELECT `CID` FROM `customer_profile` WHERE `agentId`='".$agentId."')";
}

$Select_sql = "SELECT count(`LoanRegNo`) as C  FROM `loan_register` WHERE 1 $whereClausCustomer;";
//echo $Select_sql;

$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  
  $lastPage=ceil($count/$Intv);

echo 'showLoanList('.$lastPage.');';
unset($_SESSION['lastPage']);
} 
else
{
?>
var pageNo=getCookie('LoanPageNo');
if(pageNo=='')
  pageNo=1;

showLoanList(pageNo);
<?php  
}
?>
function setCustPageSize(a)
{
document.cookie="pgZize="+a; 
showLoanList(1);
}

function setCustPageNumber(a)
{
//document.cookie="pgSizeC="+a; 
showLoanList(a);
}


function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}


$('#src_LoanDate_from').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_LoanDate_to').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


$('#src_CloseDate_from').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_CloseDate_to').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#src_LoanDate_from').val('');
$('#src_LoanDate_to').val('');
$('#src_CloseDate_from').val('');
$('#src_CloseDate_to').val('');

</script>
<?php 
include('end_html.php');
?>