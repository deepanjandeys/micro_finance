<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$CID="";            $GID="";            $BookId="";         $loan_opr='';  
$Loan_Amount="";    $EMIPrinci_opr='';  $EMIPrincipal="";   $EMIInterst_opr='';  
$EMIInterest="";    $FineAmount_opr=''; $FineAmount='';     $LoanStatus="";
$PaymentMode="";    $LoanDate_from="";  $LoanDate_to="";    $CloseDate_from=""; 
$CloseDate_to="";   $LoanType="";       $agentId='';

extract($_GET);

$CIDStr='';
if($CID<>'')
{
    $CIDStr=" and lr.CID = '".$CID."' ";
}

$agentIdStr='';
if($agentId<>'')
{
    $agentIdStr=" and lr.CID in(SELECT `CID` FROM `customer_profile` WHERE `agentId`='".$agentId."')";
}

$GIDStr='';
if($GID<>'')
{
    $GIDStr=" and GroupID = '".$GID."' ";
}


$LoanTypeStr='';
$LoanType=(int)$LoanType;

if($LoanType >0)
{
    if($LoanType==1)
        $LoanTypeStr=" and lr.LoanType = 1 ";
    else if($LoanType==2)
        $LoanTypeStr=" and lr.LoanType = 2 ";
    else if($LoanType==3)
        $LoanTypeStr=" and lr.LoanType in(1,2) ";
}

$BookIdStr='';

if($BookId<>'')
{
    $BookIdStr=" and lr.BookId = '".$BookId."' ";
}

$Loan_AmountStr='';
if($Loan_Amount<>'')
{
    $Loan_AmountStr=" and lr.LoanAmt $loan_opr '".$Loan_Amount."' ";
}

$EMIPrincipalStr='';
if($EMIPrincipal<>'')
{
    $EMIPrincipalStr=" and lr.EMIPrincipal $EMIPrinci_opr '".$EMIPrincipal."' ";
}

$EMIInterestStr='';
if($EMIInterest<>'')
{
    $EMIInterestStr=" and lr.EMIInterest $EMIInterst_opr ".$EMIInterest;
}

$LoanStatusStr='';
if($LoanStatus<>'')
{
    $LoanStatusStr=" and lr.LoanStatus = '".$LoanStatus."' ";
}

$PaymentModeStr='';
if($PaymentMode<>'')
{
    $PaymentModeStr=" and lr.EMIPayMode =".$PaymentMode;
}

$FineAmountStr='';
if($FineAmount<>'')
{
    $FineAmountStr=" and lr.FineAmount $FineAmount_opr ".$FineAmount;
}

date_default_timezone_set("Asia/Kolkata");

$LoanDateStr='';
if($LoanDate_from<>'' && $LoanDate_to<>'')
{
    $LoanDate_from=date('Y-m-d',strtotime($LoanDate_from));
    $LoanDate_to =date('Y-m-d',strtotime($LoanDate_to));

    $LoanDateStr=" and lr.LoanDate between '".$LoanDate_from."' and '".$LoanDate_to."'";
}
else if($LoanDate_from<>'')
{
    $LoanDate_from=date('Y-m-d',strtotime($LoanDate_from));
    $LoanDateStr=" and lr.LoanDate between '".$LoanDate_from."' and '".$LoanDate_from."'";
}

////

$CloseDateStr='';
if($CloseDate_from<>'' && $CloseDate_to<>'')
{
    $CloseDate_from=date('Y-m-d',strtotime($CloseDate_from));
    $CloseDate_to =date('Y-m-d',strtotime($CloseDate_to));

    $CloseDateStr=" and lr.CloseDate between '".$CloseDate_from."' and '".$CloseDate_to."'";
}
else if($CloseDate_from<>'')
{
    $CloseDate_from=date('Y-m-d',strtotime($CloseDate_from));
    $CloseDateStr=" and lr.CloseDate between '".$CloseDate_from."' and '".$CloseDate_from."'";
}

if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `LoanRegNo`, `CustName`, `LoanType`,`GroupName`, `LoanAmt`, `BookId`, `EMIPrincipal`, `EMIInterest`, `FineAmount`, pm.`Name` as `EMIPayModeStr`, `LoanDate`, `LoanStatus`, `CloseDate` FROM `loan_register` as lr LEFT JOIN `customer_profile` as cp ON  lr.`CID`=cp.`CID` join `payment_modes` AS pm ON lr.`EMIPayMode`=pm.`ID` LEFT JOIN `group_master` as g ON lr.`groupID`=g.`GID` WHERE 1 $CIDStr $agentIdStr $GIDStr $LoanTypeStr $BookIdStr $Loan_AmountStr $EMIPrincipalStr $EMIInterestStr $FineAmountStr $LoanStatusStr $PaymentModeStr $LoanDateStr $CloseDateStr Order By `LoanRegNo` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
             
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        $LoanDate = date('d-m-Y',strtotime($LoanDate));
        $CloseDate = date('d-m-Y',strtotime($CloseDate));

        if($LoanStatus==0)
            $LoanStatus='InActive';
        else if($LoanStatus==1)
            $LoanStatus='Active';

        if($LoanType=='1')
            $LoanType='Personal loan';
        else if($LoanType=='2')
            $LoanType='Group loan';
        else  
            $LoanType='';

        $s2='<!-- Modal Dialog Scrollable -->
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modalDialogScrollable'.$LoanRegNo.'" onClick="showEMI_List('.$LoanRegNo.')">
                *
              </button>
              <div class="modal fade" id="modalDialogScrollable'.$LoanRegNo.'" tabindex="-1">
                <div class="modal-dialog modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">EMI List of Loan #'.$LoanRegNo.'</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <table class="table">
                        <tr>
                            <th>Loan Type<th><td>'.$LoanType.'</td>
                            <th>Group</th><td>'.$GroupName.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Amount<th><td>'.$LoanAmt.'</td>
                            <th>Fine Amount</th><td>'.$FineAmount.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Loan Date<th><td>'.$LoanDate.'</td>
                            <th>Close Date</th><td>'.$CloseDate.'&nbsp;</td>
                        </tr>
                        <tr>
                            <th>Name<th><td>'.$CustName.'</td>
                            <th>Mode</th><td>'.$EMIPayModeStr.'&nbsp;</td>
                        </tr>
                    </table>
                    <div class="modal-body" id="EMI_list'.$LoanRegNo.'">
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary" onclick="print_EMI('.$LoanRegNo.')">Print</button>
                    </div>
                  </div>
                </div>
              </div><!-- End Modal Dialog Scrollable-->
';
        echo "<tr>
                    <th scope='row'><a href='loan_edit.php?LoanRegNo=$LoanRegNo'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_Loan($LoanRegNo)'>Delete</a></th>
                    <td>$LoanRegNo</td>
                    <td>$CustName</td>
                    <td style='text-align:right'>$LoanAmt</td>
                    <td>$LoanType</td>
                    <td>$GroupName</td>
                    <td>$BookId</td>
                    <td style='text-align:right'>$EMIPrincipal $s2</td>
                    <td style='text-align:right'>$EMIInterest</td>
                    <td style='text-align:right'>$FineAmount</td>
                    <td>$EMIPayModeStr</td>
                    <td>$LoanDate</td>
                    <td>$LoanStatus</td>
                    <td>$CloseDate</td>
                  </tr>";

      //  echo "<tr><td colspan='6'></td><td colspan='6'>&nbsp;$s2</td></tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`LoanRegNo`) as C  FROM `loan_register` as lr WHERE 1  $CIDStr $LoanTypeStr $GIDStr $BookIdStr $Loan_AmountStr $EMIPrincipalStr $EMIInterestStr $FineAmountStr $LoanStatusStr $PaymentModeStr $LoanDateStr $CloseDateStr $agentIdStr";

echo '<tr><td colspan="8">';
//echo $Select_sql;
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    
$lnks= get_pagination_links($page,'showLoanList',$count,$Intv);
echo $lnks;

echo "</td></tr>";
?>