<?php 
include('headers.php'); 
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
<?php include('topMenu.php'); ?>
</header><!-- End Header -->
<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->
  <main id="main" class="main">
    <div class="pagetitle">
      <h1>EMI Collections</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">EMI</li>
          <li class="breadcrumb-item active">Collection</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->
<?php
$agentId='';
  $agentIdReadOnly='';
  $whereClausCustomer='';
if(isset($_SESSION['isAdmin']) && isset($_SESSION['UID']))
{
  if($_SESSION['isAdmin']=='0')
    {
      $agentId=$_SESSION['UID'];
      $agentIdReadOnly='readonly';
      $whereClausCustomer=" and `agentId`=$agentId";
    }
}
$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile` WHERE 1 $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<select id="selAgent" style="width:200px;" readonly>
Select_Agents;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</select> 
Select_Agents;
}  
?>
    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of EMI Collections &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a>
<?php
              $emiCollectedDayChoice=3;
              if(isset($_COOKIE['emiCollectedDayChoice']))
                  $emiCollectedDayChoice=(int)$_COOKIE['emiCollectedDayChoice'];
                $chkToday='';
                $chkWeek='';
                $chkMonth='';
                $chkUntill='';
                
                $toDay = date('d-m-Y');
                $day = date('w');
                //$day++;
                $week_start = date('d-m-Y', strtotime('-'.$day.' days'));
                $week_end = date('d-m-Y', strtotime('+'.(6-$day).' days'));  
                $Month_start = date('01-m-Y');
                $Month_end = date('t-m-Y');

                $EMI_DueDateFrom='';
                $EMI_DueDateTo='';


  $start_date='';
  $end_date='';
$Select_sql = "SELECT `start_date`,`end_date` FROM `session_master` WHERE `active`=1";
$result = mysqli_query($db,$Select_sql);
if(mysqli_num_rows($result)>0)
{
  $row = mysqli_fetch_array($result);
  $start_date=date('d-m-Y',strtotime($row['start_date']));
  $end_date=date('d-m-Y',strtotime($row['end_date']));
}
              if($emiCollectedDayChoice==0)
              {
                $chkToday='checked';

                $EMI_DueDateFrom=$toDay;
                $EMI_DueDateTo=$toDay;
              }
              else if($emiCollectedDayChoice==1)
              {
                $chkWeek='checked';

                $EMI_DueDateFrom=$week_start;
                $EMI_DueDateTo=$week_end;
              }
              else if($emiCollectedDayChoice==2)
              {
                $chkMonth='checked';
                $EMI_DueDateFrom=$Month_start;
                $EMI_DueDateTo=$Month_end;
              }
              else if($emiCollectedDayChoice==3)
              {
                $chkUntill='checked';
                $EMI_DueDateFrom=$start_date;
                $EMI_DueDateTo=$end_date;
              } 
              ?></h5>
              <div class="row">
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" <?php echo $chkToday; ?> id="rdbToday" onclick="setToday()" value="t"><label for="rdbToday">&nbsp; Today</label>
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbWeek" <?php echo $chkWeek; ?> onclick="setWeekDay()" value="w"> <label for="rdbWeek"> this Week</label>
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbMonth" <?php echo $chkMonth; ?> onclick="setMonthDay()" value="m"> <label for="rdbMonth"> this Month</label> 
                </div>
                <div class="col-xs-3 col-lg-3">
                <input type="radio" name="rdbDay" id="rdbUntill" <?php echo $chkUntill;?> onclick="setCurrentSession()" value="s"> <label for="rdbUntill"> Current Session</label>
               </div>
              </div>

                <input type="hidden" id="hdToDay" value="<?php echo $toDay; ?>">

                <input type="hidden" id="hdWeekFrom" value="<?php echo $week_start; ?>">
                <input type="hidden" id="hdWeekTo" value="<?php echo $week_end; ?>">
                <input type="hidden" id="hdMonthFrom" value="<?php echo $Month_start; ?>">
                <input type="hidden" id="hdMonthTo" value="<?php echo $Month_end; ?>">
                <input type="hidden" id="hdStart_date" value="<?php echo $start_date; ?>">
                <input type="hidden" id="hdEnd_date" value="<?php echo $end_date; ?>">

                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                         <div class="col-lg-3">
                          Agent
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
                          echo $selAgents;
                          ?>
                        </div>

                        <div class="col-lg-3">
                          Customer
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
$Select_sql ="SELECT `CID`, `CustName` FROM `customer_profile` WHERE 1 $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);

$selCustomers='There is no Cutomer ';

if(mysqli_num_rows($result)>0)
{
$selCustomers=<<<select_Customers
<select id="selCust"  name="CID" style="width:200px;" required>
  <option value=''>Select Customer</option>
select_Customers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['CID'];
    $Name=$row['CustName'];
    
$selCustomers.=<<<select_Customers
<option value='$Code'>$Name</option>
select_Customers;
  } 
$selCustomers.=<<<select_Customers
</select> 
select_Customers;
}

echo $selCustomers;
?>
  </div>
</div>
<div class="row py-1">
  <div class="col-lg-3">
      Loan Type
  </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                        <input type="checkbox" id="src_LoanType1" class="form-check-input" > <label for="src_LoanType1">Personal</label> 
                        <input type="checkbox" id="src_LoanType2" class="form-check-input"> <label for="src_LoanType2">Group</label>
                        </div>
                        
  <div class="col-lg-3">
                          Group
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
$Select_sql ="SELECT `GID`, `GroupName` FROM `group_master` WHERE 1 $whereClausCustomer";

$result = mysqli_query($db,$Select_sql);

$selGroups='There is no Group';

if(mysqli_num_rows($result)>0)
{
$selGroups=<<<select_Groups
<select id="selGroup" name='GID' class="from-control" style="width:200px;">
  <option value="">Select Group</option>
select_Groups;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['GID'];
    $Name=$row['GroupName'];
    
$selGroups.=<<<select_Groups
<option value='$Code'>$Name</option>
select_Groups;
  } 
$selGroups.=<<<select_Groups
</select> 
select_Groups;
}

echo $selGroups;
?>
      </div>
</div>

                      <div class="row py-1">
                        
                        <div class="col-lg-3">
                          EMI Payment Mode
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <?php 
$Select_sql ="SELECT `ID`, `Name` FROM `payment_modes` ";

$result = mysqli_query($db,$Select_sql);

$selPayModes='There is no EMI Payment Mode ';

if(mysqli_num_rows($result)>0)
{
$selPayModes=<<<select_PayModes
<select id="src_PayMode" name='src_PayMode' class="from-control" style="width:200px;">
  <option value="">Select Paymode</option>
select_PayModes;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['ID'];
    $Name=$row['Name'];
    
$selPayModes.=<<<select_PayModes
<option value='$Code'>$Name</option>
select_PayModes;
  } 
$selPayModes.=<<<select_PayModes
</select> 
select_PayModes;
}

echo $selPayModes;
?>
      </div>
      <div class="col-lg-3">
                          EMI Status
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <select id="src_Status" class="form-control">
                            <option value="0"></option>
                            <option value="1">Unpaid</option>
                            <option value="2">Paid</option>
                          </select>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          EMI Due Date
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_EMI_DueDateFrom" class="form-control" value="<?php echo $EMI_DueDateFrom; ?>">
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" id="src_EMI_DueDateTo" value="<?php echo $EMI_DueDateTo; ?>" class="form-control">
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showEMIList(0)">
                        </div>
                      </div>
                      </fieldset>
                   </div>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">EMI txnID</th>
                    <th scope="col">EMI No</th>
                    <th scope="col">Collect Time</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">EMI</th>
                    <th scope="col">Fine Amount</th>
                    <th scope="col">EMIPayMode</th>
                    <th scope="col">Agent</th>
                    <th scope="col">Customer </th>
                    <th scope="col">Loan ID </th>
                    <th scope="col">Group Name </th>
                    <th scope="col">Loan Type</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">

   $(document).ready(function(){
            $('#selCust').select2();
            $('#selAgent').select2();
            $('#selGroup').select2();
            $('#src_PayMode').select2();
            
        });
function delete_EMI(EMIID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteEMI.php?EMIID='+EMIID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showEMIList(curPage)
{
  var CID= $('#selCust').val();
  var GID= $('#selGroup').val();
  var agent= $('#selAgent').val();

  if(CID==undefined)
    CID='';

  if(GID==undefined)
    GID='';
  
  var rdbDay=$("input:radio[name ='rdbDay']:checked").val();
  // var loan_opr=$('#src_loan_opr').val();
  // var Loan_Amount=$('#src_Loan_Amount').val();

  // var EMIPrinci_opr=$('#src_EMIPrinci_opr').val();
  // var EMI_Principal=$('#src_EMI_Principal').val();
  
  // var EMIInterst_opr=$('#src_EMIInterst_opr').val();
  // var EMI_Interest=$('#src_EMI_Interest').val();
  
  // var FineAmount_opr=$('#src_FineAmount_opr').val();
  // var Fine_Amount=$('#src_Fine_Amount').val();
  
  var PaymentMode=$('#src_PayMode').val();
  var EMI_DueDateFrom = $('#src_EMI_DueDateFrom').val();
  var EMI_DueDateTo = $('#src_EMI_DueDateTo').val();

  var LoanType=0;
  if($('#src_LoanType1').is(':checked'))
  {
    LoanType+=1;
  }
  if($('#src_LoanType2').is(':checked'))
  {
    LoanType+=2;
  }

  $('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');
  var xmlhttp=new XMLHttpRequest();
  
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);

      var CurPage=parseInt($('#txtCurPage').val());
      var totalPage=parseInt($('#spn_totalPage').html());

      if(CurPage>totalPage)
      {
      setCookie('EMIPageNo',totalPage,7); 
      window.location.reload();       
      }
    }
  }
setCookie('EMIPageNo',curPage,7);
 /*
 "getEMICollectionList.php?page="+curPage+"&CID="+CID+"&GID="+GID+"&agent="+agent+"&EMIPrinci_opr="+EMIPrinci_opr+"&EMI_Principal="+EMI_Principal+"&EMIInterst_opr="+EMIInterst_opr+"&EMI_Interest="+EMI_Interest+"&FineAmount_opr="+FineAmount_opr+"&Fine_Amount="+Fine_Amount+"&loan_opr="+loan_opr+"&Loan_Amount="+Loan_Amount+"&PaymentMode="+PaymentMode+"&LoanType="+LoanType+"&EMI_DueDateFrom="+EMI_DueDateFrom+"&EMI_DueDateTo="+EMI_DueDateTo+"&rdbDay="+rdbDay
 */
  xmlhttp.open("GET","getEMICollectionList.php?page="+curPage+"&CID="+CID+"&GID="+GID+"&agent="+agent+"&PaymentMode="+PaymentMode+"&LoanType="+LoanType+"&EMI_DueDateFrom="+EMI_DueDateFrom+"&EMI_DueDateTo="+EMI_DueDateTo+"&rdbDay="+rdbDay,true);
  xmlhttp.send();
}

var pageNo=getCookie('EMIPageNo');
if(pageNo=='')
  pageNo=1;

showEMIList(pageNo);

function setCustPageSize(a)
{
document.cookie="pgCollectionSize="+a; 
showEMIList(1);
}

function setCustPageNumber(a)
{
showEMIList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}

function setCollection(txnID)
{
$('#tdCollect'+txnID).html('<center><img src="assets/img/processing.gif"/></center>');
  
var Fine_Amount= $('#spnFineAmt'+txnID).html();
var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    $('#tdCollect'+txnID).html(xmlhttp.responseText);
    }
  } 
  console.log("setEMICollection.php?txnID="+txnID+"&Fine_Amount="+Fine_Amount);
  
  xmlhttp.open("GET","setEMICollection.php?txnID="+txnID+"&Fine_Amount="+Fine_Amount,true);
  xmlhttp.send();

}

agentID_Change();


function setToday()
{
var hdToDay=$('#hdToDay').val();
$('#src_EMI_DueDateFrom').val(hdToDay);
$('#src_EMI_DueDateTo').val(hdToDay);
setCookie('emiCollectedDayChoice',0,7);
showEMIList(pageNo);
}

function setWeekDay()
{
var hdWeekFrom=$('#hdWeekFrom').val();
var hdWeekTo=$('#hdWeekTo').val();
$('#src_EMI_DueDateFrom').val(hdWeekFrom);
$('#src_EMI_DueDateTo').val(hdWeekTo);
setCookie('emiCollectedDayChoice',1,7);
showEMIList(pageNo);
}

function setMonthDay()
{
var hdMonthFrom=$('#hdMonthFrom').val();
var hdMonthTo=$('#hdMonthTo').val();
$('#src_EMI_DueDateFrom').val(hdMonthFrom);
$('#src_EMI_DueDateTo').val(hdMonthTo);
setCookie('emiCollectedDayChoice',2,7);
showEMIList(pageNo);
}

function setCurrentSession()
{
var start_date=$('#hdStart_date').val();
var end_date=$('#hdEnd_date').val();
$('#src_EMI_DueDateFrom').val(start_date);
$('#src_EMI_DueDateTo').val(end_date);
setCookie('emiCollectedDayChoice',3,7);
showEMIList(pageNo);
}

$('#src_EMI_DueDateFrom').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_EMI_DueDateTo').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
</script>
<?php 
include('end_html.php');
?>
