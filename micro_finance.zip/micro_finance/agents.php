<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');  

if(isset($_GET['lastPage']))
{
  if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$Select_sql = "SELECT count(`AgentID`) as C  FROM `agent_profile`";
$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  
  $lastPage=ceil($count/$Intv);

  setcookie("AgentPageNo", $lastPage, time() + 3600);

  //echo ' last page '.$lastPage;
}

?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

  <?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Agents</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Agent</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of Agent   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          Mobile Number
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_mobile" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Address
                        </div>
                        <div class="col-lg-3">
                         <input type="text" id="src_address" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          City
                        </div>
                        <div class="col-lg-3">
                          <?php 
$Select_sql ="SELECT `Sl`, `City_Name` FROM `city_master` where `State_Sl`=18;";
// right now only city of Assam will be shown
$result = mysqli_query($db,$Select_sql);
$selCities='There is no City ';

if(mysqli_num_rows($result)>0)
{
$selCities=<<<select_Cities
<select id="selCity" name='cityId' class="from-control" style="width:200px;">
  <option value="">Select City</option>
select_Cities;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['City_Name'];
    
$selCities.=<<<select_Cities
<option value='$Code'>$Name</option>
select_Cities;
  } 
$selCities.=<<<select_Cities
</select> 
select_Cities;
}

echo $selCities;
?>
<span id='spnCity_Name'></span>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          ID Proof
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_IDProof" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          Address Proof
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_AddressProof" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          
                        </div>
                        <div class="col-lg-3">
                         
                        </div>
                        <div class="col-lg-3">
                          Sex
                        </div>
                        <div class="col-lg-3">
                          <select id="src_sex" class="form-control">
                            <option value="0"></option>
                            <option value="1">Male</option>
                            <option value="2">Female</option>
                            <option value="3">Other</option>
                          </select>
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Joining Date
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_JoiningDate_from" placeholder="dd-mm-yyyy"  class="form-control">
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_JoiningDate_to" placeholder="dd-mm-yyyy" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showAgentList(1)">
                        </div>
                      </div>
                      </fieldset>
                   </div>
                   <a href="agent_edit.php">Add New</a>
                   &nbsp;&nbsp;
                   <a href="agent_add_balance.php">Transfer Balance to Agent</a> 
                   &nbsp;&nbsp;&nbsp;
                   <a href="agent_withdraw_balance.php">Withdraw Balance from Agent</a> 
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">action</th>
                    <th scope="col">AID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Balance</th>
                    <th scope="col">Mobile No</th>
                    <th scope="col">Address</th>
                    <th scope="col">IDProof</th>
                    <th scope="col">addressProof</th>
                    <th scope="col">IDProofLink</th>
                    <th scope="col">addressProofLink</th>
                    <th scope="col">photoLink</th>
                    <th scope="col">city</th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
              <!-- End Table with stripped row py-1 s -->
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  
   $(document).ready(function(){
            $('#selCity').select2();
        });

  function delete_agent(AgentID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteAgent.php?AID='+AgentID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showAgentList(curPage)
{

  var name=$('#src_name').val();
  var mobile=$('#src_mobile').val();
  var address=$('#src_address').val();
  var IDProof=$('#src_IDProof').val();
  var AddressProof=$('#src_AddressProof').val();
  var city=$('#selCity').val();
  var JoiningDate_from = $('#src_JoiningDate_from').val();
  var JoiningDate_to = $('#src_JoiningDate_to').val();

$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');
  
    var xmlhttp=new XMLHttpRequest();
$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }
 
 setCookie('AgentPageNo',curPage,7);
 /*
console.log("getAgentList.php?page="+curPage+"&name="+name+"&mobile="+mobile+"&address="+address+"&IDProof="+IDProof+"&AddressProof="+AddressProof+"&city="+city+"&JoiningDate_from="+JoiningDate_from+"&JoiningDate_to"+JoiningDate_to);
*/
  xmlhttp.open("GET","getAgentList.php?page="+curPage+"&name="+name+"&mobile="+mobile+"&address="+address+"&IDProof="+IDProof+"&AddressProof="+AddressProof+"&city="+city+"&JoiningDate_from="+JoiningDate_from+"&JoiningDate_to"+JoiningDate_to,true);
  xmlhttp.send();
}

<?php  
if(isset($_SESSION['lastPage']))
{
  if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$Select_sql = "SELECT count(`AgentID`) as C  FROM `agent_profile`";
$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  
  $lastPage=ceil($count/$Intv);

echo 'showAgentList('.$lastPage.');';

unset($_SESSION['lastPage']);
}
else 
{
?>
var pageNo=getCookie('AgentPageNo');
if(pageNo=='')
  pageNo=1;

showAgentList(pageNo);
<?php 
}
?>

function setCustPageSize(a)
{
document.cookie="pgZize="+a; 
showAgentList(1);
}

function setCustPageNumber(a)
{
//document.cookie="pgSizeC="+a; 
showAgentList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}

function showAgentTxn_List(AID)
{
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      console.log(xmlhttp.responseText);
      $('#agent_txn_list'+AID).html(xmlhttp.responseText);
    }
  }
  xmlhttp.open("GET","getAgent_Txn_List4Modal.php?AID="+AID,true);
  xmlhttp.send();
}


$('#src_JoiningDate_from').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#src_JoiningDate_to').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#src_JoiningDate_from').val('');
$('#src_JoiningDate_to').val('');
</script>
<?php 
include('end_html.php');
?>
