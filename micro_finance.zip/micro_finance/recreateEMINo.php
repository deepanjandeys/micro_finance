<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include('includes/db.php');
//include('includes/functions.php');
$LoanRegNo='2'; 
date_default_timezone_set("Asia/Kolkata");
extract($_GET); 

$CID=0; $EMIPrincipal=''; $EMIInterest=''; $EMIPayMode=''; 
$LoanDate=''; $CloseDate='';

$sqlLog = PHP_EOL.'-- recreateEMI.php '.PHP_EOL;
        $crDate=date('Y-m-d H:i:s');

        ///////////////////////////////
            $txnID=0;

            $SelSql="SELECT `LoanRegNo` FROM `loan_register`;";
            $Recordset      =   mysqli_query($db,$SelSql);
            while($row            =   mysqli_fetch_assoc($Recordset))
            {
        extract($row);
        $emiNo=0;
        $SelSql1="SELECT `txnID` FROM `emi_register` WHERE `LoanRegNo`=$LoanRegNo Order bY `txnID`;";
        
        $Recordset1      =   mysqli_query($db,$SelSql1);
            while($row1  =   mysqli_fetch_assoc($Recordset1))
            {

        $emiNo++;
        extract($row1);

        $updSql="UPDATE `emi_register` SET `emiNo`=$emiNo WHERE `txnID`=$txnID";

        $sqlLog .= $updSql.PHP_EOL;
        $res1   = mysqli_query($db,$updSql);

        $txnID++;
}
}


//////////////////////////////
    
$sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
$handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>