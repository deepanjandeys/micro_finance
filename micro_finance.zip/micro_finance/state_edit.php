<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$ID=''; $State_Name=''; $State_Sl='';
$Action="Add new";
$ActionButton="Save";
if(isset($_GET['ID']))
{
$ID=(int)$_GET['ID'];
 $SelSql="SELECT `Sl` as `ID`, `State_Name` FROM `State_master` WHERE `Sl`=$ID";
 //echo $SelSql;
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)>0)
    {
        $row=   mysqli_fetch_assoc($Recordset);
        extract($row);
        $Action="Edit";
        $ActionButton="Update";
    }
}
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>State</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">State</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">State <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveState.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="ID" value="<?php echo $ID; ?>">
                <div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">State Name</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="State_Name" name="State_Name" value="<?php echo $State_Name; ?>" required>
                  </div>
                </div>
              
                <div class="text-center">
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
</script>

<?php 
include('end_html.php');
?>
