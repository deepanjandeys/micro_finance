<?php 
include('headers.php'); 
include('includes/db.php');    
@session_start();
?>
<body>
  <!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$ActionButton='Save';
$Action = 'Save'; $agentId=''; $AID='0';
extract($_GET);

if(isset($_SESSION['isAdmin']))
{
  if($_SESSION['isAdmin']=='0')
  {
    goto lastLine;
  }
}
else 
{
  goto lastLine;
}

?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Withdraw Balance from Agent</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Agent Withdraw Balance</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Withdraw Balance from Agent <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveAgentWithdrawBalance.php" method="post" onsubmit="return form_validation();">
                <?php 
$Select_sql ="SELECT `AgentId`, `AgentName` FROM `agent_profile`";

$result = mysqli_query($db,$Select_sql);
$selAgents='There is no Agent ';

if(mysqli_num_rows($result)>0)
{
$selAgents=<<<Select_Agents
<input class="form-control" 
            list="agentIdOptions" name='agentId' id='agentId'  
            placeholder="Select Agents " value="$AID" onchange='fetchCurBalance(this.value)' autocomplete="off" required> 
        <datalist id="agentIdOptions"> 
Select_Agents;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['AgentId'];
    $Name=$row['AgentName'];
    
$selAgents.=<<<Select_Agents
<option value='$Code'>$Name</option>
Select_Agents;
  } 
$selAgents.=<<<Select_Agents
</datalist> 
Select_Agents;
}
?>
<div class="row mb-3">
                  <label for="inputEmail3" class="col-sm-2 col-form-label">Agent Id</label>
                  <div class="col-sm-4">
                    <?php echo $selAgents; ?>
                  </div>
                  <div class="col-sm-6">
                    <span id='spnAgentname'></span>
                  </div>
                </div>
                <input type="hidden" name="AID" value="<?php echo $AID; ?>">
                <div class="row mb-3">
                  <label for="withdraw_balance" class="col-sm-2 col-form-label">Withdraw Balance</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="withdraw_balance" name="withdraw_balance"  required>
                    
                  </div>
                </div>
                 
                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Current Balance</label>
                  <div class="col-sm-4">
                     <span id="spnCurBalance"></span>
                  </div>
                  <input type="hidden" name="Balance" id="Balance">
                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
lastLine:

include('footers.php');
?>
<script type="text/javascript">
  
function fetchCurBalance(agentId)
{
  var xmlhttp=new XMLHttpRequest();

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#spnCurBalance').html(xmlhttp.responseText);
      $('#Balance').val(xmlhttp.responseText);
    }
  }
 
 // console.log("fetchCurBalanceOfAgent.php?agentId="+agentId);
  xmlhttp.open("GET","fetchCurBalanceOfAgent.php?agentId="+agentId,true);
  xmlhttp.send();
}

fetchCurBalance(<?php echo $AID; ?>);

function form_validation()
{
var msg='';
  if($('#agentId').val()=='')
  {
    msg +='Select an Agent<br>';
  }
 
 var Balance=parseFloat($('#Balance').val());
 var withdraw_balance=parseFloat($('#withdraw_balance').val());
if(withdraw_balance>Balance)
{
  msg +='Withdraw Amount must be less than Current Balance';
}
  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}
</script>
<?php 
include('end_html.php');
?>
