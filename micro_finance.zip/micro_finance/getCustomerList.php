<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$CID=''; $CustName='';  $Address=''; $mobileNo=''; $IDProof=''; $addressProof='';
$IDProofLink=''; $addressProofLink=''; $photoLink=''; $agentId=''; $cityId=''; 
$sex='';  $dob='';  $page=0;
//print_r($_POST);

$name='';   $mobile='';     $address='';    $IDProof='';    $AddressProof='';   $agent='';      $city='';       
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and CustName like '%".$name."%' ";
}

$mobileStr='';
if($mobile<>'')
{
    $mobileStr=" and c.mobileNo like '%".$mobile."%' ";
}

$addressStr='';

if($address<>'')
{
    $addressStr=" and c.Address like '%".$address."%' ";
}

$IDProofStr='';
if($IDProof<>'')
{
    $IDProofStr=" and c.IDProof like '%".$IDProof."%' ";
}

$AddressProofStr='';
if($AddressProof<>'')
{
    $AddressProofStr=" and c.addressProof like '%".$AddressProof."%' ";
}
$agentStr='';

if($agent<>'')
{
    $agentStr=" and c.agentId =".$agent;
}

$cityStr='';
if($city<>'')
{
    $cityStr=" and c.cityId =".$city;
}
date_default_timezone_set("Asia/Kolkata");

if(isset($_COOKIE['pgZize']))
    $Intv=(int)$_COOKIE['pgZize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `CID`, `CustName`, c.`Address`, c.`mobileNo`, c.`IDProof`, c.`addressProof`, c.`IDProofLink`, c.`addressProofLink`, c.`photoLink`, a.`AgentName`,cm.`City_Name`, g.`name` as `sex`, c.`dob` FROM `customer_profile` as c LEFT JOIN `agent_profile` as a ON a.AgentId=c.agentId LEFT JOIN `city_master` as cm ON  c.`cityId`=cm.`Sl` JOIN `gender_master` as g on c.sex=g.id WHERE 1 $nameStr $mobileStr $addressStr $IDProofStr $AddressProofStr $agentStr $cityStr Order By `CID` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              $IDProofLinkStr='';
              $addressProofLinkStr='';
              $photoLinkStr='';
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        $IDProofLinkStr='';
        $addressProofLinkStr='';
        $photoLinkStr='';
        
        extract($row);   
        
        if($IDProofLink!=''){
                    if(file_exists("uploads/IDProofLink/".$IDProofLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($IDProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/IDProofLink/$IDProofLink' alt='uploads/IDProofLink/$IDProofLink' style='width:50px;' />&nbsp;&nbsp;";

                        $IDProofLinkStr= '<a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">'.$fileTag.'</a>';
                      }
                      else if($extension=='pdf')
                      {
                      $fileTag=  '<object data= 
                    "uploads/IDProofLink/'.$IDProofLink.'" 
                    width="50" height="50"> </object> ';
                      
                      $IDProofLinkStr= $fileTag.'<br><a href="uploads/IDProofLink/'.$IDProofLink.'" target="_blank">Preview</a>';
                      }
                      
                    }
                  } 
        if($addressProofLink!='')
        {
                    if(file_exists("uploads/addressProofLink/".$addressProofLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($addressProofLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/addressProofLink/$addressProofLink' alt='uploads/addressProofLink/$addressProofLink' style='width:50px;' />&nbsp;&nbsp;";
                    
                        $addressProofLinkStr= '<a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">'.$fileTag.'</a>';
                    
                      }
                      else if($extension=='pdf')
                      {
                      $fileTag=  '<object data= 
                    "uploads/addressProofLink/'.$addressProofLink.'" 
                    width="50" height="50"> </object> ';
                    
                      $addressProofLinkStr= $fileTag.'<br><a href="uploads/addressProofLink/'.$addressProofLink.'" target="_blank">Preview</a>';
                    
                      }
                      
                      }
                  } 
        if($photoLink!=''){
                    if(file_exists("uploads/photoLink/".$photoLink))
                    {
                      $fileTag='';
                      $extension = strtolower(pathinfo($photoLink, PATHINFO_EXTENSION));
                    if($extension=='png' || $extension =='jpg' || $extension=='jpeg' || $extension=='gif')
                      {
                        $fileTag= "<img src='uploads/photoLink/$photoLink' alt='uploads/photoLink/$photoLink' style='width:50px;' />&nbsp;&nbsp;";
                      }
                     

                      $photoLinkStr= '<a href="uploads/photoLink/'.$photoLink.'" target="_blank">'.$fileTag.'</a>';
                    }
                  } 
        echo "<tr>
                    <th scope='row'><a href='customer_edit.php?CID=$CID'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_cust($CID)'>Delete</a></th>
                    <td>$CID</td>
                    <td>$CustName</td>
                    <td>$mobileNo</td>
                    <td>$Address</td>
                    <td>$IDProof</td>
                    <td>$addressProof</td>
                    <td>$IDProofLinkStr</td>
                    <td>$addressProofLinkStr</td>
                    <td>$photoLinkStr</td>
                    <td>$AgentName</td>
                    <td>$City_Name</td>
                    <td>$sex</td>
                    <td>$dob</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`CID`) as C  FROM `customer_profile` as c WHERE 1 $nameStr $mobileStr $addressStr $IDProofStr $AddressProofStr $agentStr $cityStr";
echo '<tr><td colspan="8">';
//echo $Select_sql;
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];
                    
$lnks= get_pagination_links($page,'showCustomerList',$count,$Intv);
echo $lnks;

echo "</td></tr>";
?>