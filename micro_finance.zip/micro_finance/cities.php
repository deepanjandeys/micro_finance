<?php 
@session_start();
include('headers.php'); 
include('includes/db.php');  
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Cities</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">City</li>
          <li class="breadcrumb-item active">List</li>
        </ol>
      </nav>
    </div><!-- End Page Title  -->

    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">List of City   &nbsp;&nbsp;<a id="a_search" class="btn" href="javascript:void(0)" onclick="show_hide_search()">Show Search</a></h5>
                   <!-- Table with stripped rows -->
                   <div id="divSerach" style="display:none;">
                    <fieldset class="bg-warning p-2 text-white rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3">
                          <input type="text" id="src_name" class="form-control">
                        </div>
                        <div class="col-lg-3">
                          <?php 
$Select_sql ="SELECT `Sl`, `State_Name` FROM `state_master` ";
$result = mysqli_query($db,$Select_sql);
$selStates='There is no Agent ';
if(mysqli_num_rows($result)>0)
{
$selStates=<<<select_States
<select id="selState" name='State_Sl' class="from-control" style="width:200px;">
  <option value="">Select City</option>
select_States;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['Sl'];
    $Name=$row['State_Name'];
    
$selStates.=<<<select_States
<option value='$Code'>$Name</option>
select_States;
  } 
$selStates.=<<<select_States
</select> 
select_States;
}
echo $selStates;
?>
<span id='spnState_Name'></span>
                        </div>
                        <div class="col-lg-3">
                          <input type="button" id="src_search" class="btn btn-primary" value="Search" onclick="showCitiList(1)">
                        </div>
                      </fieldset>
                   </div>
                   <a href="city_edit.php">Add New</a>
              <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>action</th>
                    <th style="width:20px">ID</th>
                    <th style="widh:100px;">Name</th>
                    <th style="width:50px;">State</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id="tbCust">
                </tbody>
              </table>
            </div>
              <!-- End Table with stripped row py-1 s -->
            </div>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  $(document).ready(function(){
    $('#selState').select2();
  });

  function delete_city(CitiID)
  {
    if(confirm('Do you want to Delete'))
    {
      location.replace('deleteCity.php?ID='+CitiID);
    }
    else 
    {
      //alert('not deleted');
    }
  }

function showCitiList(curPage)
{

  var name = $('#src_name').val();
  var State_Sl = $('#selState').val();
  var xmlhttp=new XMLHttpRequest();
$('#tbCust').html('<center><img src="assets/img/processing.gif"/></center>');
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#tbCust').html(xmlhttp.responseText);
    }
  }

setCookie('CityPageNo',curPage,7);

//console.log("getCityList.php?page="+curPage+"&name="+name+"&State_Sl="+State_Sl);
  xmlhttp.open("GET","getCityList.php?page="+curPage+"&name="+name+"&State_Sl="+State_Sl,true);
  xmlhttp.send();
}

<?php  
if(isset($_SESSION['lastPage']))
{
  if(isset($_COOKIE['pgSizeC']))
    $Intv=(int)$_COOKIE['pgSizeC'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$Select_sql = "SELECT count(`Sl`) as C  FROM `city_master` ";
$result = mysqli_query($db,$Select_sql);
$row = mysqli_fetch_array($result);
   $count=0;
  if(isset($row['C']))
    $count=$row['C'];
  
  $lastPage=ceil($count/$Intv);

echo 'showCitiList('.$lastPage.');';

unset($_SESSION['lastPage']);
}
else 
{
?>

var pageNo=getCookie('CityPageNo');
if(pageNo=='')
  pageNo=1;

showCitiList(pageNo);
<?php  
}
?>

function setCustPageSize(a)
{
document.cookie="pgSizeC="+a; 
showCitiList(1);
}

function setCustPageNumber(a)
{
//document.cookie="pgSizeC="+a; 
showCitiList(a);
}

function show_hide_search() 
{
  $('#divSerach').toggle('slow');

  if($('#a_search').html()=='Show Search')
  {
    $('#a_search').html('Hide Search');
  }
  else 
  {
    $('#a_search').html('Show Search');
  }
}

</script>
<?php 
include('end_html.php');
?>
