<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
include('includes/functions.php');

$ID='';    $name='';   
extract($_GET);

$nameStr='';
if($name<>'')
{
    $nameStr=" and principalAmount like '%".$name."%' ";
}

if(isset($_COOKIE['pgSize']))
    $Intv=(int)$_COOKIE['pgSize'];
else
    $Intv=0;

if($Intv==0)
    $Intv=10;

$page=(int)$page;
if($page==0)
    $page++;

$start=($page-1)*$Intv; 

$SelSql="SELECT `principalAmt`, `FineAmt` from `fine_master` WHERE 1 $nameStr Order By `principalAmt` LIMIT ".$start.','.$Intv.";";
//echo "<br>".$SelSql;
              $Recordset      =   mysqli_query($db,$SelSql);
              
    if(mysqli_num_rows($Recordset)>0)
    {
        while($row=   mysqli_fetch_assoc($Recordset))
        {
        extract($row);   
        
        echo "<tr>
                    <th scope='row'><a href='fine_edit.php?principalAmt=$principalAmt'>Edit</a>
                    <a href='javascript:void(0)' onClick='delete_Fine($principalAmt)'>Delete</a></th>
                    <td>$principalAmt</td>
                    <td>$FineAmt</td>
                  </tr>";
         
        }
    } 
              
$Select_sql = "SELECT count(`principalAmt`) as C  FROM `fine_master` WHERE 1 $nameStr";
echo '<tr><td colspan="8">';
                $result = mysqli_query($db,$Select_sql);
                $row = mysqli_fetch_array($result);
                 $count=0;
                if(isset($row['C']))
                    $count=$row['C'];

$lnks= get_pagination_links($page,'showFineList',$count,$Intv);
echo $lnks;

echo "</td></tr>";
?>