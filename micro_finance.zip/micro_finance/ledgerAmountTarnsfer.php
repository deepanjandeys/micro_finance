<?php 
include('headers.php'); 
include('includes/db.php');    
?>
<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

<?php include('topMenu.php'); ?>

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
 <?php include('leftNavMenu.php'); ?>
  </aside><!-- End Sidebar-->

<?php 
$ledgerID='';  $Amount=0; $ledgerID1=''; $Remarks='';

$Action="Add new";
$ActionButton="Save";
?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Amount Transfer between Ledger</h1>
      <hr/>

      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Amount Transfer between Ledgers</li>
          <li class="breadcrumb-item active"><?php echo $Action; ?></li>
        </ol>
      </nav>
      <hr/>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body" style="background-color:#B8B8B8;">
              <h5 class="card-title">Amount Transfer between Ledgers <?php echo $Action; ?></h5>

              <!-- Horizontal Form -->
              <form action="saveLedgerAmountTransfer.php" method="post" enctype="multipart/form-data" onsubmit="return form_validation();">
                <div class="row mb-3">
                  <label for="ledgerID" class="col-sm-2 col-form-label">Ledger #1</label>

<div class="col-sm-4">
                  <?php 
$Select_sql ="SELECT `LedgerID`,`LedgerName` FROM `ledger_master` where `LedgerType`=1;";

$result = mysqli_query($db,$Select_sql);

$selLedgers='There is no Ledger';

if(mysqli_num_rows($result)>0)
{
$selLedgers=<<<select_Ledgers
<input class="form-control" 
            list="ledgerIDOptions" name='ledgerID' id='ledgerID'  
            placeholder="Select Ledger " value="$ledgerID" onchange='ledgerID_Change()'> 
        <datalist id="ledgerIDOptions"> 
select_Ledgers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['LedgerID'];
    $Name=$row['LedgerName'];
    
$selLedgers.=<<<select_Ledgers
<option value='$Code'>$Name</option>
select_Ledgers;
  } 
$selLedgers.=<<<select_Ledgers
</datalist> 
select_Ledgers;
}

echo $selLedgers;
?>
</div>
<div class="col-3">
  <span id='spnledgerID_Name'></span>
</div>
<div class="col-3">
  <span id="spnCurBalance"></span>
</div>
</div>
<div class="row mb-3">
  <label for="Amount" class="col-sm-2 col-form-label">Amount</label>
  <div class="col-sm-4">
  <input type="number" class="form-control" id="Amount" name="Amount" value="<?php echo $Amount; ?>" required>
  </div>
</div>
                <div class="row mb-3">
                  <label for="ledgerID1" class="col-sm-2 col-form-label">Ledger #2</label>

<div class="col-sm-4">
<?php 
$Select_sql ="SELECT `LedgerID`,`LedgerName` FROM `ledger_master` where `LedgerType`=1;";

$result = mysqli_query($db,$Select_sql);

$selLedgers='There is no Ledger';

if(mysqli_num_rows($result)>0)
{
$selLedgers=<<<select_Ledgers
<input class="form-control" 
            list="ledgerIDOptions1" name='ledgerID1' id='ledgerID1'  
            placeholder="Select Ledger " value="$ledgerID" onchange='ledgerID1_Change()'> 
        <datalist id="ledgerIDOptions1"> 
select_Ledgers;

while ($row = mysqli_fetch_array($result))
    {
    $Code=$row['LedgerID'];
    $Name=$row['LedgerName'];
    
$selLedgers.=<<<select_Ledgers
<option value='$Code'>$Name</option>
select_Ledgers;
  } 
$selLedgers.=<<<select_Ledgers
</datalist> 
select_Ledgers;
}

echo $selLedgers;
?>
</div>
<div class="col-3">
  <span id='spnledgerID_Name1'></span>
</div>
<div class="col-3">
  <span id="spnCurBalance1"></span>
</div>
</div>
<div class="row mb-3">
  <label for="Remarks" class="col-sm-2 col-form-label">Remarks</label>
  <div class="col-sm-4">
  <input type="text" class="form-control" id="Remarks" name="Remarks" value="<?php echo $Remarks; ?>" >
  </div>
</div>

                <div class="text-center">
                  <div id="divErrMsg"  class="list-group-item list-group-item-danger"></div>
                  <button type="submit" name="action" value="<?php echo $ActionButton; ?>" class="btn btn-primary"><?php echo $ActionButton; ?></button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Horizontal Form -->

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->
<?php 
include('footers.php');
?>
<script type="text/javascript">
  function ledgerID1_Change() {
    var val = document.getElementById("ledgerID1").value;
    var opts = document.getElementById('ledgerIDOptions1').children;

    $('#spnledgerID_Name1').html('');
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].value === val) {
        // An item was selected from the list!
        // yourCallbackHere()
        $('#spnledgerID_Name1').html(opts[i].text);
        fetchCurBalance(val,'1');
        break;
      }
    }
  }  

ledgerID_Change();
ledgerID1_Change();

function form_validation()
{
var msg='';
  if($('#ledgerID').val()=='')
  {
    msg +='Select Ledger 1<br>';
  }

  if($('#ledgerID1').val()=='')
  {
    msg +='Select Ledger 2<br>';
  }

var Amount=parseFloat($('#Amount').val());
if(isNaN(Amount))
Amount=0;

if(Amount==0)
{
  msg+="Type an Amount <br>";
}
  if(msg !='')
  {
  $('#divErrMsg').html(msg);
  return false;
  }
  return true;
}

function fetchCurBalance(ledgerId,whichOne)
{
  var xmlhttp=new XMLHttpRequest();
if(whichOne ==undefined)
  whichOne='';
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
      $('#spnCurBalance'+whichOne).html(xmlhttp.responseText);
    }
  }
 
  console.log("fetchCurBalanceOfLedger.php?ledgerId="+ledgerId);
  xmlhttp.open("GET","fetchCurBalanceOfLedger.php?ledgerId="+ledgerId,true);
  xmlhttp.send();
}

</script>

<?php 
include('end_html.php');
?>
