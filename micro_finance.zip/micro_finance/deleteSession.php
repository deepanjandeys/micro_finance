<?php 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);
@session_start();

include('includes/db.php');
//include('includes/functions.php');

$id=''; 

extract($_GET); 
$sqlLog = PHP_EOL.'-- deleteSession.php '.PHP_EOL;
        
    $SelSql =   "SELECT `id`  FROM `session_master` WHERE `id`<>$id and `active`=1;";
    $Recordset      =   mysqli_query($db,$SelSql);
    if(mysqli_num_rows($Recordset)==0)
    {
        $_SESSION['error_message']='This session is active session, first make session it inactive then delete this session';
        header('location:settings.php');
        die();
    
    }
    $delSql="DELETE FROM `session_master` WHERE `id`=".$id;

    
    $sqlLog .= $delSql.PHP_EOL;
    $res1   = mysqli_query($db,$delSql);

    header('location:settings.php'); 
    $sqlLog =str_replace(";",";".PHP_EOL,$sqlLog);
    $handle = fopen($_SERVER['DOCUMENT_ROOT'].'/sqlLog/db__'.date('Y-m-d').'.sql','a');
    fwrite($handle,$sqlLog);
    fclose($handle);
?>